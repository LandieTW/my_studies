# Change Log
All notable changes to the RLC project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [5.1.0] - 2026-05-27

Version 5.1.0 adds support for user-defined OrcaFlex results in analysis criteria.

### Fixed
- Fixed a bug where cases were incorrectly marked as excluded (status `X`) based on DNV-RP-N103 minimum period checks even when `calculate_min_period` was set to `False`. This caused Hs values for smaller periods to be filtered out regardless of the setting. (#41)

### Added
- Support for user-defined OrcaFlex results.  RLC now parses the `UserDefinedResults()` function from the model's external function script (embedded or external file) to extract valid result names. These names are accepted during analysis criteria validation alongside standard built-in result parameters.
- Validation that external user-defined result scripts are listed in `extra_files`.

## [5.0.2] - 2026-05-15

Version 5.0.2 is a patch release that improves performance and fixes a bug with
bisection retries when using HPC-Flex.

### Fixed
- Fixed a bug where bisected seeds were never re-submitted when using HPC-Flex.
After a bisection, the seed status is set to 'F0', 'F1', etc., but the HPC-Flex
submission query only looked for 'Q' and 'Q+' statuses.  This caused an
infinite loop where the bisection was detected but no files were sent for
solving.  The DOF and local interfaces were not affected.

### Changed
- Significantly improved the performance of storing results to the database by
using batched updates and parallel JSON file reading.
- Significantly improved the performance of the bootstrap confidence interval
calculation by using NumPy vectorization.


## [5.0.1] - 2026-05-06

Version 5.0.1 is a minor update to Version 5.0.0 to fix bugs that were
identified after the release of Version 5.0.0.

### Fixed
- Fixed bug where ``hs_min`` was never considered during the coarse step-down
search. When reducing H\ :sub:`s`\  by ``hs_course_step``
resulted in a value below ``hs_min``, the target is now floored at
``hs_min`` so that it is always evaluated before concluding that all
sea states fail for a given period.

### Changed
- Updated online documents to reflect changes in Version 5.0.0 and to add the
change log.

### Added
- Added a retry mechanism when copying the local database to the
network path. The sync now retries up to 5 times (2 seconds apart)
if the file is locked, and logs a confirmation message when a retry
succeeds.

## [5.0.0] - 2026-04-08

Version 5.0.0 represents a major update the RLC script.  The main focus of Version 5.0.0 is to implement Gumbel distribution fit checking to ensure the calculated fit parameters can be considered to be a good fit for the distribution.  In previous versions the script would use the gumbel distribution parameters to calculate probabilistic loads, regardless of the 'goodness of fit.'  The assumption that all data fit a Gumbel distribution is not always valid.

### Changed
- When performing the statistical analysis, if the data is found to not fit the Gumbel distribution, then the analysis switches to the empirical method to determine statistical values. If there are insufficient seeds available to use the empirical method, additional seeds are run in accordance with the required probability level. If the empirical method is used, bootstrapping is implemented to obtain confidence intervals for the results.
- The method of input was changed from custom python script to an input configuration file using a YAML text file format.  A detailed input checker has been implemented to ensure the input provided is valid.  This has a number of benefits over the previous method:

    - The user no longer needs to know how to do programming in python,
    - The YAML file format is familiar for many people working with Orcaflex,
    - Allows for the future adoption of a GUI to build the YAML file,
    - Allows for the future conversion to an executable program rather than a python script.

- A simple text based graphical user interface (GUI) has been implemented during the running of the files.  The GUI provides additional information beyond what was provided in previous versions to indicate the status of the analysis.

- In previous versions, the analysis was run on a single H\ :sub:`s`\ basis.  Starting with the highest defined H\ :sub:`s`\, the analysis would work backwards considering only one unique H\ :sub:`s`\ at a time.  The current version runs everything that will eventually have to be run during the first iteration.  This may mean multiple H\ :sub:`s`\ may be considered at any one time.  As well, since course and fine H\ :sub:`s`\ increments are possible, the script can search for each governing H\ :sub:`s`\ independently for each period.

- Folders are now used to store all created files during the run.  The only files in the working folder are the initiation python script (i.e. :file:`run.py``), the Orcaflex base file and the RLC configuration file.

- RLC now uses a SQLite database to store results and status as the script progresses.  If the script crashes or if there are issues, the user can load the SQLite database using the `SQLite Browser <https://sqlitebrowser.org/dl/>`_ to open the database.  The database is located in the :file:`database/` folder.  During execution, RLC will write to a temporary local database and regularly sync with the `database/` folder (as the user may be running RLC on a network drive).

- Seed values are no longer repeated throughout the analysis.  In previous versions, the seed number for seed 1, for example, for all H\ :sub:`s`\/Period/Wave Directions was the same.  This version has a unique seed value for each file that is run.  The seed value is recorded in the :file:`rlc_results.db` file and the :file:`rlc_results.xlsx` file.

### Added
- Users now has the option to get RLC to send email updates as the analysis progresses.  This is useful when analysis is scheduled to run overnight and the user may wish to get notification of the status after hours.

- The spreadsheet containing the results (:file:`results/rlc_results.xlsx`) now also contains the seed number (1, 2, 3, etc.) as well as the seed value.

- A debug mode has been added.  When debug mode is activated, additional log messages are written to help the user troubleshooet issues.

- Added ability to specify the JONSWAP gamma parameter as per the requirements of Petrobras in Brazil.

### Removed
- Users can no longer specify "abs" (absolute value) for a results parameter.  If the absolute value is required, the user should use a "max" check and a "min" check in combination with the same (but opposite sign) limit.  This simplifies coding as makes it clear how the software is working.

- Users can no longer specify multiple acceptance criteria for the same orcaflex object, result parameter and probability level.  For example, there can only be one Crane_Wire, End A, Effective tension, 90%, max check.  This is to simplify input checking and output.  If the user wishes to use the same parameter against multiple criteria, the worst criteria should be entered.

## [4.1.1] - 2025-04-03
- Fixed bugs when values equal exactly 0

## [4.1.0] - 2024-08-20

### Beta 1 - 2024-08-22
- Update to allow newer version of Python to be used (Replaced Panda's panels with Multiindexed dataframes).
- Removed ability to produce plots.  This was a rarely used feature and could be better handled using a seperate script/spreadsheet.
- Added ability to automatically create post calculation action files based on input in the master_script.py file.
- Fixed bug with including extra files for HPC-Flex
- Added an error check to ensure that all extra files specified are of filetype *.py, *.his or *.inc.  If other files are needed (i.e. *.dll files) they need to be added to HPC-Flex by olivier.caro@technipfmc.com.

## [4.0.0] - 2024-07-29
- Pulling of Version 4.0.0b5 to 4.0.0.

### Beta 5 - 2024-04-15
- Error noted by Young Jang Na when setting t_start to a constant.

### Beta 4 - 2024-04-11
- Partially fixed issue with the static solve case.  When using HPC-Flex as the run method, the simulation of the static (i.e. Hs=0) case is run on the local machine using the OrcFXAPI library.  The script would check to see if the static.txt file was present when all HPC-Flex runs are complete.  If the result is not present it would simply set the result to 0.  The script now waits for 10 minutes for the static result to appear.  Perhaps need to consider an alternative method?  When running on a DOF environment, the static case is run on DOF as well so this issue doesn't appear.

- Updated license error handler for local solutions based on feedback from Orcina

### Beta 3 - 2024-04-04
- Corrected another bug with duplicate log messages.

### Beta 2 - 2024-04-02
- Corrected bug with duplicate log messages. 

### Beta 1
- Initial Beta Release

### Added
- Added this change log for future reference.

- Added ability to specify sea state period as either Spectral Peak Period (Tp) or Zero Crossing Period (Tz).

- Added ability to specify additional files that may be needed in the anlaysis (e.g. post calculation action files, external function files, etc.)

### Changed
- Replaced screen and log file logging methods to use the python logging library.
- Log files now have fixed names (rlc_log.txt and weather_window.txt)
 
### Fixed
- Fixed issues with writing to log files.  The script would sometimes have an error if the filesystem for the log file was too busy to release the file in time for the next update.

- Fixed issue for checking if there is a valid internet connection when HPC-Flex has failed.  The old method tried to resolve 1.1.1.1 Port 83 (DNS). This appears to be blocked at TFMC now.  The current method attempts to resolve www.google.com to see if there is a valid internet connection.

## [3.1.12] - 2023-08-17

### Added
- Added status updates for jobs submitted to HPC-Flex.

## [3.1.11] - 2022-09-07

### Added
- Added Orcaflex Version as an input for the user to select the version of Orcaflex to be used for HPC-Flex

## [3.1.10] - 2022-09-07

## [3.1.9] - 2022-04-19

## [3.1.8] - 2022-02-21

### Fixed
- Updated to reflect new Digicorner domain

## [3.1.7] - 2021-10-15

### Fixed
- Fixed issue where DLL path for DOF may be in a different location than the Norway cluster.

## [3.1.6] - 2021-04-21

## [3.1.5] - 2021-04-06
### Fixed
- Minor HPC-Flex Optimizations


## [3.1.4] - 2021-03-23
### Added
- Working implementation of HPC-Flex

### Fixed
- Fixed bug in dofcmd command.

## [3.1.3] - 2021-03-23

## [3.1.2] - 2021-03-23

## [3.0.15] - 2020-01-26

### Added
- Added feature to deal with license errors

### Fixed
- Minor bug fixes

## [3.0.15] - 2020-10-05

### Added
- Added option to pass OrcFxAPI.dll path

## [3.0.15] - 2020-10-02

