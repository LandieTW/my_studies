.. _usage:

##################
Running the Script
##################

.. contents::
   :local:
   :depth: 2

Introduction
************

The script requires Python and some extra libraries to function (i.e. numpy,
scipy, ). Note that these libraries are not included with the standard Python
distribution.  If RLC is installed using the
:ref:`installation instructions<installation>` most of these libraries are
installed automatically.  The only exception is HPC-Flex which requires a
manual installation using the instructions provided in
:ref:`installation instructions<installation>`

Work Flow
*********

The workflow in the repeated lowering method is outlined in
:numref:`Figure %s <figure-workflow>`.

.. _figure-workflow:

.. figure:: images/RLCWorkFlow.jpg
   :alt: Work Flow - Repeated Lowering
   :width: 500px
   :align: center

   Work Flow - Repeated Lowering Control

The yellow boxes indicate the stages in which user intervention is needed.

Orcaflex Model
**************

Base File
=========

Each analysis requires a properly defined Orcaflex file which contains the
fully defined system for the analysis.  The most typical analysis type that the
RLC script is used for is for splash zone deployment, though other types of
operations can also be simulated using RLC (including hoisting operations).

Environment
-----------

The RLC script is based on multiple simulations of the operation in different
irregular waves with the same statistical parameters.  A probabilistic analysis
is performed to determine the probabilistic loads and parameters that can be
compared against acceptance criteria.  As such, the analysis assumes that an
JONSWAP irregular wave is defined.

Therefore, a single wave train should be defined in the Orcaflex model with the
JONSWAP spectrum defined as the Wave Type
(see :numref:`Figure %s <figure-EnvironmentData>`).  The option for "User
specified seeds" should also be selected.

The Wave Direction, H\ :sub:`s`\, Tz and Seed will be automatically populated
by the RLC script when the analysis files are created.

The spectral parameters will also be defined through the RLC script.

.. _figure-EnvironmentData:

.. figure:: images/OrcaflexEnvironmentData.jpg
   :alt: Orcaflex - Environment Data
   :width: 500px
   :align: center

   Orcaflex - Environment Data

If wave shielding is to be utilized ensure:

    - the Orcaflex vessel object contains Sea State RAOs
    - the lifted object is fully contained within the wave shielded zone as
      defined by the Sea State RAOs
    - each Orcaflex object refers to the Disturbance Vessel for the wave
      shielding to be applied

Crane Wire
----------

The analysis assumes that an structure will be lowered or hoisted using a crane
wire.  This can be simulated using either an Orcaflex Winch object or an
Orcaflex Line object with line feeding enabled.  The winch/line can be attached
to a vessel with defined RAOs (displacement or force) at a point representing
the crane tip location.

The pay-out/pay-in speed of the winch/line should be set to a speed within the
specifications of the hoist and should represent a typical value.

The properties of the winch/line wire (i.e. stiffness, etc.) should represent
the properties of the actual hoisting wire.

Slings
------

Items such as pennant, slings, etc. should be included to represent the actual
lift configuration.  These can be modelled using either line or link objects.

The properties of the line/link (i.e. stiffness, etc.) should represent the
properties of the actual pennant/slings.

Lifted Object
-------------

The structure being lifted should be modelled in
accordance with guidelines such as
`OED-TGR-272 Part D <http://subseacoe.digicorner.intra/knowledgecentre/references/Level3Documents/OED-TGR-272%20Part%20D.pdf>`_
:cite:`OED-TGR-272_Part_D`.  This includes a sufficient
discretization to ensure a proper response in waves.

The lifted object should be fully supported by the sling/crane wire system
without any other winches or lines connecting to it during the lower/hoisting
process.

Post Calculation Actions
------------------------

The RLC script uses a post calculation action script to extract results from
the analysis after each analysis file has been run.  By default, this post
calculation action file (Python) is created automatically by the RLC. However,
the user also has the option of specifying their own post calculation script
and additional scripts.  **It is highly recommended that the automated post
calculation script is used.**

If the the post calculation action is created automatically by the script,
the post calculation action should be defined as
:file:`auto_post_calc_action.py` as shown in
:numref:`Figure %s <figure-PostCalcAction>`.


.. _figure-PostCalcAction:

.. figure:: images/OrcaflexPostCalcAction.jpg
   :alt: Orcaflex - Post Calculation Actions
   :width: 500px
   :align: center

   Orcaflex - Post Calculation Actions

If the post calcualtion action script is created by the user, ensure the
correct file name is specified.

Folder Setup
************

A minimum of three files are required to run the RLC script.  These include:

=========================   ==========================
File                        Description
=========================   ==========================
:file:`*.dat`               Orcaflex Base File as described above.
:file:`run_rlc.py`          Launch file for RLC script created by the user
                            (can be renamed as necessary).
:file:`rlc_input.yml`       Configuration data for the RLC run.
=========================   ==========================

Optionally, a fourth file may be include which is the custom post calculation
action script file as described above.

The `run_rlc.py` file is a simple python script that must be created by the
user containing the following lines:

.. code-block:: python
   
   import rlc.main as rlc

   if __name__ == "__main__":
      rlc.main()


No other files are required.  To ensure the script runs successfully, it is
recommended that no other files be present in the folder when running.  All
files created during the execution of the script are stored in sub folders.

If the a local computing cluster is used to perform the analysis using
Distributed Orcaflex, the folder needs to reside in a location that each
computer in the cluster can access.

If the local computer or if HPC-Flex is used ot perform the analysis, any
folder is sufficient.

During the execution of RLC, the following folders and
files are created:

.. list-table:: Folders and Files Created
   :widths: 30 70
   :header-rows: 1

   * - Folder/File
     - Description
   * - :file:`database/rlc_results.db`
     - SQL database created to keep track of results
       and status as the script executes.  During
       runtime, RLC will write to a local temporary
       database.  This temporary database is deleted
       once the script completes.
   * - :file:`logs/rlc.log`
     - Main log file for the RLC run.  This file is
       updated as the script executes.
   * - :file:`logs/zero_wave.log`
     - The local CPU performs an analysis of the file
       with zero wave height.  This is the log file
       of that process.
   * - :file:`results/rlc_results.xlsx`
     - An Excel spreadsheet with the complete set of
       results which includes:

       - Overall status of each
         H\ :sub:`s`\/T
       - Overall status of each
         H\ :sub:`s`\/T/WaveDir
       - Results from each individual yml file.
       - Gumbel parameters and fit checks for each
         criteria
   * - :file:`results/weather_window.xlsx`
     - An Excel spreadsheet showing the weather
       window table with a summary of the loads for
       each case.
   * - :file:`results/weather_window.pdf`
     - A pdf print of the Excel spreadsheet.
   * - :file:`runs/`
     - A folder containing:

       - All :file:`*.yml` files needed
       - All :file:`*.json` results files from each
         run
       - Plus other files below
   * - :file:`runs/__pycache__`
     - Created if Distributed Orcaflex is used.
       Contains compiled python modules for the post
       calculation actions.
   * - :file:`runs/auto_post_calc_action`
     - Created by RLC if automatic_post_calc is set
       to True.
   * - :file:`runs/dof_call_err.txt`
     - Created if Distributed Orcaflex is used.
   * - :file:`runs/dof_submit.txt`
     - Created if Distributed Orcaflex is used.
   * - :file:`runs/hpc_files.zip`
     - Created if HPC-Flex is used.
   * - :file:`runs/base_file.dat`
     - A copy of the base file.


Running the Script
******************

To run the script, launch a command prompt by selecting the Windows Start
Button and typing "CMD."  Then click the icon to open a Command Prompt.

If you've installed RLC into a virtual environment, activate that environment
(see :ref:`installation instructions<installation>`).

At the command prompt, navigate to the folder containing the :file:`run_rlc.py`
file.

After the :file:`rlc_input.yml` file has been updated for the appropriate
inputs type the following command.

.. code-block:: console

   python run_rlc.py

If the input file has a different name than :file:`rlc_input.yml` then it can
be specified as an argument after the python script file.

.. code-block:: console

   python run_rlc.py rlc_input_sample.yml

This will start running the :file:`run_rlc.py` file and run the required
analysis.  The command prompt window will provide updates as to the progress of
the analysis.  Result files will be present in the folder.

Previous Run Checks
===================

RLC does not delete result :file:`*.json` files that have already been created
by a previous run if a new RLC run is launched. It is up to the user to manage
the folders and identify if it is safe to perform a new run.

Base File Changes
-----------------

If RLC is launched and the :file:`runs` folder contains an existing copy of the
base file from a previous run, and if the base file is different, the user will
be presented with a warning message asking if they want to proceed.

In some cases, this may be acceptable.  For example, if the users adds a
comment to the comment section of the base file or if the user changes another
parameter that does not influence the results.  This may be acceptable.

In some cases, changing the time set to a smaller timestep may be acceptable.
It is the user's responsibilty to check this.

If the user selects that they do not want to continue using the changed file
the RLC script will stop, giving the user an opportunity to investigate.

Input File Changes
------------------

When RLC is run, it makes a copy of the input :file:`*.yml` file and places it
in the :file:`runs` folder (with a :file:`*.yml.original` file extension).

If RLC is launched and the :file:`runs` folder exits and it contains a
:file:`*.yml.original` file from a previous run, RLC will check to
see if any of the following critical parameters are changed.  Critical
parameters are defined as those parameters that would cause an individual run
to produce different results.  This would require a rerun of RLC.

The following parameters are considered critical:

- ``base_file``
- ``period_type``
- ``calculate_jonswap_gamma``
- ``calculate_jonswap_gamma_method``
- ``jonswap_gamma``

The only exception to this is the ``seed_random_generator`` parameter.  While
re-running with a different psudo random number generator seed will generate
different results, this doesn't invalidate the existing results.  The user
should be aware, though, that if the analysis is run from scratch.

Command Line Arguments
======================

As mentioned, an input file argument can be specified.  Additionally, other 
optional arguments are available.


.. code-block:: console

   python run_rlc.py [FILENAME] [OPTIONS]

Positional Arguments
--------------------

FILENAME
   Optional YAML input file. If omitted, the file ``rlc_input.yml`` is used.

Options
-------

--ignore-interactive-warnings
   Skip warnings that normally require user interaction.

--debug
   Provides additional log messages that could help debug issues such as:
   
   - Loop number for analysis loop.
   - Input file validation indicator.
   - Output of Hs and Period cases.
   - etc.

Starting a New Run
******************

If the user has made significant changes to the input file and/or the base
file, the user can do a complete new run by deleting all of the folders created
by the previous runs and starting with the three required files.