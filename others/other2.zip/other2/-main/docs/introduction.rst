.. _introduction:

############
Introduction
############

The **RLC (Repeated Lowering Control) Script** is a specialized Python
library designed to support probabilistic analysis and control evaluation for
offshore lifting operations. Developed to streamline and automate the
assessment of wave-induced dynamic responses, the script facilitates the
generation, execution, and statistical evaluation of simulation cases based on
randomized sea states.

At its core, the RLC script manages a structured SQLite database
(`rlc_results.db`) that organizes simulation data across multiple layers of
analysis:

- **Seed-Level Analysis** (`seed_results`):
  Individual simulations based on randomized wave
  seeds.
- **Statistical Aggregation** (`stat_results`):
  Probabilistic evaluation of grouped seed results
  for specific sea states and wave directions.
- **Case-Level Assessment** (`case_results`):
  Summary evaluations across all directions for a
  given sea state.
- **Fit Criteria Evaluation** (`criterion_tables`):
  Statistical results and goodness-of-fit tests
  (KS and AD) for distribution modeling.

Each table is governed by a robust status-tracking system that enables
efficient workflow management, from initial setup to final result validation.
The script supports both single-run and iterative seed expansion workflows,
with built-in logic for bootstrap fallback and acceptance criteria testing.

This documentation provides a comprehensive guide to installing, using, and
understanding the RLC script, including its theoretical foundations and
practical usage examples.