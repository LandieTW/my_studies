.. _output:

######
Output
######

.. contents::
   :local:
   :depth: 2

Introduction
************

Once the script has finished running, with no errors, 3 output files are
created in the ``results/`` folder.

rlc_results.xlsx
****************

This file contains the full dataset of all analysis and results.  It includes
numerous tabs.

.. list-table:: ``rlc_results.xlsx`` Spreadsheet
   :widths: 20 80
   :header-rows: 1

   * - Tab
     - Description
   * - sqlite-sequence
     - RLC now uses an SQlite3 database to store all results and keep track of
       all analysis.  The ``rlc_results.xlsx`` spreadsheet is a conversion of
       this database (``database/rlc_results.db``) to Excel format.  This tab
       contains a table summarizing the number of rows on each of the sheets
       contained in the database/spreadsheet.
   * - case_results
     - This tab contains a listing of all of the H\ :sub:`s`\ and wave period
       T\ :sub:`p`\/T\ :sub:`z` combinations along with the associated status,
       number of seeds that were needed, as well as the governing value from all
       of the wave directions considered for each result parameter requested.
   * - stat_results
     - This tab contains a list of all of the H\ :sub:`s`\ , wave period
       T\ :sub:`p`\/T\ :sub:`z` and wave direction combinations with the
       associated status, number of seeds, as well as the calculated statistical
       results for each result parameter requested.
   * - seed_results
     - This tab contains a list of each YAML file that was run including the
       H\ :sub:`s`\ , wave period T\ :sub:`p`\/T\ :sub:`z`, wave direction,
       status, seed number (from 1 to the total number of seeds), seed value
       (as calculated by the pseudo-random number generator) as well as the raw
       result values obtained from each Orcaflex analysis as extracted from the
       post calculation ``*.json`` files.
   * - Parameter Result Tabs
     - Tab created for each result parameter.

weather_window.xlsx
*******************

This file contains a summary of the analysis results that would be suitable to
be included in a report.  The file is an Excel spreadsheet which can be useful
for copy and pasting data to reports.

The file contains a single sheet where all results are summarized in the
following sections:

Analysis Heading
================

Four items are presented at the top of the output:

.. list-table:: ``weather_window.xlsx`` Spreadsheet
   :widths: 20 80
   :header-rows: 1

   * - Item
     - Description
   * - Base File
     - The ``basefile.dat`` file used in the analysis.
   * - Base File OF Version
     - The OrcaFlex version that was used to prepare the ``basefile.dat``.
   * - Base File Save Date
     - Presents the last save date of the ``basefile.dat``.  This can be
       useful for understanding which exact base file was used to perform
       the RLC analysis.
   * - Run Using RLC Version
     - Reports the version of RLC that was used to run the analysis.

Input File Header
=================

This sections reprints the ``header`` key in the input file.  It would be
useful to have analysis specific information here which may include background
on the acceptance criteria.

Allowable Weather Window Table
==============================

Presents the traditional "Go/No Go" table of H\ :sub:`s`\ vs Period
(T\ :sub:`p`\/T\ :sub:`z`).  This table will indicate whether a particular
H\ :sub:`s`\/Period combination is acceptable ("OK"), no good ("NG") or not
analyzed ("X").  Cases that are marked with an "X" are cases where the
H\ :sub:`s`\ is too large for the given period in accordance with DNV-RP-N103
:cite:`DNV-RP-N103`.

If the input key ``alpha_factor`` is set to a value other than 1.0 the
H\ :sub:`s`\ values will be reduced by the ``alpha_factor``.

:numref:`Figure %s <figure-GoNoGoTable>` shows a typical "Go/No Go" table.

.. _figure-GoNoGoTable:

.. figure:: images/GoNoGoTable.png
   :alt: Typical Go/No Go Table
   :width: 500px
   :align: center

   Typical Go/No Go Table

Summary Table
=============

Presents a numerical summary of the results.  This table shows the maximum
allowable H\ :sub:`s`\ for each wave period as well as the maximum/minimum
value of each parameter being assessed.  The requested probability level is
shown in addition to the limits that the results are compared against.  Units
for each result parameter are extracted from OrcaFlex and presented.

A no waves case has also been run to show the results without any waves.
For this case, the structure is lowered through the splash zone with the
H\ :sub:`s`\ set to 0m.

:numref:`Figure %s <figure-SummaryTable>` shows the summary table.

.. _figure-SummaryTable:

.. figure:: images/SummaryTable.png
   :alt: Typical Summary Table
   :width: 500px
   :align: center

   Typical Summary Table

Detailed Table
==============

Presents a numerical summary of all H\ :sub:`s`\/Period/Wave Direction cases.
This table shows the maximum/minimum values of each parameter being assessed.
The requested probability level is shown in addition to the limits that the
results are compared against. Units for each result parameter are extracted
from OrcaFlex and presented.

Values that do not meet the acceptance criteria are highlighted in red.

The no waves case is also presented.

:numref:`Figure %s <figure-DetailedTable>` shows the detailed output table.

.. _figure-DetailedTable:

.. figure:: images/DetailedTable.png
   :alt: Typical Partial Detailed Table
   :width: 500px
   :align: center

   Typical Partial Detailed Table

weather_window.pdf
******************

After the ``weather_window.xlsx`` file has been created a pdf of this file is
automatically created.  This is to make it easier to include the results
summary in analysis reports.