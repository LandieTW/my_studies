.. _console:

###########
DOS Console
###########

.. contents::
   :local:
   :depth: 2

Introduction
************

While the script is running, a logger is used to log message to the console
screen as well as to the log file located at ``logs/rlc.log``.

The script firstly checks the input data specified in the ``rlc_input.yml``
file to ensure required keys are defined and optional keys are valid.  Once the
input has be validated the DOS console window change to a text based graphical
user interface (GUI).  This console window can be resized and the contents will
rescale with it.  The console window has 3 main regions: Status Table, Legend
and Log Messages.

.. _figure-gui_console:

.. figure:: images/gui_console.png
   :alt: Text Graphical User Interface
   :width: 500px
   :align: center

   Text Graphical User Interface

Status Table
************

This table provides the status of each and every H\ :sub:`s`\ and wave period
T\ :sub:`p`\/T\ :sub:`z` combination.  As the analysis progresses, the status
of each case is updated in the table to give the user visibility of the
progress.

Legend
******

The legend area shows all of the possible values that can appear in the Status
Table and are summarized below.

.. list-table:: Optional Arguments
   :widths: 20 80
   :header-rows: 1

   * - Status
     - Description
   * - X
     - This period is below the the minimum period
       for that H\ :sub:`s`\ in accordance with
       DNV-RP-N103 :cite:`DNV-RP-N103`
   * - \-
     - This case has not been assessed yet.
   * - N
     - RLC has determined that this case needs to be
       analyzed.  This is the the first time that it
       has been run.  The analysis will be performed
       using ``min_seeds``.
   * - Y
     - YAML files are being created for this case.
   * - Q
     - The analysis has been added to the queue to be
       submitted to Distributed Orcaflex or HPC-Flex.
   * - R
     - The analysis files for this case are currently
       running on Distributed Orcaflex or HPC-Flex.
   * - A
     - The analysis has been completed and the results
       are being stored and assessed (using Gumbel
       distribution or empirical distribution).
   * - N+
     - RLC has determined that:

       - One or both of the fit tests failed
         (KS and/or AD test failed)
       - The requested probability level for the
         parameter in question requires more seeds
         than what has been run.
   * - Y+
     - YAML files are being created for the additional
       seeds.
   * - Q+
     - The analysis for the additional seeds has been
       added to the queue to be submitted to
       Distributed Orcaflex or HPC-Flex.
   * - R+
     - The analysis for the additional seed files for
       this case are currently running on Distributed
       Orcaflex or HPC-Flex.
   * - A+
     - The analysis for the additional seeds has been
       completed and the results are being stored and
       assessed (using Gumbel distribution or
       empirical distribution).
   * - OK
     - The statistical results meet the requirements
       for all acceptance criteria.
   * - NG
     - The statistical results of at least one
       parameter in one of the wave directions does
       not meet the acceptance criteria.
   * - F
     - One of the analysis files failed.

Logging Messages
****************

This window shows the most recent 4 log messages sent to the logger.  These
messages will be present in the ``logs/rlc.log`` file.