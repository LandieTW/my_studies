.. _input_file:

#####################
Input File Parameters
#####################

.. contents::
   :local:
   :depth: 2

Introduction
************

The file :file:`rlc_input.yml` is a YAML file that is read when the
:file:`run_rlc.py` script is ran.  This file can be renamed if desired as long
as the correct file name is used when launching RLC.  A sample file is provide
here: (:download:`rlc_input.yml <_static/downloads/rlc_input.yml>`).

The :file:`rlc_input.yml` file uses the YAML file format, similar to how
Orcaflex YAML files work.  YAML files require a specific syntax to work
properly, however, the syntax is very readable and easy to use.
Visit `yaml.org <http://yaml.org>`_ for more details.

Required Keys
*************

In the :file:`rlc_input.yml` at least three keys are required.  All other keys
are optional and have default values (or are not required).  The three required
keys are : ``header``, ``base_file`` and ``vars_limits``.  There are also
optional arguments that can be defined if necessary.

.. confval:: header
  :type: string (multi line)
  :default: N/A

  A key named ``header`` is used to add additional details to the output files
  to give the user an opportunity to document the results.  A sample format is
  provided but this section can really contain any text.

  The header can be multiple lines. To do this use a pipes character (|) after
  the key name and indent the text. All indented text before the definition of
  the next keys is part of the header.
  .. code-block:: yaml

      header: |
          Project: Test Project
          Analysis: Test Structure
          Author: ABC    Date: 15-Aug-2025
          Sling Limit is per rigging design and rigging calculations.
          Structure mass is xxx tonne.

.. confval:: base_file
  :type: string
  :default: N/A

  A key named ``base_file`` contains the name of the Orcaflex base
  :file:`*.dat`` file.  In this case the filename is
  :file:`base_file_name.dat`.

  .. code-block:: yaml

      base_file: "base_file_name.dat"

.. confval:: analysis_criteria
  :type: string
  :default: N/A

  The ``analysis_criteria`` section defines a list of analysis criteria for
  evaluating specific parameters of objects within the model. Each criterion
  is represented as a YAML mapping (a set of key-value pairs) within a
  sequence, and it specifies the conditions under which certain parameters
  (e.g., forces, angles, etc.) are analyzed to produce a probabilistic value.
  Examples of typical criteria that are evaluated are:

  - Maximum Dynamic Hook Load

  - Minimum Dynamic Hook Load

  - Maximum Sling Load

  - Minimum Sling Load

  - Maximum Structure Load

  - Maximum Lift Point Load

  Other items can also be considered as necessary.  For example passive heave
  compensator stroke, crane wire angle, crane wire load, connection force, etc.

  Through defining the acceptance criteria, it sets the acceptable risk for
  each parameter. For example, a probability_level of 0.99 for mode: "max" for
  effective tension for a line element means that parameter should exceed the
  defined threshold in no more than 1% of cases.

  Each list item is a mapping with the following keys:

  .. confval:: orcaflex_object_name
    :type: string
    :default: N/A

    The exact name of the OrcaFlex object in the model (i.e. crane_wire)

  .. confval:: orcaflex_object_parameter
    :type: string
    :default: N/A

    The parameter of the object to be evaluated.  For example, this could be a
    line ``Effective tension`` or a 6D buoy ``Connection z force``.  Any of the
    available OrcaFlex results parameters are possible.

    Must match one of the allowed parameters for the specified OrcaFlex object.

    For the complete list of acceptable parameter values see
    :ref:`orcaflex-parameters-6d-buoy`,
    :ref:`orcaflex-parameters-line`,
    :ref:`orcaflex-parameters-link`,
    :ref:`orcaflex-parameters-winch`,
    :ref:`orcaflex-parameters-shape`,
    and :ref:`orcaflex-parameters-constraint`.

    **User-Defined Results**

    In addition to the built-in OrcaFlex result parameters, user-defined
    results are also supported.  User-defined results are defined via a
    Python script containing a ``UserDefinedResults(model)`` function, as
    described in the
    `OrcaFlex documentation <https://www.orcina.com/webhelp/OrcaFlex/Content/html/Generaldata,Userdefinedresults.htm>`_.

    The script can be either embedded in the OrcaFlex base file or stored
    in an external ``.py`` file.  If an external file is used, it **must**
    be included in the :confval:`extra_files` list.

    RLC will automatically parse the ``UserDefinedResults()`` function to
    extract valid result names.  Use the ``Name`` value from the result
    dictionary as the ``orcaflex_object_parameter``.

    For example, if the user-defined results script defines:

    .. code-block:: python

        def UserDefinedResults(model):
            return (
                {
                    "ObjectType": OrcFxAPI.ot6DBuoy,
                    "Name": "Depth",
                    "Units": "LL",
                    "TimeDomainFunction": Depth
                },
            )

    Then the ``orcaflex_object_parameter`` would be ``"Depth"``.

    .. note::

       User-defined result names that are constructed dynamically (e.g.
       using string formatting or ``exec()``) cannot be validated at input
       checking time and will be rejected.  Where possible, use string
       literals for the ``Name`` key in the result dictionaries.

    **Important: Acceptable parameters are case sensitive!**

  .. confval:: orcaflex_object_argument
    :type: string
    :default: N/A

    Required for line elements to identify where on the line the
    results should be evaluated.

    Valid Values are shown below.

    .. list-table::
      :header-rows: 1

      * - Value
        - Description
      * - ``End A``
        - Evaluate the result (using ``mode`` below) at the EndA end of the
          line.
      * - ``End B``
        - Evaluate the result (using ``mode`` below) at the EndB end of the
          line.
      * - ``Range``
        - Evaluate the result (using ``mode`` below) over the full length of
          the line.


  .. confval:: probability_level
    :type: float
    :default: N/A

    A decimal value (between 0 and 1) indicating the probability threshold for
    the criterion.  The ``probability_level`` defines the probability threshold
    for the criterion, interpreted as either the probability of exceedance or
    non-exceedance depending on the mode.

    **Limits:**

      - **Minimum:**  :math:`>0`
      - **Maximum:**  :math:`<1`

  .. confval:: mode
    :type: string
    :default: N/A

    Valid values are shown below:
    
    .. list-table::
      :header-rows: 1

      * - Value
        - Description
      * - ``max``
        - the probability of exceedance :math:`P(X>x)`, the
          likelihood that the parameter exceeds the specified value.
          The maximum value from the time history is extracted.
      * - ``min``
        - the probability of non-exceedance :math:`P(X≤x)`,
          the likelihood that the parameter is less than or equal to the
          specified value.  The minimum value from the time history is
          extracted.


  .. confval:: value
    :type: float
    :default: N/A

    A float value indicating the limiting criteria value in the units as
    defined by Orcaflex.    

  Below are some examples of how the YAML text could be structured.  Note that
  tabs are very important in YAML files.

  .. code-block:: yaml

      analysis_criteria:
      - orcaflex_object_name: "crane_hook"
        orcaflex_object_parameter: "Connection z force"
        probability_level: 0.99
        mode: "max"
        value: 680

  In this case, the OrcaFlex object in question is the 6D buoy ``crane_hook``.
  ``Connection z force`` is a a result parameter of a 6D buoy.  This means that
  in 99% of cases, the force should remain at or below 680 kN.  If this is not
  the case, the criteria is considered failed (i.e. crane overload).  Note that
  the result parameter units is always in the units as specified by OrcaFlex
  (force is in kN, angles are in degrees, etc.)

  .. code-block:: yaml

      - orcaflex_object_name: "crane_hook"
        orcaflex_object_parameter: "Connection z force"
        probability_level: 0.9
        mode: "min"
        value: 32

  In this case, the OrcaFlex object in question is again the 6D buoy
  ``crane_hook`` with the parameter ``Connection z force``.  This means that in
  90% of the cases, the force should remain at or above 32 kN.  If this is not
  the case, the criteria is considered failed (i.e. slack crane wire).

  .. code-block:: yaml

      - orcaflex_object_name: "Sling1"
        orcaflex_object_parameter: "Effective tension"
        orcaflex_object_argument: "End A"
        probability_level: 0.9
        mode: "max"
        value: 145

  In this case, the OrcaFlex object in question is the line element ``Sling1``
  with the parameter ``Effective tension``.  It also contains the argument
  "End A" meaning the result is taken at End A of the OrcaFlex line element.
  This means that in 90% of the cases, the tension force should remain at or
  above 145 kN.  If this is not the case, the criteria is considered failed
  (i.e. sling failure, padeye failure, etc.)

  .. code-block:: yaml

      - orcaflex_object_name: "Sling1"
        orcaflex_object_parameter: "Effective tension"
        orcaflex_object_argument: "End A"
        probability_level: 0.9
        mode: "min"
        value: 0

  In this case, the OrcaFlex object in question is again the line element
  ``Sling1`` with the parameter ``Effective tension``.  It also contains the
  argument "End A" meaning the result is taken at End A of the OrcaFlex line
  element. This means that in 90% of the cases, the tension force should remain
  at or below 0 kN.  If this is not the case, the criteria is considered failed
  (i.e. sling failure, padeye failure, etc.)

Optional Keys
*************

The optional arguments that are available in the ``rlc.run()`` function is
where most of the customization of the script exists.  All of the parameters
have default values, but the user will likely have to specify custom values for
their particular analysis.

Option arguments are entered using a simple syntax:

.. code-block:: yaml

    keyword: value

The full list of optional arguments are specified below.

.. confval:: hs_start
  :type: float
  :default: ``3.5``

  Starting (highest) significant wave height (H\ :sub:`s`\) to be considered
  in the analysis, in meters.
  
  **Limits:**

  - **Minimum:**  :math:`0.1`
  - **Maximum:**  :math:`20` (warning issued if it exceeds  :math:`5`)


.. confval:: hs_course_step
  :type: float
  :default: ``0.5``

  The coarse step size for reducing the significant wave height (H\ :sub:`s`\)
  during the analysis, in meters. This step is used to iteratively test lower
  H\ :sub:`s`\ values until an acceptable value is found.

  ``hs_start`` must be a multiple of ``hs_course_step``.

  **Limits:**

  - **Minimum:**  :math:`0.1`
  - **Maximum:** ``hs_course_step``

.. confval:: hs_fine_step
  :type: float
  :default: ``hs_course_step`` value.

  The fine step size for reducing the significant wave height (H\ :sub:`s`\)
  after the coarse step identifies an acceptable value, in meters. This allows
  for refinement to find a slightly higher H\ :sub:`s`\.  If a fine step is not
  needed, set the value of ``hs_fine_step`` equal to the value of
  ``hs_course_step``.

  ``hs_start`` and ``hs_course_step`` must be a multiple of ``hs_fine_step``.

  **Limits:**

  - **Minimum:** :math:`0.1`
  - **Maximum:** ``hs_course_step``

.. confval:: hs_min
  :type: float
  :default: ``0.25``

  The lowest significant wave height (H\ :sub:`s`\) to consider in the
  analysis, in meters.

  ``hs_min`` must be a multiple of ``hs_fine_step``.  ``hs_min`` must be less
  or equal to ``hs_course_step`` and ``hs_max``.

  **Limits:**

  - **Minimum:** :math:`0.1`
  - **Maximum:** ``hs_course_step``

.. confval:: period_type
  :type: string
  :default: ``"Tp"``

  The type of irregular wave period to be used in the analysis. Options are:

  Valid Values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``Tp``
      - Spectral Peak Period
    * - ``Tz``
      - Zero Crossing Period

.. confval:: calculate_jonswap_gamma
  :type: boolean
  :default: True

  Determines whether the JONSWAP gamma parameter is calculated automatically.
  Options are:

  Valid Values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``True``
      - calculates gamma based on the value in
        ``calculate_jonswap_gamma_method``
    * - ``False``
      - use a manually specified gamma value

.. confval:: calculate_jonswap_gamma_method
  :type: string
  :default: ``"of"``

  Specifies the automatic gamma calculation method.

  Valid values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``dnv``
      - Uses the method defined by DNV-RP-N103 :cite:`DNV-RP-N103`.  This
        method only works when ``period_type`` is ``Tp``.
    * - ``pb``
      - Uses the method specified by Petrobras.  This method only works when
        ``period_type`` is ``Tp``
    * - ``of``
      - Uses the method built into Orcaflex based on Isherwood
        :cite:`Isherwood1987Jonswap`.  This method only works  ``period_type``
        is ``Tz``.

  The DNV method is based on the formulas in DNV-RP-N103 :cite:`DNV-RP-N103`.
  
  .. math::
   :label: eq:dnv_gamma1
  
    {\gamma}=e^{(5.75-1.15{T_p}/{\sqrt{H_s}})}
    \text{ for } 3.6<T_p/\sqrt{H_s}<5

  .. math::
   :label: eq:dnv_gamma2
  
    {\gamma}=1 \text{ for } 5≤T_p/\sqrt{H_s}

  The Orcaflex method is based the formulas deveoped by Isherwood
  :cite:`Isherwood1987Jonswap`:

  .. math::
   :label: eq:isherwood_gamma1
  
    {\gamma}=10.54 - 1.34s^{-\frac{1}{2}}-e^{-19+3.775s^{-\frac{1}{2}}}
    \text{ for } s≥0.037
    
  .. math::
   :label: eq:isherwood_gamma2
    
    {\gamma}=0.9 + e^{18.86-3.67s^{-\frac{1}{2}}} \text{ for } s<0.037

  Where *s* is the wave steepness as shown below.  The above formulae are
  valid for :math:`\mbox{0.03 < s < 0.15}`.

  .. math::
   :label: eq:isherwood_wavesteepness
  
    s=\frac{2{\pi}H_s}{gT_z^2}

  The Petrobras method is based on the formula:

  .. math::
   :label: eq:petrobras_gamma

   {\gamma}=6.4 T_{p}^{-0.491}

.. confval:: jonswap_gamma
  :type: float
  :default: ``1.0``

  Jonswap gamma value to use if ``calculate_jonswap_gamma`` is
  ``False``. If ``calculate_jonswap_gamma`` is ``True``, this value is ignored.

.. confval:: calculate_min_period
  :type: boolean
  :default: ``True``

  Determines if the minimum period to be investigated is automatically
  calculated.

  Valid values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``True``
      - Calculate minimum period based on H\ :sub:`s`\/DNV-RP-N103
    * - ``False``
      - Use ``t_start`` value

.. confval:: t_end
  :type: float
  :default: ``18``

  Largest period in seconds to consider.

    **Limits:**

  - **Minimum:** ``t_start`` or ``1`` whichever is higher.
  - **Maximum:** :math:`30`

.. confval:: t_start
  :type: float
  :default: ``1.0``

  Minimum period to consider. If ``calculate_min_period`` is ``True``,
  this value is ignored.

  **Limits:**

  - **Minimum:** :math:`>0`
  - **Maximum:** Lower of ``t_end`` and ``30``.

.. confval:: t_step
  :type: float
  :default: ``1.0``

  Time step for periods < ``t_step_change``.

.. confval:: t_step2
  :type: float
  :default: ``2.0``

  Time step for periods > ``t_step_change``.

.. confval:: t_step_change
  :type: float
  :default: ``8.0``

  Period at which to change the time step from ``t_step`` to ``t_step2``.

.. confval:: t_extra
  :type: list of floats
  :default: []

  List of additional periods to consider. These will be added to the periods
  generated by the ``t_start``, ``t_end``, ``t_step``, and ``t_step2`` values.

.. confval:: wave_dirs
  :type: list of floats
  :default: ``[165, 180, 195]``

  List of wave directions to consider.

  **Limits:**

  - **Minimum:** :math:`>0`
  - **Maximum:** :math:`360`

.. confval:: min_seeds
  :type: integer
  :default: ``50``

  Minimum number of seeds to run for each H\ :sub:`s`\/Period combination.

  **Limits:**

  - **Minimum:** :math:`11`
  - **Maximum:** :math:`1000`

.. confval:: seed_random_generator
  :type: integer
  :default: ``12343``

  Random seed to use for the random number generator. This is used to ensure
  that the same seeds are used for each run.  There is no maximum or minimum
  value but it must be an integer.

.. confval:: alpha_factor
  :type: float
  :default: ``1.0``

  DNV Alpha factor in accordance with DNV-ST-N001 :cite:`DNV-ST-N001` to reduce
  H\ :sub:`s`\  depending on forecasting capibilities and operation duration.

  **Limits:**

  - **Minimum:** :math:`>0` though the lowest value in DNV is 0.49.
  - **Maximum:** :math:`1`

.. confval:: run_method
  :type: string
  :default: ``"dof"``

  Selects the method of analysis.

  Valid values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``dof``
      -  Distributed Orcaflex (default) 
    * - ``hpcflex``
      - TechnipFMC HPC-Flex system.
    * - ``local``
      - Local system.  The number of processors used is the maximum of 1,
        the number of yml files to be run and one less than the number of
        available processors.

.. confval:: extra_files
  :type: list of strings
  :default: ``[]``

  List of extra files to be copied to the runs folder. This is used to copy any
  additional files needed for the simulation.  Valid file types are
  :file:`*.dll`, :file:`*.inc`, :file:`*.his` and :file:`*.py`

.. confval:: ks_test_criteria
  :type: float
  :default: ``0.05``

  The significance level (α) for the Kolmogorov-Smirnov (KS) test, determining
  the p-value threshold to reject the null hypothesis (that two distributions
  are the same). A p-value below this value indicates significant differences
  between distributions. The default of 0.05 is a standard statistical
  convention.

  Only the following values are accepted:

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``0.15``
      - 15% significance level
    * - ``0.10``
      - 10% significance level
    * - ``0.05``
      - 5% significance level (default)
    * - ``0.025``
      - 2.5% significance level
    * - ``0.01``
      - 1% significance level



.. confval:: ad_test_criteria
  :type: float
  :default: ``0.05``

  The significance level (α) for the Anderson-Darling (AD) test, setting the
  threshold to reject the null hypothesis (that a sample follows a specified
  distribution). The default of 0.05 is a standard statistical convention.

  Due to the fixed critical values returned by the AD test implementation,
  only the following values are accepted:

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``0.15``
      - 15% significance level
    * - ``0.10``
      - 10% significance level
    * - ``0.05``
      - 5% significance level (default)
    * - ``0.025``
      - 2.5% significance level
    * - ``0.01``
      - 1% significance level

.. confval:: force_skip_sim_file_save
  :type:  boolean
  :default: ``True``

  Identifies if the :file:`*.sim` file is saved.

  Valid values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``True``
      - Do not save simulation files
    * - ``False``
      - Save simulation files in runs folder.

.. confval:: automatic_post_calc
  :type:  boolean
  :default: ``True``

  Identifies if RLC automatically creates the post calculation action python
  file.  It is highly recommended that this be left as ``True`` as  the output
  needs to exactly fit the expected :file:`*.json` format.

  Valid values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``True``
      - Creates the auto_post_calc_action.py file automatically
    * - ``False``
      - User defines their own post calculation file

.. confval:: num_bootstraps
  :type:  integer
  :default: ``10000``

  Number of bootstrap samples to perform.  This number must be greater than
  1000.

  **Limits:**
  
    - **Minimum:** :math:`1000`
    - **Maximum:** :math:`1000000`

.. confval:: conf_interval
  :type:  float
  :default: ``0.95``

  Number that provides the confidence interval for the
  bootstrapping.  For ``min`` cases, it will take the lower confidence
  interval.  For ``max`` cases it will take the upper confidence interval.

  **Limits:**

    - **Minimum:** :math:`0`
    - **Maximum:** :math:`1`

.. confval:: max_bisections
  :type:  integer
  :default: ``0``

  Maximum number of bisections to perform if a specific seed ``*.yml`` file has
  failed.  A bisection, cuts the time step in half and reruns the analysis.
  This parameter reflects the number of times the time step will be cut in
  half.  If there are still failed filed after the ``max_bisections`` have been
  performed, the case is considered NG and the H\ :sub:`s`\  is reduced if
  possible.

  When an individual seed fails (i.e. unstability) RLC will create a
  failed ``Hsx.xx_Txx.xx_WDxxx_seedx_failed.json`` file for that seed with the
  error.  Upon a rerun of RLC, this will ensure RLC doesn't attempt to rerun
  the same failed seed.

  **Limits:**

    - **Minimum:** :math:`0`
    - **Maximum:** :math:`5`

.. confval:: zero_wave_timeout
  :type:  integer
  :default: ``600``

  Maximum time that the program will wait for the zero wave analysis (run on
  the local machine) takes to complete.

  **Limits:**

    - **Minimum:** :math:`1`
    - **Maximum:** No Limit

.. confval:: email_on_failure
  :type:  boolean
  :default: ``False``

  Identifies if RLC sends an email if a single file has failed during the run.

  Valid values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``True``
      - Sends email
    * - ``False``
      - Does not send email

.. confval:: email_on_loop
  :type:  boolean
  :default: ``False``

  Identifies if RLC sends an email each time the script assess all cases for
  the next phase of analysis.

  Valid values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``True``
      - Sends email
    * - ``False``
      - Does not send email

.. confval:: email_on_finish
  :type:  boolean
  :default: ``False``

  Identifies if RLC sends an email when the script has completed running.

  Valid values are shown below.

  .. list-table::
    :header-rows: 1

    * - Value
      - Description
    * - ``True``
      - Sends email
    * - ``False``
      - Does not send email

.. confval:: path_orcfx_dll
  :type:  string
  :default: N/A

  Path to the OrcaFlex DLL file.  This is only needed if the script is run on a
  Distributed Orcaflex system.
