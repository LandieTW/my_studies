# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = "Repeated Lowering Control (RLC)"
copyright = "2026, TechnipFMC"
author = "Andrew Blundon"

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = []

templates_path = ["_templates"]
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]


# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = "sphinx_rtd_theme"
html_static_path = ["_static"]

numfig = True

source_suffix = {
    ".rst": "restructuredtext",
    ".md": "markdown",
}

# Required for In Line Equation Numbering
extensions = [
    "sphinx.ext.mathjax",
    "sphinxcontrib.bibtex",
    "sphinx_copybutton",
    "myst_parser",
]

html_css_files = [
    "custom.css",
]

mathjax3_config = {
    "tex": {
        "inlineMath": [["$", "$"], ["\\(", "\\)"]],
        "displayMath": [["$$", "$$"], ["\\[", "\\]"]],
        "processEscapes": True,
        "tags": "ams",
        "tagSide": "right",
        "tagIndent": "0.8em",
    },
    "options": {
        "skipHtmlTags": ["script", "noscript", "style", "textarea", "pre"],
        "ignoreHtmlClass": "tex2jax_ignore",
    },
}

bibtex_bibfiles = ["references.bib"]
