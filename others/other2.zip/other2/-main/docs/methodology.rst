.. _methodology:

###########
Methodology
###########

.. contents::
   :local:
   :depth: 2

Introduction
************

The continual lowering/hoisting analysis is the preferred method performing
lifting analysis from a floating vessel to and from subsea.  It utilizes time
domain analysis as it takes into consideration the lowering / hoisting speed of
the crane in addition the irregular nature of ocean waves.  This method depends
upon running a number of irregular wave simulations (each using a different
wave train) to obtain a statistical distribution of the maximum and minimum
dynamic load (or other parameter) and then use statistical methods to determine
the load (or parameter) at a specified probability value.  For example, the
load that has a 10% probability of non-exceedance can be calculated.

Acceptance Criteria
*******************

The goal of a lifting analysis is to determine the acceptable sea states in
which a lift can be performed.  To assess that, various result parameters are
calculated and compared against specific acceptance criteria.  Generally, this
includes crane and sling loads but can include other parameters such as crane
wire declination, connection force, etc.  Essentially, any parameter that is
available in the Orcaflex results window can be used.

For each parameter, acceptance criterion needs to be
defined.  The acceptance criteria is a key component to
performing a lifting analysis using the RLC script.  The
analysis is performed for multiple significant wave
heights (H\ :sub:`s`\) and wave periods
(T\ :sub:`p`\/T\ :sub:`z`).  For a given
H\ :sub:`s`\ and period combination, all acceptance
criteria must be met.  If one is not met, that sea state
is not suitable for installation.

In general, guidance for this methodology is taken from
DNV-ST-N001 :cite:`DNV-ST-N001`, however, the guidance
provided is limited.  Section 16.17.3.3 of
DNV-ST-N001 :cite:`DNV-ST-N001` states:

.. epigraph::
    *“The probability of exceeding the calculated extreme characteristic load
    (hydrodynamic + static load or snap load) in the operation period shall not
    exceed 10%.”*

In other words, the load that has a 1/10 probability of being exceeded.  This
load may be used to determine the acceptability of the lifting appliance.

To help engineers interpret the DNV requirements,
TechnipFMC have prepared
OED-TGR-272 Part B :cite:`OED-TGR-272_Part_B`.
This document provides the acceptance for many of
the components including the crane load.

As indicated above, DNV requires that load that has a 10% probability of
exceedance be calculated.   However, many crane systems have alarms built in to
warn the Crane Operator of high loads.  If the load for comparison against the
acceptance criteria had a 1/10 probability of being exceeded, the crane alarms
would likely be set off frequently.

Therefore, the dynamic load which has a 99% probability of non-exceedance will
be selected for checking the crane capacity as referenced in OED-TGR-272 Part B
:cite:`OED-TGR-272_Part_B`.

Other probability criteria are also listed in
OED-TGR-272 Part B :cite:`OED-TGR-272_Part_B`.

Statistical Analysis
********************

Generation of Statistical Sample Data
=====================================

The lowering/hoisting analysis is performed at each
H\ :sub:`s`\, T\ :sub:`p`\/T\ :sub:`z` and heading
numerous times, each time using a different wave train.
This process involves defining a seed within Orcaflex
(which is automatically determined by the RLC script).

By performing multiple simulations using different seeds, a statistical
distribution of the maximum and minimum loads (or other parameters) can be
developed.  The more analysis cases performed (i.e. the more seeds analyzed)
the more data available to determine the distribution parameters.

This method will result in the requirement to perform thousands of simulations.
This process can be quite time consuming.  This is essentially the purpose of
RLC, to automate this process.

Statistical Distribution Analysis
=================================

The Gumbel distribution is a particular case of the Generalized Extreme Value
distribution (Fisher-Tippett).  This type of statistical distribution is found
to be applicable if the distribution of the sample data is of a normal or
exponential type and is commonly used to model the distribution of maxima or
minima of random variables, usually related to extreme events such as rainfall
or earthquakes.

The Gumbel distribution can be used to determine the probability associated
with maximums and minimums of a parameter.

.. math::
   :label: eq:PDFGumbelMax

   PDF_{GumbelMax}(x)=\frac{1}{\beta}e^{-\left(
   \frac{x-\mu}{\beta}+e^{-(\frac{x-\mu}{\beta})} \right)}

.. math::
   :label: eq:CDFGumbelMax

   CDF_{GumbelMax}(x)=e^{-e^{-\left( \frac{x-\mu}{\beta} \right)}}

.. math::
   :label: eq:PDFGumbelMin

   PDF_{GumbelMin}(x)=\frac{1}{\beta}e^{\left(
   \frac{x-\mu}{\beta}+e^{(\frac{x-\mu}{\beta})} \right)}

.. math::
   :label: eq:CDFGumbelMin

   CDF_{GumbelMin}(x)=1-e^{-e^{\left( \frac{x-\mu}{\beta} \right)}}

Where:

=============   =======
PDF             Probability Density function
CDF             Cumulative Density Function
x               Variable (i.e. load)
:math:`\beta`   Scale parameter (>0)
:math:`\mu`     Location parameter
=============   =======

The general maximum Gumbel distribution probability density and cumulative
distribution functions are shown in :numref:`Figure %s <figure-MaxGumbel>`.

.. _figure-MaxGumbel:

.. figure:: images/MaxGumbelDistribution.jpg
   :alt: Maximum Gumbel Distribution
   :width: 500px
   :align: center

   Maximum Gumbel Distribution

The general minimum Gumbel distribution probability density and cumulative
distribution functions are shown in :numref:`Figure %s <figure-MinGumbel>`.

.. _figure-MinGumbel:

.. figure:: images/MinGumbelDistribution.jpg
   :alt: Minimum Gumbel Distribution
   :width: 500px
   :align: center

   Minimum Gumbel Distribution

It can be noted that Cumulative Density Functions (CDFs) are simply a double
exponential functions.  By rearranging and taking the double natural log the
CDFs the equations can be rewritten.

The maximum and minimum probabilistic values of the chosen parameter can be
determined:

.. math::
   :label: eq:ParameterGumbelMax

   Parameter_{GumbelMax}(p)=\mu-\beta \cdot ln\left( -ln(p) \right)

.. math::
   :label: eq:ParameterGumbelMin

   Parameter_{GumbelMin}(p)=\mu+\beta \cdot ln\left( -ln(1-p) \right)

Where:

=========  ==========================================
Parameter  Dynamic Hook Load (Maximum or Minimum)
           with a probability of non-exceedance
           of "p"
p          Non-exceedance probability
=========  ==========================================

These relationships can be used for any parameter of interest (i.e. sling
force, crane wire angle, passive heave compensator stroke, etc.).

These formulae are in the form:

.. math::
   :label: eq:mxb

   y=mx+b

and can therefore be plotted as a straight line.

DNV-RP-N103 :cite:`DNV-RP-N103` states:

.. epigraph::
    *“If a continuous lowering of the object is simulated a large number of
    realizations is required in order to obtain a proper statistical
    confidence.”*

It is recommended to use at least 30 different wave trains to obtain enough
statistical information to reliably predict the maximum / minimum loads.
Therefore, for each H\ :sub:`s`\, period and heading combination, 30 different
analyses are performed, as a minimum.  The maximum and minimum dynamic load is
recorded for each analysis.

.. _figure-TimeHistoryPlot:

.. figure:: images/TimeHistoryPlot.jpg
   :alt: Time History Plot
   :width: 500px
   :align: center

   Typical Time History Plot of a Parameter (i.e. Crane Wire Tension)

Given a sample set of 30 data points, the Gumbel distribution parameters can be
estimated using the built in functions in the python scipy library.

``scipy.stats.gumbel_r`` calculates the ``loc`` and ``scale`` parameters for a
given data set where maximum extreme values are required.

``scipy.stats.gumbel_l`` calculates the ``loc`` and ``scale`` parameters for a
given data set where minimum extreme values are required.

These Scipy :cite:`2020SciPy-NMeth` functions are built into RLC and is
selected automatically based on the defined ``mode`` parameter in each
``analysis_criteria`` specified.

Fit Tests
---------

Prior to using the calculated Gumbel parameters to determine the probabilistic
values, it is important to ensure that the data is a good fit for calculated
fit parameters for a Gumbel distribution.  Two statistical fit tests are
implemented to ensure that the data could have come from the calculated
distribution.

Kolomogorov-Smirnov Test
^^^^^^^^^^^^^^^^^^^^^^^^

The Kolmogorov–Smirnov (KS) test is a non-parametric method used to determine
whether a sample comes  from a specific distribution (one-sample test) or
whether two samples come from the same distribution (two-sample test). It works
by comparing the cumulative distribution functions (CDFs) of the sample(s) and
calculating the maximum absolute difference between them, known as the KS
statistic. This value reflects how far apart the distributions are, with larger
values indicating greater divergence. The KS test is especially useful because
it does not assume any particular distribution shape and is sensitive to
differences in both location and shape, making it a versatile tool for
assessing goodness-of-fit or distributional similarity, particularly for
continuous data.

Python's ``Scipy`` has functions built in to perform the KS test on data.  The
user can define the KS test significance level (α), however, a typical value of
0.05 is assumed by default.

For each dataset, a KS test is performed versus the calculated Gumbel
distribution. If the KS test statistic is greater than the critical value
corresponding to the chosen significance level (commonly 0.05), the null
hypothesis — that the dataset follows the Gumbel distribution — is rejected.
This indicates that the observed data significantly deviates from the expected
Gumbel distribution, suggesting a poor fit. Conversely, if the KS statistic is
less than or equal to the critical value, the fit is considered statistically
acceptable.

If the data is a poor fit the Gumbel distribution should not be used to
determine probabilistic values.

Anderson-Darling
^^^^^^^^^^^^^^^^

Similarly, the Anderson–Darling (AD) test is a statistical test used to
evaluate whether a given sample of data follows a specific probability
distribution. Like the Kolmogorov–Smirnov test, it compares the empirical
cumulative distribution function (CDF) of the sample to the theoretical CDF of
the target distribution, but the AD test places more emphasis on the tails of
the distribution, making it more sensitive to deviations in those regions.

``Scipy`` has functions built in to perform the AD test on data.  The user can
define the AD test p-value, however, a typical value of 0.05 is assumed by
default.

The test produces a statistic that reflects the degree of discrepancy between
the sample and the theoretical distribution, and this value is compared against
critical values to determine significance. A small p-value (typically less than
0.05) indicates that the sample does not follow the specified distribution,
leading to rejection of the null hypothesis. The AD test is especially useful
when assessing goodness-of-fit for distributions where tail behavior is
important, such as in reliability analysis or extreme value modeling.

If the data is a poor fit the Gumbel distribution should not be used to
determine probabilistic values.

Empirical Statistical Evaluation
--------------------------------

If either the KS or the AD tests fail, then the Gumbel distribution is not
suitable to determine probabilistic values. Therefore, in those cases, the
empirical or sample method is used. This approach relies directly on the
observed data without assuming any underlying theoretical distribution.
Probabilities are estimated by ranking the data and calculating exceedance
frequencies based on their position within the sorted dataset. For example, the
empirical cumulative distribution function (ECDF) can be used to determine the
probability of a value being exceeded, making this method especially useful
when the dataset is large and representative, or when distributional
assumptions are unreliable.

When using the empirical method, the number of seeds is critical.  It is
impossible to accurately determine a value with a 1% probability of exceedance
if only 10 seeds were run.  In general, the required number of seeds can be
estimated from the requested probability level.

.. math::
   :label: eq:no_seeds

   n=1/(1-p)

For a 99% probability level, at least 100 seeds are required.

If the number of seeds run is less than the required number of seeds based on
the required probability level **AND** both the KS and AD tests fail, RLC must
run more seeds for that case to be able to determine probabilistic values
empirically.

If the empirical statistical evaluation is performed, the data goes through a
bootstrapping procedure to estimate uncertainty and improve the reliability of
probabilistic values. Bootstrapping involves repeatedly resampling the
available data with replacement to generate many synthetic datasets, known as
bootstrap samples. For each sample, the desired statistic (e.g., exceedance
probability) is recalculated, producing a distribution of estimates. This
allows for the construction of confidence intervals and quantification of
variability, even when the original dataset is limited. Bootstrapping is
especially valuable when theoretical assumptions are invalid or when the number
of seeds is insufficient for direct inference.

RLC requires at least 1000 bootstrap samples but calculates 10000 by default
using the functions built into `Scipy` :cite:`2020SciPy-NMeth`.  This value can
be adjusted using the ``num_bootstraps`` key in the input file.

When all of the bootstrap samples have been created, RLC will determine the
probabilistic value with an associated upper or lower confidence interval.  By
default a 95% confidence interval is used but this value can be modified using
the ``conf_interval`` key in the input file.  For maximum cases, it will
calculate the upper confidence interval.  For minimum cases, it will calculate
the lower confidence interval.

Maximum Value Example
---------------------

A typical distribution of the maximum load from 50 data seeds vs. the best fit
Gumbel distribution is shown in
:numref:`Figure %s <figure-MaxSampleHistogram>`.

.. _figure-MaxSampleHistogram:

.. figure:: images/MaxSampleHistogram.jpg
   :alt: Maximum Sample Histogram
   :width: 500px
   :align: center

   Maximum Sample Histogram with Gumbel Curve Fit

   .. Reference data_sources, Sling1 Max, Hs=3, T=12, Dir=180

The linear regression of the sample data in
:numref:`Figure %s <figure-MaxSampleHistogram>` is shown
in :numref:`Figure %s <figure-SampleRegressionMax>`.

.. _figure-SampleRegressionMax:

.. figure:: images/SampleRegressionMax.jpg
   :alt: Linear Regression
   :width: 500px
   :align: center

   Linear Regression of Sample Data
   (:math:`\beta = 1.68`; :math:`\mu = 102.25`)

The first step is to perform the KS and the AD test.  The KS test provides a
measure of how likely the data comes from a population that has a Gumbel
distribution.  It looks for the largest vertical separation between the
empicial CDF and the Gumbel CDF (:numref:`Figure %s <figure-KSAD_test_max>`).

.. _figure-KSAD_test_max:

.. figure:: images/KSAD_test_max.jpg
   :alt: CDF Gumbel Data
   :width: 500px
   :align: center

   Cumulative Distribution Function for Data (Maximum)

The KS test compares the dataset to a Gumbel distribution and, in this case,
returns a statistic of 0.0999. At the 0.05 significance level, the critical
value is 0.1923. Since the KS statistic is lower than this threshold, the test
passes, meaning there's no significant difference between the data and the
Gumbel distribution. The high p-value of 0.700, in this case, further confirms
a good fit.

The AD test provides a measure of how likely the data comes from a population
that has a Gumbel distribution, but it focuses more on the tails. In this case,
the (AD) test results show an adjusted statistic of 0.6012, which is compared
against critical values at various significance levels. At the 0.05 level, the
critical value is 0.757. Since the adjusted AD statistic is less than this
threshold, the test does not reject the null hypothesis, meaning the data is
considered a statistically acceptable fit to the Gumbel distribution. The
p-value of 0.133 supports this conclusion, indicating no significant deviation
between the sample and the theoretical distribution.

Since both the KS and AD test pass, the calculated Gumbel distribution
``scale`` and ``loc`` parameters can be used to estimate probabilistic values.

Assuming this data represents the crane load we can use this for checking the
crane capacity, using the sample data above, one can determine the load that
has a 1/100 probability of occurring (i.e. 99% non-exceedance probability):

.. math::
   :label: eq:DHLGumbelMaxSample

   DHL_{GumbelMax}(0.99)=102.25-1.68 \cdot ln\left( -ln(0.99) \right)

.. math::
   :label: eq:DHLGumbelMaxSampleResult
   
   DHL_{GumbelMax}(0.99)=110.0 kN

In other words, in this example, there is a 1% chance that the maximum load
during the operation will exceed 110.0 kN.

Minimum Value Example
---------------------

A typical distribution of the minimum load from 50 data seeds vs. the best fit
Gumbel distribution is shown in
:numref:`Figure %s <figure-MinSampleHistogram>`.

.. _figure-MinSampleHistogram:

.. figure:: images/MinSampleHistogram.jpg
   :alt: Minimum Sample Histogram
   :width: 500px
   :align: center

   Minimum Sample Histogram with Gumbel Curve Fit

   .. Reference data_sources, CraneHook Min, Hs=3, T=5, Dir=165

The linear regression of the sample data in
:numref:`Figure %s <figure-MinSampleHistogram>` is shown
in :numref:`Figure %s <figure-SampleRegressionMin>`.

.. _figure-SampleRegressionMin:

.. figure:: images/SampleRegressionMin.jpg
   :alt: Linear Regression
   :width: 500px
   :align: center

   Linear Regression of Sample Data (:math:`\beta = 33.9`; :math:`\mu = 175.7`)

Again, the first step is to perform the KS and the AD test which can be
visualized in the CDF plot (:numref:`Figure %s <figure-KSAD_test_min>`).

.. _figure-KSAD_test_min:

.. figure:: images/KSAD_test_min.jpg
   :alt: CDF Gumbel Data
   :width: 500px
   :align: center

   Cumulative Distribution Function for Data (Minimum)

In this case, the KS test returns a statistic of 0.1201. At the 0.05
significance level, the critical value is 0.1923. Since the KS statistic is
lower than this threshold, the test passes, meaning there's no significant
difference between the data and the Gumbel distribution. The high p-value of
0.467, in this case, further confirms a good fit.

The (AD) test results show an adjusted statistic of 0.9272, which is compared
against critical values at various significance levels. At the 0.05 level, the
critical value is 0.757. Since the adjusted AD statistic is **greater** than
this threshold, the test does reject the null hypothesis, meaning the data is
**not** considered a statistically acceptable fit to the Gumbel distribution.
The p-value of 0.02 supports this conclusion, indicating a significant
deviation between the sample and the theoretical distribution.

Since the AD test fails, the empirical method must be used to determine
probabilistic values.

Assuming this data represents the minimum crane load we can use this for
checking slack lines in the crane.  Using the sample data above, one can
determine the load that has a 1/10 probability of occurring (i.e. 90% non-
exceedance probability):

For this case, the after bootstrapping the data, the lower 95% confidence level
is taken to be 30.3 kN.

In other words, in this example, there is a 10% chance that the minimum load
during the operation will fall below 30.3 kN.

Determining the Number of Seeds
=============================== 

:numref:`Figure %s <figure-50Seeds>` shows the effect that
the number of seeds analyzed has on the analysis.  A number
of different structures, headings and zero-up-crossing
periods were evaluated.  It is clear that with only 10 seeds
evaluated a large error will be present in the results,
however, as the number of seeds is increased, the resulting
error decreases quickly.  Based on this, 50 seeds are the
recommended as a starting point.  If the data does not fit
the calculated distribution well and if the required
probability levels are larger than 0.98 then additional
seeds will be run automatically by RLC.

.. _figure-50Seeds:

.. figure:: images/50Seeds.jpg
   :alt: Effect of Number of Seeds
   :width: 500px
   :align: center

   Effect of Number of Seeds

For information, TechnipFMC in Norway also performed testing to determine the
effect of the number of seeds analyzed :cite:`NR099910-004-10001`.

.. _figure-NorwaySeeds:

.. figure:: images/NorwayEffectofSeeds.jpg
   :alt: Effect of Number of Seeds (Norway)
   :width: 500px
   :align: center

   Effect of Number of Seeds (Norway)

Based on this analysis, the following conclusions were made:

- For a 90% probability level of confidence (respectively 99.99%) and using
  only 10 realizations, the average error is below 1.5% (respectively 3%)
  whereas the maximum error in the 5 samples is close to 8% (respectively 16%).

- For a 90% probability level of confidence (respectively 99.99%) and using
  only 25 realizations, the average error is below 1.0% (respectively 1.5%)
  whereas the maximum error in the 5 samples is close to 6% (respectively 13%).

- For a 90% probability level of confidence (respectively 99.99%) and using
  only 50 realizations, the average error is below 0.5% (respectively 1.0%)
  whereas the maximum error in the 5 samples is close to 3% (respectively 8%).

- For a 90% probability level of confidence (respectively 99.99%) and using
  only 100 realizations, the average error is below 0.2% (respectively 0.5%)
  whereas the maximum error in the 5 samples is close to 0.5% (respectively
  2%).