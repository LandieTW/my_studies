.. _orcaflex-parameters:

###################
OrcaFlex Parameters
###################

.. contents::
   :local:
   :depth: 2

Overview
********
This page lists all available OrcaFlex result parameters grouped by object
type. Use these when specifying ``orcaflex_object_parameter`` in your input
file.

.. _orcaflex-parameters-6d-buoy:

6D Buoy Parameters
******************

The following parameters are valid for 6D buoy objects:

.. rubric:: Allowed Parameters

``X``, ``Y``, ``Z``, ``Dynamic x``, ``Dynamic y``, ``Dynamic z``,
``Rotation 1``, ``Rotation 2``, ``Rotation 3``, ``Azimuth``, ``Declination``,
``Dynamic Rx``, ``Dynamic Ry``, ``Dynamic Rz``, ``Velocity``, ``GX velocity``,
``GY velocity``, ``GZ velocity``, ``x velocity``, ``y velocity``, ``z
velocity``, ``Angular velocity``, ``x angular velocity``, ``y angular
velocity``, ``z angular velocity``, ``Acceleration``, ``GX acceleration``, ``GY
acceleration``, ``GZ acceleration``, ``x acceleration``, ``y acceleration``,
``z acceleration``, ``Acceleration rel. g``, ``x acceleration rel. g``, ``y
acceleration rel. g``, ``z acceleration rel. g``, ``Angular acceleration``, ``x
angular acceleration``, ``y angular acceleration``, ``z angular acceleration``,
``Dry length``, ``Sea surface Z``, ``Sea surface clearance``, ``Sea velocity``,
``Sea X velocity``, ``Sea Y velocity``, ``Sea Z velocity``, ``Sea
acceleration``, ``Sea X acceleration``, ``Sea Y acceleration``, ``Sea Z
acceleration``, ``Connection force``, ``Connection x force``, ``Connection y
force``, ``Connection z force``, ``Connection moment``, ``Connection x
moment``, ``Connection y moment``, ``Connection z moment``

.. _orcaflex-parameters-constraint:

Constraint Parameters
*********************

Allowed parameters for constraint objects:

.. rubric:: Allowed Parameters

``Displacement``, ``x``, ``y``, ``z``, ``Angular displacement``, ``Rx``,
``Ry``, ``Rz``, ``Velocity``, ``x velocity``, ``y velocity``, ``z velocity``,
``Angular velocity``, ``x angular velocity``, ``y angular velocity``, ``z
angular velocity``, ``Acceleration``, ``x acceleration``, ``y acceleration``,
``z acceleration``, ``Angular acceleration``, ``x angular acceleration``, ``y
angular acceleration``, ``z angular acceleration``, ``In-frame X``, ``In-frame
Y``, ``In-frame Z``, ``In-frame dynamic x``, ``In-frame dynamic y``, ``In-frame
dynamic z``, ``In-frame azimuth``, ``In-frame declination``, ``In-frame
gamma``, ``In-frame dynamic Rx``, ``In-frame dynamic Ry``, ``In-frame dynamic
Rz``, ``In-frame velocity``, ``In-frame GX velocity``, ``In-frame GY
velocity``, ``In-frame GZ velocity``, ``In-frame x velocity``, ``In-frame y
velocity``, ``In-frame z velocity``, ``In-frame angular velocity``, ``In-frame
x angular velocity``, ``In-frame y angular velocity``, ``In-frame z angular
velocity``, ``In-frame acceleration``, ``In-frame GX acceleration``, ``In-frame
GY acceleration``, ``In-frame GZ acceleration``, ``In-frame x acceleration``,
``In-frame y acceleration``, ``In-frame z acceleration``, ``In-frame angular
acceleration``, ``In-frame x angular acceleration``, ``In-frame y angular
acceleration``, ``In-frame z angular acceleration``, ``In-frame connection
force``, ``In-frame connection GX force``, ``In-frame connection GY force``,
``In-frame connection GZ force``, ``In-frame connection Lx force``, ``In-frame
connection Ly force``, ``In-frame connection Lz force``, ``In-frame connection
moment``, ``In-frame connection GX moment``, ``In-frame connection GY moment``,
``In-frame connection GZ moment``, ``In-frame connection Lx moment``, ``In-
frame connection Ly moment``, ``In-frame connection Lz moment``, ``Out-frame
X``, ``Out-frame Y``, ``Out-frame Z``, ``Out-frame dynamic x``, ``Out-frame
dynamic y``, ``Out-frame dynamic z``, ``Out-frame azimuth``, ``Out-frame
declination``, ``Out-frame gamma``, ``Out-frame dynamic Rx``, ``Out-frame
dynamic Ry``, ``Out-frame dynamic Rz``, ``Out-frame velocity``, ``Out-frame GX
velocity``, ``Out-frame GY velocity``, ``Out-frame GZ velocity``, ``Out-frame x
velocity``, ``Out-frame y velocity``, ``Out-frame z velocity``, ``Out-frame
angular velocity``, ``Out-frame x angular velocity``, ``Out-frame y angular
velocity``, ``Out-frame z angular velocity``, ``Out-frame acceleration``,
``Out-frame GX acceleration``, ``Out-frame GY acceleration``, ``Out-frame GZ
acceleration``, ``Out-frame x acceleration``, ``Out-frame y acceleration``,
``Out-frame z acceleration``, ``Out-frame angular acceleration``, ``Out-frame x
angular acceleration``, ``Out-frame y angular acceleration``, ``Out-frame z
angular acceleration``, ``Out-frame connection force``, ``Out-frame connection
GX force``, ``Out-frame connection GY force``, ``Out-frame connection GZ
force``, ``Out-frame connection Lx force``, ``Out-frame connection Ly force``,
``Out-frame connection Lz force``, ``Out-frame connection moment``, ``Out-frame
connection GX moment``, ``Out-frame connection GY moment``, ``Out-frame
connection GZ moment``, ``Out-frame connection Lx moment``, ``Out-frame
connection Ly moment``, ``Out-frame connection Lz moment``

.. _orcaflex-parameters-line:

Line Parameters
***************

Allowed parameters for line objects:

.. rubric:: Allowed Parameters

``End force``, ``End moment``, ``End force Ez angle``, ``End force Exy angle``,
``End force Ezx angle``, ``End force Ezy angle``, ``End force azimuth``,
``End force declination``, ``No moment azimuth``, ``No moment declination``,
``End Ex force``, ``End Ey force``, ``End Ez force``, ``End Ex moment``,
``End Ey moment``, ``End Ez moment``, ``End Lx force``, ``End Ly force``,
``End Lz force``, ``End Lx moment``, ``End Ly moment``, ``End Lz moment``,
``End GX force``, ``End GY force``, ``End GZ force``, ``End GX moment``,
``End GY moment``, ``End GZ moment``, ``X``, ``Y``, ``Z``, ``Dynamic x``,
``Dynamic y``, ``Dynamic z``, ``Azimuth``, ``Declination``, ``Gamma``,
``Twist``, ``Node azimuth``, ``Node declination``, ``Node gamma``,
``Layback``, ``Velocity``, ``GX velocity``, ``GY velocity``, ``GZ velocity``,
``x velocity``, ``y velocity``, ``z velocity``, ``Acceleration``,
``GX acceleration``, ``GY acceleration``, ``GZ acceleration``,
``x acceleration``, ``y acceleration``, ``z acceleration``,
``Acceleration rel. g``, ``x acceleration rel. g``, ``y acceleration rel. g``,
``z acceleration rel. g``, ``Effective tension``, ``Wall tension``,
``Normalised tension``, ``Sidewall pressure``, ``Total mean axial strain``,
``Direct tensile strain``, ``Max bending strain``,
``Max pipelay von Mises strain``, ``Worst ZZ strain``, ``ZZ strain``,
``Contents density``, ``Contents temperature``, ``Contents pressure``,
``Contents flow rate``, ``Contents flow velocity``, ``Fluid incidence angle``,
``Bend moment``, ``x bend moment``, ``y bend moment``,
``Bend moment component``, ``In plane bend moment``,
``Out of plane bend moment``, ``Curvature``, ``Normalised curvature``,
``x curvature``, ``y curvature``, ``Curvature component``,
``In plane curvature``, ``Out of plane curvature``, ``Bend radius``,
``x bend radius``, ``y bend radius``, ``Bend radius component``,
``In plane bend radius``, ``Out of plane bend radius``, ``Shear force``,
``x shear force``, ``y shear force``, ``Shear force component``,
``In plane shear force``, ``Out of plane shear force``,
``Max von Mises stress``, ``Bending stress``, ``Max bending stress``,
``Pm``, ``Pb``, ``Worst ZZ stress``, ``Direct tensile stress``,
``Worst hoop stress``, ``Max xy shear stress``, ``Internal pressure``,
``External pressure``, ``Net internal pressure``, ``von Mises stress``,
``RR stress``, ``CC stress``, ``ZZ stress``, ``RC stress``, ``RZ stress``,
``CZ stress``, ``API RP 2RD stress``, ``API RP 2RD utilisation``,
``API STD 2RD method 1``, ``API STD 2RD method 2``, ``API RP 1111 LLD``,
``API RP 1111 CLD``, ``API RP 1111 BEP``, ``API RP 1111 max combined``,
``DNV OS F101 disp. controlled``, ``DNV OS F101 load controlled``,
``DNV ST F101 disp. controlled``, ``DNV ST F101 load controlled``,
``DNV ST F101 simplified strain``, ``DNV ST F101 simplified stress``,
``DNV ST F101 tension utilisation``, ``DNV OS F201 LRFD``, ``DNV OS F201 WSD``,
``PD 8010 allowable stress check``, ``PD 8010 axial compression check``,
``PD 8010 bending check``, ``PD 8010 torsion check``,
``PD 8010 load combinations check``, ``PD 8010 bending strain check``,
``Line clearance``, ``Line centreline clearance``,
``Line horizontal centreline clearance``, ``Line vertical centreline
clearance``, ``Whole line clearance``, ``Whole line centreline clearance``,
``Whole line horizontal centreline clearance``, ``Whole line vertical
centreline clearance``, ``Seabed clearance``, ``Vertical seabed clearance``,
``Line clash force``, ``Line clash impulse``, ``Line clash energy``, ``Solid
contact force``, ``Seabed normal penetration/D``, ``Seabed normal resistance``,
``Seabed normal resistance/D``, ``Arc length``, ``Expansion factor``, ``Ez
angle``, ``Exy angle``, ``Ezx angle``, ``Ezy angle``, ``Relative velocity``,
``Normal relative velocity``, ``x relative velocity``, ``y relative velocity``,
``z relative velocity``, ``Strouhal frequency``, ``Reynolds number``, ``x drag
coefficient``, ``y drag coefficient``, ``z drag coefficient``, ``Lift
coefficient``, ``Drag force``, ``Normal drag force``, ``x drag force``, ``y
drag force``, ``z drag force``, ``Lift force``, ``Fluid inertia force``, ``x
fluid inertia force``, ``y fluid inertia force``, ``z fluid inertia force``,
``Morison force``, ``Normal Morison force``, ``x Morison force``, ``y Morison
force``, ``z Morison force``, ``Sea surface Z``, ``Depth``, ``Sea surface
clearance``, ``Proportion wet``, ``Sea velocity``, ``Sea X velocity``, ``Sea Y
velocity``, ``Sea Z velocity``, ``Sea acceleration``, ``Sea X acceleration``,
``Sea Y acceleration``, ``Sea Z acceleration``

.. _orcaflex-parameters-link:

Link Parameters
***************

Allowed parameters for link objects:

.. rubric:: Allowed Parameters

``Tension``, ``Length``, ``Velocity``, ``Azimuth``, ``Declination``,
``End A X``, ``End A Y``, ``End A Z``, ``End B X``, ``End B Y``, ``End B Z``

.. _orcaflex-parameters-winch:

Winch Parameters
****************

Allowed parameters for winch objects:

.. rubric:: Allowed Parameters

``X``, ``Y``, ``Z``, ``Tension``, ``Length``, ``Stretched length``,
``Velocity``, ``Azimuth``, ``Declination``,
``Connection force``, ``Connection GX force``, ``Connection GY force``,
``Connection GZ force``, ``Connection Lx force``, ``Connection Ly force``,
``Connection Lz force``

.. _orcaflex-parameters-shape:

Shape Parameters
****************

Allowed parameters for shape objects:

.. rubric:: Allowed Parameters

``Contact force``, ``Contact GX force``, ``Contact GY force``, ``Contact GZ
force``, ``Contact Lx force``, ``Contact Ly force``, ``Contact Lz force``,
``X``, ``Y``, ``Z``, ``Rotation 1``, ``Rotation 2``, ``Rotation 3``, ``Dynamic
x``, ``Dynamic y``, ``Dynamic z``, ``Dynamic Rx``, ``Dynamic Ry``, ``Dynamic
Rz``, ``Velocity``, ``GX velocity``, ``GY velocity``, ``GZ velocity``,
``Acceleration``, ``GX acceleration``, ``GY acceleration``, ``GZ acceleration``

