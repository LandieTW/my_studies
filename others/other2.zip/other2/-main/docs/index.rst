############################################
TechnipFMC - Repeated Lowering Control (RLC)
############################################

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   installation
   methodology
   usage
   input_file
   orcaflex_parameters
   console
   output
   references
   changelog


########
Overview
########

Current Version: 5.0.0

This documentation describes the TechnipFMC script Repeated
Lowering Control (RLC).  This script is used to automate the
process of performing analysis for lifting objects through the
splash zone from a floating vessel or fixed platform.  This
program relies on the use of the Python programming language
and the time domain simulation software
`Orcaflex <http://www.orcina.com/orcaflex/>`_ (by Orcina).
Orcaflex is available in the TechnipFMC Software Center.

It is assumed that the user is familiar with Orcaflex and has
a basic understanding of the Python programming language.

The RLC script is developed and hosted on the
`TechnipFMC Azure DevOps <https://dev.azure.com/technipfmc-dev/>`_
site under the
`Subsea-InstallationAnalysis <https://dev.azure.com/technipfmc-dev/Subsea-
InstallationAnalysis>`_ project. If you do not have access to this site,
contact your Installation Analysis lead.

Alternatively, contact:

- `Andrew Blundon <mailto:andrew.blundon@technipfmc.com>`_ -
  NAM Lifting and I&C Technical Authority (North America Region)
- `Young Jang Na <mailto:youngjang.na@technipfmc.com>`_ -
  Manager Installation Analyses (Norway Region)


