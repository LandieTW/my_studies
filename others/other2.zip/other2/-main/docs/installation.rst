.. _installation:

############
Installation
############

.. contents::
   :local:
   :depth: 2


Introduction
************

The RLC script requires the use of the Python programming language and the
Windows command prompt.  The script requires Python 3 and has been tested with
version 3.12.9.  If Python hasn't been installed it can be installed through
the TechnipFMC software center.  Ensure the correct version is selected from
the TechnipFMC Software Center.  Alternatively, the installation package can be
installed (with limited options) from the Python `website
<https://www.python.org/>`_.

Python Installation
*******************

Software Center
===============

Open the TechnipFMC Software Center and search for Python.  You will see
multiple versions listed.  It is recommended that version 3.12 be installed.

Manual Installation
===================

Go to `Python Downloads <https://www.python.org/downloads/>`_ and search for
version 3.12.  More recent versions may work but have not been tested.
Download the "Windows installer (64-bit)."  This will download the the
executable installer.  Double click the executable to launch the installer.

Click "Custom Installation".  Ensure "pip" is checked on the Optional Features
page.  Ensure "for all users (requires admin privileges)" is unchecked.  Click
next.

Select a local accessible folder for installation.  Make note of this folder.

Creating a Virtual Environment
******************************

Once Python is installed it is highly recommended to create a virtual
environment for running RLC.  This will ensure that compatibility issues do not
exist if other Python libraries are installed.  As well, using a virtual
environment allows the user to have have different versions of RLC installed
simultaneously, each in their own virtual environment.  This is extremely
useful, especially if a bug is found and you wish to revert back to an older
version.  It is recommended that the created virtual environment is only used
to run RLC.

A virtual environment is an isolated workspace for Python.  It lets you install
and use packages without affecting the system-wide Python installation or other
projects.  Each virtual environment has its own copy of the Python interpreter
and its own set of installed packages.  It generally only takes a few seconds
to create and virtual environment and install the required packaged.  A virtual
environment can be deleted simply by deleting the folder in which it was
installed.

To create a virtual environment open a Windows Command Prompt (start button ->
cmd).  From there navigate to a folder where you want to create the virtual
environment.  This has to be a physical drive in your machine and not a network
folder.  It is recommended that the virtual environment also not be installed
on a OneDrive or Sharepoint folder.  When you've navigated to the folder enter
this command.

.. code-block:: bash

    c:\python\python -m venv venv_rlc

The path for your particular python installation may differ from what is above
as it depends on the folder in which python was installed.  If you have
multiple versions of Python installed, ensure that the version used to create
the virtual environment is compatible with the version of RLC being installed
(3.12 is recommended).  As well, the name of the virtual environment (venv_rlc
above) can be customized to whatever name you wish.  It may be useful to
include the Python version number in the virtual environment name and the RLC
version number (i.e. venv_3.12.9_rlc5.0.0).

Once the virtual environment is created, it needs to be activated.  To do that,
using the command prompt, go to the Scripts folder of your virtual environment.

.. code-block:: bash

    c:\path_to_vir_env\venv_rlc\Scripts

From there activate the virtual environment.

.. code-block:: bash

    c:\path_to_vir_env\venv_rlc\Scripts\activate.bat

Once the virtual environment is activated, you'll know that it is activated as
the command prompt will change.

.. code-block:: bash

    (venv_3.12.9_rlc5.0.0) c:\path_to_vir_env\venv_rlc\Scripts\

The :file:`(venv_3.12.9_rlc5.0.0)` indicates that you're in the virtual
environment that was just created.  Whenever you go to run the RLC script,
navigate to this folder and activate the virtual environment.

Once the virtual environment is enabled for the first time, the RLC package
needs to be installed.  This only needs to be done once after the virtual
environment is created.

DevOps
******

The RLC script is developed and hosted on the `TechnipFMC Azure DevOps
<https://dev.azure.com/technipfmc-dev/>`_ site under the `Subsea-
InstallationAnalysis <https://dev.azure.com/technipfmc-dev/Subsea-
InstallationAnalysis>`_ project. If you do not have access to this site,
contact your Installation Analysis lead.

By hosting this script on DevOps the installation and update process can be
greatly simplified for users.  This also gives the developers access control
and archiving functions.  Once set up, the RLC script can be installed in your
Python environment like any other Python package.

Automatic Authentication Setup
==============================

The first step in the process is to set up automatic authentication to the
DevOps Artifacts server.

.. code-block:: bash

    pip install artifacts-keyring


Set-up Artifact Feed to Pip
===========================

Add the installation analysis DevOps feed to your pip configuration file for
your virtual environment.

.. code-block:: bash

    pip config --site set global.extra-index-url https://pkgs.dev.azure.com/technipfmc-dev/Subsea-InstallationAnalysis/_packaging/InstallationAnalysisWheels/pypi/simple

If you've decided to not use a virtual environment for RLC, you can add the
DevOps feed to your Global pip configuration.

.. code-block:: bash

    pip config --user set global.extra-index-url https://pkgs.dev.azure.com/technipfmc-dev/Subsea-InstallationAnalysis/_packaging/InstallationAnalysisWheels/pypi/simple

**Note it is highly recommended that you use a virtual environment for running
RLC.**  If you are using a virtual environment, use the option `--site` instead
of `--user`.

Install the Module
==================

Once you set up authentication you should be able to directly install RLC to
your Python environment using pip.  This will install the latest stable
release.

.. code-block:: bash

    pip install rlc

and to update.

.. code-block:: bash

    pip install --upgrade rlc

To install a specific version of rlc use the command.

.. code-block:: bash

    pip install rlc==4.0.0

Note that `pip install` or `pip install --upgrade` can only be done once
artifact feed is set up. You can check if the artifact feed is already set by.

.. code-block:: bash

    pip config list

If you are requested for ID and password this may indicate that the artifacts-
keyring is not installed yet. You can check if the artifacts-keyring is already
installed by.

.. code-block:: bash

    pip show artifacts-keyring

If you cannot install the artifacts-keyring because of the artifact feed, then
you can unset the artifact feed by.

.. code-block:: bash

    pip config unset global-extra-index-url

and install the artifacts-keyring as in section Set-up automatic
authentication.

No Changes to pip Config File
=============================

If you don't want to change pip config file (i.e. do not connect to DevOps for
future upgrades etc.), you can pass the index URL as an argument.

.. code-block:: bash

    pip install rlc --index-url https://pkgs.dev.azure.com/technipfmc-dev/Subsea-InstallationAnalysis/_packaging/InstallationAnalysisWheels/pypi/simple

Installing HPC-Flex
*******************

HPC-Flex is a TechnipFMC package that is stored on The Well site and cannot be
automatically installed when RLC is installed.

To install HPC-Flex, navigate to the `HPC-Flex Well Page
<https://digicorner.sharepoint.com/sites/TheWell/SitePages/HPC-Flex.aspx>`_.
From there, search for the package distribution file. This version of RLC has
been tested with HPC-Flex version 0.8.6.

Once the :file:`hpcflex-0.8.3-py3-none-any.whl` has been downloaded, enter your
virtual environment in the command prompt, navigate to the location where the
file :file:`hpcflex-0.8.6-py3-none-any.whl` has been downloaded, and run.

.. code-block:: bash

    python -m pip install --user hpcflex-0.8.3-py3-none-any.whl

This will install the HPC-Flex package to that virtual environment.

Troubleshooting
***************

Azure Authentication Requested
==============================

Problem
-------

As mentioned earlier, it's **strongly recommended** to use **virtual
environments** when setting up your Python environment.

If a user has previously configured Azure DevOps in their base Python
installation using the following command:

.. code-block:: bash

    pip config --user set global.extra-index-url https://pkgs.dev.azure.com/technipfmc-dev/Subsea-InstallationAnalysis/_packaging/InstallationAnalysisWheels/pypi/simple

This command creates a pip.ini file in the user's profile directory:

.. code-block:: bash

    C:\Users\<UserName>\AppData\Roaming\pip\

This file stores the DevOps repository URL globally. As a result, even when
working inside a virtual environment, Python will still reference this global
configuration first when running:

.. code-block:: bash

    pip install rlc

This can trigger an Azure authentication prompt, even though the virtual
environment is properly configured. The issue arises because the artifacts-
keyring is set up for the virtual environment, not the base Python
installation. Therefore, the prompt fails to accept credentials.

In contrast, when using:

.. code-block:: bash

    pip config --site set global.extra-index-url <URL>

The configuration is stored within the virtual environment, not in the global
AppData folder. This avoids the authentication issue.

Resolution
----------

To fix this issue navigate to:

.. code-block:: bash

    C:\Users\<UserName>\AppData\Roaming\pip\

and delete the ``pip.ini`` file.

This will remove the global DevOps URL and allow your virtual environment to
use its own configuration without triggering Azure authentication.