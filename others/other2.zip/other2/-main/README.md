# RLC — Repeated Lowering Control for Lifting Analysis

RLC fully automates probabilistic lifting analysis using the repeated lowering methodology with OrcaFlex. It manages sea state simulations, applies Gumbel distribution fitting with goodness-of-fit checks, and produces probabilistic load results and weather window outputs.

**Documentation:** https://azsane02userlc.z13.web.core.windows.net/

## Key Features

- **YAML-based configuration** — no Python scripting required; all analysis parameters are defined in a single `rlc_input.yml` file
- **Gumbel distribution fit checking** — automatically falls back to empirical methods with bootstrapped confidence intervals when data does not fit the Gumbel distribution
- **Live console UI** — Rich-based terminal interface showing an Hs × Period status grid with real-time progress updates
- **SQLite database** — all results and run status are stored in a local database for robustness and traceability
- **Multiple run methods** — Distributed OrcaFlex (DOF), local, or HPC-Flex
- **Email notifications** — optional email updates as the analysis progresses
- **Excel and PDF output** — `rlc_results.xlsx`, `weather_window.xlsx`, and `weather_window.pdf`

## Requirements

- Python 3.12 or later
- Windows 10 or 11
- OrcaFlex (with `orcfxapi` license)

## Installation

A virtual environment is recommended.

### 1. Set up authentication to the Azure DevOps Artifacts feed

```
pip install artifacts-keyring
```

### 2. Configure the artifact feed

Using a virtual environment (recommended):

```
pip config --site set global.extra-index-url https://pkgs.dev.azure.com/technipfmc-dev/Subsea-InstallationAnalysis/_packaging/InstallationAnalysisWheels/pypi/simple
```

Or for a user-level configuration:

```
pip config --user set global.extra-index-url https://pkgs.dev.azure.com/technipfmc-dev/Subsea-InstallationAnalysis/_packaging/InstallationAnalysisWheels/pypi/simple
```

### 3. Install the package

```
pip install rlc
```

To upgrade to the latest version:

```
pip install --upgrade rlc
```

## Quick Start

1. **Prepare your working folder** with the following files:
   - An OrcaFlex base model (`.dat` file)
   - An RLC configuration file (`rlc_input.yml`)
   - A launcher script (`run_rlc.py`)

2. **Create the launcher script** `run_rlc.py`:

   ```python
   import rlc.main as rlc

   if __name__ == "__main__":
       rlc.main()
   ```

3. **Run the analysis:**

   ```
   python run_rlc.py
   ```

   Or specify a different input file:

   ```
   python run_rlc.py my_config.yml
   ```

   Use `--debug` for verbose logging.

4. **Results** are written to the `results/` folder. The SQLite database is stored in `database/` and logs in `logs/`.

For full details on the input file format, OrcaFlex model requirements, and output interpretation, refer to the [documentation](https://azsane02userlc.z13.web.core.windows.net/).

## License

TechnipFMC Internal Use License — see [license.txt](license.txt) for details.

## Contact

Andrew Blundon — andrew.blundon@technipfmc.com
