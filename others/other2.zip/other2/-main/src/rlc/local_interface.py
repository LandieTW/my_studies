import functools
import json
import logging
import os
import random
import socket
import time
from datetime import datetime
from multiprocessing import Pool, cpu_count
from pathlib import Path

import OrcFxAPI as of

import rlc.utils as utils

logger = logging.getLogger("RLC")


# ==============================
# Status file helpers
# ==============================
STATUS_DIR_NAME = ".rlc_status"


def status_path(yml: str) -> Path:
    """
    Builds a path like <dir>/.rlc_status/<stem>.status.json next to the YAML.
    """
    p = Path(yml)
    status_dir = p.parent / STATUS_DIR_NAME
    status_dir.mkdir(parents=True, exist_ok=True)
    return status_dir / f"{p.stem}.status.json"


def write_status(yml: str, state: str, message: str | None = None) -> None:
    """
    Atomically write a status JSON so readers never see a partially written file.
    States: 'RUNNING', 'COMPLETED', 'UNSTABLE'
    """
    sp = status_path(yml)
    payload = {
        "yml": str(yml),
        "state": str(state).upper(),
        "message": message,
        "pid": os.getpid(),
        "host": socket.gethostname(),
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    tmp = sp.with_suffix(sp.suffix + f".tmp-{os.getpid()}")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f)
    os.replace(tmp, sp)  # atomic replace on same filesystem


def delete_status_file(yml: str) -> bool:
    """
    Deletes the per-job status file if it exists.
    Returns True if deleted, False otherwise.
    """
    sp = status_path(yml)
    try:
        sp.unlink()
        return True
    except FileNotFoundError:
        return False
    except Exception as e:
        logger.warning(f"Could not delete status file for {yml}: {e}")
        return False


def read_status(yml: str) -> dict | None:
    """
    Safe status reader. Returns dict or None (if unreadable/missing).
    """
    sp = status_path(yml)
    if not sp.exists():
        return None
    try:
        with open(sp, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        # If corrupted, treat as missing to be conservative.
        return None


def cleanup_status_files(yml_files: list[str]) -> tuple[int, int]:
    """
    Deletes status files for the provided YAMLs if none are running.
    Returns (deleted_count, remaining_running_count).

    If any job is still RUNNING, deletion is skipped.
    """
    jobs_running, jobs_completed, jobs_unstable = categorize_jobs(yml_files)

    if jobs_running:
        logger.info(
            "Skipping cleanup: %d jobs still running (e.g., %s ...)",
            len(jobs_running),
            jobs_running[0] if jobs_running else "",
        )
        return 0, len(jobs_running)

    deleted = 0
    for yml in jobs_completed + jobs_unstable:
        if delete_status_file(yml):
            deleted += 1

    return deleted, 0


# ==============================
# OrcaFlex license-handled helpers
# ==============================


def license_handler(func):
    """Decorator to handle license errors."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        for i in range(10):
            try:
                return func(*args, **kwargs)
            except of.DLLError as error:
                if not error.status == of.stLicensingError:
                    raise error
                time.sleep(i + random.random())
                print(f"Failed attempt {i + 1} of trying to reach a license.")
        return None

    return wrapper


@license_handler
def load_data(model, path):
    """Load data and handle license error."""
    model.LoadData(path)


@license_handler
def run_simulation(model):
    """Run simulation and handle license error."""
    model.RunSimulation()


@license_handler
def post_actions(model, path):
    """Run post calculation actions and handle license error."""
    model.ExecutePostCalculationActions(path, of.atInProcPython)


@license_handler
def get_of_model(model_file_name=None):
    """Return OrcFxAPI.Model(model_file_name) with license error handling."""
    return of.Model(model_file_name)


# ==============================
# Worker / categorizer
# ==============================
def _get_model_state(model):
    """
    Try to obtain the model state across possible attribute variants.
    Returns the enum or None.
    """
    for attr in ("state", "State", "modelState", "ModelState"):
        if hasattr(model, attr):
            try:
                return getattr(model, attr)
            except Exception:
                pass
    return None


def ofx_worker(ymls):
    """Internal worker function that runs the simulations."""

    # random sleep to avoid multiple instances being open at the same time
    time.sleep(2 * random.random())

    # get an instance of OrcFxAPI.Model with license management.
    m = get_of_model()

    if m is None:
        # Could not acquire license after retries; mark all as unstable for visibility.
        for yml in ymls:
            write_status(
                yml, "UNSTABLE", "Failed to acquire OrcaFlex license."
            )
        return False

    for yml in ymls:
        try:
            if not os.path.exists(yml):
                logger.error("File not found %s" % yml)
                write_status(yml, "UNSTABLE", "YAML file not found.")
                continue

            # Mark as running as soon as we pick it up
            write_status(yml, "RUNNING")

            # Load, run, and post-process
            load_data(m, yml)
            run_simulation(m)

            # Inspect the model state
            current_state = _get_model_state(m)

            # Classify based on model state
            if current_state == of.ModelState.SimulationStoppedUnstable:
                write_status(
                    yml, "UNSTABLE", "Simulation stopped due to instability."
                )
            elif current_state == of.ModelState.SimulationStopped:
                write_status(
                    yml, "COMPLETED", "Simulation completed successfully."
                )
            else:
                # Unexpected state—keep as RUNNING with a note
                write_status(
                    yml, "RUNNING", f"Unexpected state: {current_state}"
                )

            # Post calculation actions (partial results may exist for unstable)
            post_actions(m, yml)

        except of.DLLError as e:
            # License-related errors already retried by the decorator; record outcome.
            write_status(yml, "UNSTABLE", f"OrcaFlex DLL error: {e}")
        except Exception as e:
            # Any other runtime error—mark unstable
            write_status(yml, "UNSTABLE", f"Worker exception: {e}")

    return True


def categorize_jobs(yml_files):
    """
    Returns:
        jobs_running, jobs_completed_successfully, jobs_unstable

    Logic:
      - Missing status => treated as RUNNING (queued/not started).
      - state == 'COMPLETED' => completed_ok
      - state == 'UNSTABLE'  => unstable
      - otherwise => RUNNING
    """
    jobs_running = []
    jobs_completed_successfully = []
    jobs_unstable = []

    for yml in yml_files:
        s = read_status(yml)
        if s is None:
            jobs_running.append(yml)
            continue

        state = str(s.get("state", "")).upper()
        if state == "COMPLETED":
            jobs_completed_successfully.append(yml)
        elif state == "UNSTABLE":
            jobs_unstable.append(yml)
        else:
            jobs_running.append(yml)

    return jobs_running, jobs_completed_successfully, jobs_unstable


# ==============================
# Orchestration
# ==============================


def run_yml(ymls):
    nprocs = max(1, min(len(ymls), (cpu_count() or 2) - 1))
    pool = Pool(processes=nprocs)
    logger.info("Processing %d files using %d cpus." % (len(ymls), nprocs))

    # split the list of ymls into chunks
    chunk_size = len(ymls) // nprocs + 1
    chunks = [
        ymls[i : i + chunk_size] for i in range(0, len(ymls), chunk_size)
    ]

    # opens one orcaflex instance first. seems that posterior openings are faster.
    get_of_model()

    # map_async matches DOF behavior
    return pool.map_async(ofx_worker, chunks)


def main(config, console_manager):
    # Create the text file for local
    txt_file, yml_files = utils.create_txt_package(config, logger)
    total_files = len(yml_files)

    # Check if there are any files to run
    if total_files == 0 or txt_file is None:
        logger.info("No YML files to run. Skipping local submission.")
        # Change Status of files to running
        utils.db_status_update(old_status="Q", new_status="R")
        utils.db_status_update(old_status="Q+", new_status="R+")
        return [], []  # Return empty lists for yml_files and unstable

    logger.info(f"Running local jobs with text file: {txt_file}")
    logger.info(f"Running {total_files} *.yml files.")

    # Run the yml files locally
    run_yml(yml_files)

    # Change Status of files to running
    utils.db_status_update(old_status="Q", new_status="R")
    utils.db_status_update(old_status="Q+", new_status="R+")

    # Update the console manager
    console_manager.update_from_database()

    # Watch the folder for json result files.  When all json files are created

    check_interval = 10  # 10 seconds

    while True:
        running, completed_ok, unstable = categorize_jobs(yml_files)
        num_running = len(running)
        num_completed_ok = len(completed_ok)
        num_unstable = len(unstable)

        logger.info(
            f"Local Progress: Completed: {num_completed_ok}, Running: {num_running}, Unstable: {num_unstable}"
        )

        if num_completed_ok + num_unstable == total_files:
            logger.info("DOF Batch completed")
            logger.info(
                f"Completed Successfully: {num_completed_ok}, Unstable: {num_unstable}"
            )

            # Clean up helper status JSON files now that all jobs are categorized
            deleted, remaining = cleanup_status_files(yml_files)
            logger.info(
                "Status cleanup: deleted %d files, %d still present.",
                deleted,
                remaining,
            )

            break

        # if time.time() - start_time > timeout_seconds:
        #     logger.warning("Timeout reached before all JSON files were created.")
        #     break

        time.sleep(check_interval)

    return yml_files, unstable
