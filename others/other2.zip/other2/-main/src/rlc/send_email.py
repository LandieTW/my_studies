# Import Libraries
import win32com.client as win32
import getpass
import datetime as DT
import logging
import os

import rlc.config as cfg

logger = logging.getLogger("RLC")


class EmailNotifier:
    """
    This class is used to send email notifications.
    """

    VALID_MSG_TYPES = {"Info", "Warning", "Error"}

    def __init__(self):
        self.to_email = self.get_smtp_address()

    def send(self, msg_type: str, msg_text: str):
        if msg_type not in self.VALID_MSG_TYPES:
            raise ValueError(
                f"Invalid msg_type: {msg_type}. Must be one of: {self.VALID_MSG_TYPES}"
            )

        # Open up an outlook email
        try:
            outlook = win32.Dispatch("Outlook.Application")
            new_mail = outlook.CreateItem(0)
        except Exception as e:
            logger.error(f"Failed to create Outlook email: {e}")
            return

        try:
            if os.path.exists(cfg.LOG_PATH):
                new_mail.Attachments.Add(cfg.LOG_PATH)
            else:
                logger.warning("Attachment 'rlc.log' not found.")
        except Exception as e:
            logger.warning(f"Failed to attach file: {e}")

        # Email subject
        new_mail.Subject = (
            f"RLC - Run Status Update ({msg_type}): {DT.date.today():%Y-%m-%d}"
        )

        # Generate Body
        # Title
        # - Email
        strBody = "<h2>Repeat Lowering Control: Run Status Update</h2>"

        # User Details
        # - Email
        strBody += f"<p>Sent From Account: {getpass.getuser()}</p>"

        strBody += (
            f"<p>This email is sent automatically by the Repeated Lowering Control tool. "
            f"The user {getpass.getuser()} is running this script to perform a repeated"
            f"lowering/hoisting analysis for a subsea lift.</p>"
            f"<br>"
            f"<b>Message Details:</b>"
            f"<p>{msg_text}</p>"
        )

        # Add the to and cc list
        new_mail.To = self.to_email
        new_mail.HTMLBody = strBody

        # Display the email
        # new_mail.Display()
        new_mail.Send()
        logger.info(f"Status update email set to: {self.to_email}")

    def info(self, msg_text: str):
        self.send("Info", msg_text)

    def warning(self, msg_text: str):
        self.send("Warning", msg_text)

    def error(self, msg_text: str):
        self.send("Error", msg_text)

    def get_smtp_address(self):
        """
        This function returns the email address of the user.

        Args:
            None

        Return:
            email address:  (str)   A string with the email address
        """
        outlook = win32.Dispatch("Outlook.Application")
        session = outlook.Session
        current_user = session.CurrentUser

        # Get the AddressEntry object
        address_entry = current_user.AddressEntry

        # If it's an Exchange user, get the SMTP address
        if address_entry.Type == "EX":
            exch_user = address_entry.GetExchangeUser()
            if exch_user:
                return exch_user.PrimarySmtpAddress
        else:
            return address_entry.Address


if __name__ == "__main__":
    # try:
    #     outlook = win32.Dispatch("Outlook.Application")
    #     mail = outlook.CreateItem(0)
    #     mail.To = "your.email@example.com"  # Replace with a known good address
    #     mail.Subject = "Test Email"
    #     mail.Body = "This is a test."
    #     mail.Display()  # Try this without attachments or HTML
    # except Exception as e:
    #     logger.error(f"Outlook error: {e}")

    logging.basicConfig(level=logging.INFO)
    notifier = EmailNotifier()
    notifier.info("This is an info message")

    # send_email(config)
