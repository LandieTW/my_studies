import json
import logging
import sqlite3
from concurrent.futures import ThreadPoolExecutor

import rlc.config as cfg
import rlc.utils as utils
import rlc.utils_core as utils_core

logger = logging.getLogger("RLC")


def _read_json_file(seed):
    """Read and parse a single JSON results file. Returns (seed, data) or (seed, None)."""
    rowid, hs, period, wave_dir, seed_number, seed_value = seed
    json_file = (
        "runs/"
        + utils_core.file_name_gen(hs, period, wave_dir, seed_number)
        + "_results.json"
    )
    try:
        with open(json_file, "r") as f:
            data = json.load(f)
        return (seed, data)
    except FileNotFoundError:
        logger.warning(f"Missing file: {json_file}")
        return (seed, None)


def main():
    """
    This function reads the results from the JSON files and stores them in the database.
    """

    # Connect to the SQLite database
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Apply performance-related PRAGMA settings
        cursor.execute("PRAGMA synchronous = OFF")
        cursor.execute("PRAGMA journal_mode = MEMORY")
        cursor.execute("PRAGMA temp_store = MEMORY")

        # Fetch all rows that need to be updated
        cursor.execute(
            """
            SELECT rowid, hs, period, wave_dir, seed_number, seed_value
            FROM seed_results
            WHERE status = 'C'
        """
        )
        seeds_to_update = cursor.fetchall()

        # Read and parse all JSON files in parallel (I/O-bound)
        with ThreadPoolExecutor() as executor:
            parsed_results = list(
                executor.map(_read_json_file, seeds_to_update)
            )

        # Write to DB serially with batched updates (one UPDATE per seed)
        conn.execute("BEGIN")
        for seed, data in parsed_results:
            if data is None:
                continue
            rowid, hs, period, wave_dir, seed_number, seed_value = seed

            results = data.get("results", [])
            columns = []
            values = []
            for result in results:
                column_name = utils.construct_criterion_name_no_prob(result)
                columns.append(f'"{column_name}" = ?')
                values.append(result["value"])

            if columns:
                set_clause = ", ".join(columns)
                values.append(rowid)
                try:
                    cursor.execute(
                        f"UPDATE seed_results SET {set_clause} WHERE rowid = ?",
                        values,
                    )
                except sqlite3.OperationalError as e:
                    logger.info(
                        f"Error updating seed {seed_number} for hs={hs}, period={period}, wave_dir={wave_dir}: {e}"
                    )
        conn.commit()

    utils.sync_db_to_network()


if __name__ == "__main__":
    main()
