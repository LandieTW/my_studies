# logger_config.py
import logging
import os
from collections import deque

import rlc.config as cfg

# Global deque for log messages (shared with rlc_console.py)
log_messages = deque(maxlen=200)  # Retain up to 20 messages


class CustomRichHandler(logging.Handler):
    def __init__(
        self,
        console=None,
        layout=None,
        data=None,
        hs_values=None,
        period_values=None,
        main_table=None,
        legend_table=None,
        live=None,
        update_callback=None,
    ):
        super().__init__()
        self.console = console
        self.layout = layout
        self.data = data
        self.hs_values = hs_values
        self.period_values = period_values
        self.main_table = main_table
        self.legend_table = legend_table
        self.live = live
        self.update_callback = update_callback
        self.recent_messages = deque(maxlen=100)  # Track recent messages

    def emit(self, record):
        try:
            message = self.format(record)
            if message not in self.recent_messages:
                self.recent_messages.append(message)
                if (
                    self.update_callback
                    and self.console
                    and self.layout
                    and self.live
                ):
                    self.update_callback(
                        console=self.console,
                        data=self.data,
                        hs_values=self.hs_values,
                        period_values=self.period_values,
                        new_log_message=message,
                        layout=self.layout,
                        main_table=self.main_table,
                        legend_table=self.legend_table,
                        live=self.live,
                    )
        except Exception:
            self.handleError(record)


def setup_logger(name: str, debug: bool = False):
    """Set up a logger with file and console handlers."""
    # Ensure the parent directory of the log file exists

    log_dir = os.path.dirname(cfg.LOG_PATH)
    os.makedirs(log_dir, exist_ok=True)

    level = logging.DEBUG if debug else logging.INFO
    formatter = logging.Formatter("[%(asctime)s %(levelname)s]: %(message)s")

    # File handler for logging to file
    file_handler = logging.FileHandler(cfg.LOG_PATH, mode="w")
    file_handler.setFormatter(formatter)
    file_handler.setLevel(level)

    # Stream handler for initial terminal output (before switching to Rich)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(level)

    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Clear existing handlers to avoid duplicates
    logger.handlers.clear()
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    logger.propagate = False

    return logger


def switch_to_rich_logging(
    logger,
    console=None,
    layout=None,
    data=None,
    hs_values=None,
    period_values=None,
    main_table=None,
    legend_table=None,
    live=None,
    update_callback=None,
):
    """
    Switch logger to use CustomRichHandler for log_messages deque and console updates.
    Removes all non-file handlers before adding the Rich handler.
    """
    # Keep only FileHandler(s), remove all others
    if not any(isinstance(h, CustomRichHandler) for h in logger.handlers):
        logger.handlers = [
            h for h in logger.handlers if isinstance(h, logging.FileHandler)
        ]

    # Add CustomRichHandler
    rich_handler = CustomRichHandler(
        console=console,
        layout=layout,
        data=data,
        hs_values=hs_values,
        period_values=period_values,
        main_table=main_table,
        legend_table=legend_table,
        live=live,
        update_callback=update_callback,
    )
    rich_handler.setFormatter(
        logging.Formatter("[%(asctime)s %(levelname)s]: %(message)s")
    )
    rich_handler.setLevel(logger.level)
    logger.addHandler(rich_handler)
