import json
import logging
import sqlite3
import sys
import time
from multiprocessing import Process

import rlc.check_criteria as check_criteria
import rlc.config as cfg
import rlc.post_calc as post_calc
import rlc.run_stats as run_stats
import rlc.store_results as store_results
import rlc.submit as submit
import rlc.utils as utils
import rlc.utils_core as utils_core
from rlc.notifier_factory import get_notifier
from rlc.zero_wave import main as zero_wave_main

logger = logging.getLogger("RLC")
notifier = get_notifier()


def run_zero_wave(config):
    # Convert config to JSON string to mimic CLI input
    import sys

    sys.argv = ["zero_wave.py", json.dumps(config)]
    zero_wave_main()


def create_yml(config):
    """
    Create YML files for each case in the database.
    This function connects to the SQLite database, retrieves cases with status 'N',
    and generates YML files for each case. It updates the status to 'Y' after
    creating the YML files.
    """

    # Connect to the database
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Retrieve cases with status 'N' or 'N+'
        utils.custom_execute(
            cursor,
            """
            SELECT rowid, hs, period, wave_dir, status, seed_number, seed_value
            FROM seed_results
            WHERE status = 'N' or status = "N+"
            """,
        )
        cases = cursor.fetchall()

        # Lists to store data for batch updates
        seed_updates = []
        case_updates = []
        stat_updates = []

        progress_previous = 0
        logger.info(f"Creating YMLs from {len(cases)} cases")
        for i, row in enumerate(cases):
            rowid, hs, period, wave_dir, status, seed_number, seed_value = row
            # Generate YML file for the case
            utils_core.generate_yml_file(
                config, hs, period, wave_dir, seed_number, seed_value
            )

            # Update Progress in Logging Messages
            progress_fraction = (i + 1) / len(cases)
            progress_current = int(progress_fraction * 100)
            if progress_current > progress_previous:
                logger.info(
                    f"Creating YMLs ({i}/{len(cases)}): {utils_core.progress_bar(progress_fraction)}"
                )
                progress_previous = progress_current

            # Collect data for batch updates
            seed_updates.append((rowid,))
            case_updates.append((hs, period))
            stat_updates.append((hs, period, wave_dir))

        # Temporary list to loop through cases in each update.
        update_matrix = [["N", "Y"], ["N+", "Y+"]]
        # Batch update seed_results
        for update in update_matrix:
            if seed_updates:
                cursor.executemany(
                    f"""
                    UPDATE seed_results
                    SET status = '{update[1]}'
                    WHERE rowid = ? AND status = '{update[0]}'
                    """,
                    seed_updates,
                )

            # Batch update case_results
            if case_updates:
                cursor.executemany(
                    f"""
                    UPDATE case_results
                    SET status = '{update[1]}'
                    WHERE hs = ? AND period = ? AND status = '{update[0]}'
                    """,
                    case_updates,
                )

            # Batch update stat_results
            if stat_updates:
                cursor.executemany(
                    f"""
                    UPDATE stat_results
                    SET status = '{update[1]}'
                    WHERE hs = ? AND period = ? AND wave_dir = ? AND status = '{update[0]}'
                    """,
                    stat_updates,
                )
    utils.sync_db_to_network()


def update_highest_hs_status(config):
    """
    Open a SQLite database and update the status to 'N' for the highest hs
    for each unique period where status is '-'.

    This is done at the start of the analysis run to initialize the first
    set of cases to be analyzed.

    Args:
        db_file (str): Path to the SQLite database file.
        period_type (str): Type of period, either 'Tp' or 'Tz'.
    """
    # Connect to the database
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        ######################
        # Setting case_results
        ######################
        #
        # Find unique periods where status is '-'
        utils.custom_execute(
            cursor,
            """
            SELECT DISTINCT period
            FROM case_results
            WHERE status = '-'
        """,
        )
        unique_periods = [row[0] for row in cursor.fetchall()]

        # For each unique period, find the row with the highest hs
        for period in unique_periods:
            utils.custom_execute(
                cursor,
                """
                SELECT rowid, hs
                FROM case_results
                WHERE period = ? AND status = '-'
                ORDER BY hs DESC
                LIMIT 1
            """,
                (period,),
            )
            result = cursor.fetchone()

            if result:
                rowid, highest_hs = result
                # Update the status to 'N' for the row with the highest hs
                utils.custom_execute(
                    cursor,
                    """
                    UPDATE case_results
                    SET status = ?
                    WHERE rowid = ?
                """,
                    ("N", rowid),
                )

        ######################
        # Setting stat_results
        ######################
        #
        # Find unique periods where status is '-'
        # Create dictionary for highest hs per period
        hs_dict = {}
        utils.custom_execute(
            cursor, "SELECT period, MAX(hs) FROM stat_results GROUP BY period"
        )

        for row in cursor.fetchall():
            period, max_hs = row
            hs_dict[period] = max_hs

        # Update status to 'N' for records with highest hs per period
        for period, hs in hs_dict.items():
            cursor.execute(
                """
                UPDATE stat_results SET status = 'N'
                WHERE period = ? AND hs = ? and status = '-'
                """,
                (period, hs),
            )

        ######################
        # Setting seed_results
        ######################
        # For seed_results, we only need to update the status of the first no_seeds cases
        # where no_seeds is the value specified in the input file.

        no_seeds = config.get("min_seeds")
        # Step 1: Get all unique periods where status is '-'
        utils.custom_execute(
            cursor,
            """
            SELECT DISTINCT period
            FROM seed_results
            WHERE status = '-'
            """,
        )
        unique_periods = [row[0] for row in cursor.fetchall()]

        # Step 2: For each period, find the max hs and update all matching rows
        for period in unique_periods:
            # Get the max hs for this period
            utils.custom_execute(
                cursor,
                """
                SELECT MAX(hs)
                FROM seed_results
                WHERE period = ? AND status = '-'
                """,
                (period,),
            )
            max_hs = cursor.fetchone()[0]

            if max_hs is not None:
                # Update all rows of this max hs for this period
                # Update the status to 'N' for the first no_seeds cases

                utils.custom_execute(
                    cursor,
                    """
                    UPDATE case_results
                    SET status = 'N'
                    WHERE period = ? AND hs = ? AND status = '-'
                    """,
                    (period, max_hs),
                )

                utils.custom_execute(
                    cursor,
                    """
                    UPDATE stat_results
                    SET status = 'N'
                    WHERE period = ? AND hs = ? AND status = '-'
                    """,
                    (period, max_hs),
                )

                utils.custom_execute(
                    cursor,
                    """
                    UPDATE seed_results
                    SET status = 'N'
                    WHERE period = ? AND hs = ? AND status = '-' AND seed_number <= ?
                    """,
                    (period, max_hs, no_seeds),
                )

        # Commit the changes
        conn.commit()
    utils.sync_db_to_network()


def repeat_analysis_loop():
    """
    This function opens the rlc_results.db file and sees if there are any cases in the case_results table
    where the status is not "F", "OK", "NG" or "X".  If so, return True to indicate the analysis loop should repeat.

    Args:
        None

    Return:
        bool: True if the analysis loop should repeat, False otherwise.
    """

    # Connect to the database
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Retrieve cases where status is not "F", "OK", "NG" or "X"
        utils.custom_execute(
            cursor,
            """
            SELECT rowid, hs, period, status
            FROM case_results
            WHERE status != "F" AND status != "OK" AND status != "NG" AND status != "X"
            """,
        )
        cases = cursor.fetchall()

        if cases:
            return True
        else:
            return False


def finalize_case_results(config):
    """
    Finalizes the case_results table in the rlc_results.db
    Considers each row in case_results.  Finds the rows in the stat_results table that have the same hs and period.
    Goes through each criteria and gets either the max or min value (depending on the criteria) of all the matching rows.

    Args:
        config (_type_): _description_
    """

    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Step 1: Get all unique hs/period combinations from case_results
        utils.custom_execute(
            cursor, "SELECT DISTINCT hs, period FROM case_results"
        )
        case_combinations = cursor.fetchall()

        for hs, period in case_combinations:
            # Step 2: Get matching rows from stat_results
            utils.custom_execute(
                cursor,
                """
                SELECT * FROM stat_results
                WHERE hs = ? AND period = ?
            """,
                (hs, period),
            )

            rows = cursor.fetchall()

            if not rows:
                continue

            # Get column names to access values by name
            stat_columns = [desc[0] for desc in cursor.description]

            for criteria in config.get("analysis_criteria"):
                mode = criteria.get("mode")

                column_name = utils.criteria_to_column_name(criteria)

                # Extract values from the relevant column
                values = [
                    row[stat_columns.index(column_name)]
                    for row in rows
                    if row[stat_columns.index(column_name)] is not None
                ]

                if not values:
                    continue

                # Compute max or min
                result_value = max(values) if mode == "max" else min(values)

                # Step 4: Update case_results with the computed value
                utils.custom_execute(
                    cursor,
                    f"""
                    UPDATE case_results
                    SET "{column_name}" = ?
                    WHERE hs = ? AND period = ?
                    """,
                    (result_value, hs, period),
                )
    utils.sync_db_to_network()


def run_analysis(console_manager, config, cases):
    max_hs_per_period = {}
    for case in cases.values():
        hs = case["hs"]
        period = case["period"]
        if period not in max_hs_per_period or hs > max_hs_per_period[period]:
            max_hs_per_period[period] = hs

    logger.info("Starting analysis...")
    logger.info("Updating status of highest hs for each period to 'N'...")
    # Update the status of the highest hs for each period to 'N' to initiate the analysis
    update_highest_hs_status(config)
    console_manager.update_from_database()

    # Create the runs folder/copy base file
    utils.create_runs_folder(config)

    # Create and/or copy the post calc action file
    post_calc.copy_post_calc_action(config)

    # Copy Extra files to runs folder
    utils.copy_extra_files(config)

    # Perform Zero Wave Analysis
    # Next lines are commented out as this is only used for single process
    # analysis (i.e. zero_wave is run as a subprocess)
    # logger.info("Performing Zero Wave Analysis...")
    # utils_core.zero_wave_analysis(config, logger)

    logger.info("Performing Zero Wave Analysis in a subprocess...")
    zero_wave_timeout = config.get("zero_wave_timeout")
    zero_wave_start_time = time.time()

    logger.info("Performing Zero Wave Analysis in a separate process...")
    zero_wave_process = Process(target=run_zero_wave, args=(config,))
    zero_wave_process.start()

    loops = 0

    while True:
        loops += 1
        logger.debug(f"Starting loop {loops}")

        # Create YML files for any cases with a 'N' and 'N+'
        # This changes the status to 'Y' and "Y+"
        logger.info("Creating *.yml files ...")
        create_yml(config)

        # Update console
        console_manager.update_from_database()
        logger.info("*.yml files created ...")
        utils.db_status_update(old_status="N", new_status="Y")
        utils.db_status_update(old_status="N+", new_status="Y+")

        # Files are ready for analysis
        # Analysis can be local, DOF or HPC-Flex
        # Change all of the Y files to Q
        logger.info("Queueing file for analysis ...")
        utils.db_status_update(old_status="Y", new_status="Q")
        utils.db_status_update(old_status="Y+", new_status="Q+")
        console_manager.update_from_database()

        # Submit files
        logger.info("Submitting files for analysis ...")
        submit.main(config, console_manager)

        # Store Analysis Results in Database
        logger.info("Storing results in database ...")
        store_results.main()
        utils.db_status_update(
            old_status="C",
            new_status="CS",
            case_results=False,
            stat_results=False,
        )  # type: ignore

        # Perform Analysis of Base Seed Cases
        logger.info("Performing statistical analysis of base seeds cases ...")
        run_stats.main(config)

        # Check each case to see if passes criteria
        logger.info("Checking criteria ...")
        check_criteria.main(config)
        console_manager.update_from_database()

        # Change Hs for NG cases
        logger.info("Considering next Hs to run for each period ...")
        utils.next_hs(config)
        console_manager.update_from_database()

        # Check to see if analysis loop should be repeated
        if not repeat_analysis_loop():
            logger.info("All analysis completed.")
            if config.get("email_on_finish"):
                notifier.info("RLC Analysis run has completed.")
            break
        else:
            # Get text table of current results
            results_table_text, results_table_html = (
                utils.get_current_results_table_from_db()
            )
            logger.info("\n" + results_table_text)

            if config.get("email_on_loop"):
                notifier_text = (
                    f"<p>RLC has finished loop number {loops}.</p>"
                    f"<p>Current status table:</p>"
                )
                notifier_text += results_table_html
                notifier.info(notifier_text)

    while True:
        if not zero_wave_process.is_alive():
            logger.info("Zero wave analysis finished.")
            break
        elif time.time() - zero_wave_start_time > zero_wave_timeout:
            logger.error(
                "Zero wave analysis timeout reached. Terminating process."
            )
            zero_wave_process.terminate()
            zero_wave_process.join()
            sys.exit(1)
        else:
            logger.info("Waiting for zero wave analysis to complete...")
            time.sleep(10)

    return
