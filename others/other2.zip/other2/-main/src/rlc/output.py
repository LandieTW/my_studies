import datetime
import json
import logging
import os
import shutil
import sqlite3
import time

import win32com.client as client
import xlsxwriter
from win32com.client import gencache

import rlc.config as cfg
import rlc.utils as utils
from rlc import __version__

logger = logging.getLogger("RLC")


def get_excel_app_late_bound():
    """Start a fresh Excel instance (avoids attaching to orphaned/zombie Excel)."""
    excel = client.DispatchEx("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False
    return excel  # use this instead of EnsureDispatch in convert


def open_workbook_robust(excel, path):
    """Open an .xlsx and recover if COM returns None or hits Protected View."""
    path = os.path.abspath(path)
    fname = os.path.basename(path).lower()
    before = excel.Workbooks.Count
    wb = None

    # 1) Normal open with explicit kwargs (helps late-binding)
    try:
        wb = excel.Workbooks.Open(
            Filename=path,
            ReadOnly=True,
            UpdateLinks=0,
            IgnoreReadOnlyRecommended=True,
            Notify=False,
            Editable=False,
        )
    except Exception as e:
        msg = str(e).lower()
        # 2) Protected View fallback
        if "protected view" in msg or "cannot be opened because" in msg:
            logger.info("Opening via ProtectedViewWindows then editing...")
            pv = excel.ProtectedViewWindows.Open(path, False, "")
            wb = pv.Edit()

    # 3) If COM returned None, attach to the just-opened workbook
    if not wb:
        time.sleep(0.3)  # give Excel a moment
        after = excel.Workbooks.Count
        if after > before:
            for i in range(1, excel.Workbooks.Count + 1):
                w = excel.Workbooks(i)
                try:
                    if (
                        getattr(w, "FullName", "") or ""
                    ).lower() == path.lower() or (
                        getattr(w, "Name", "") or ""
                    ).lower() == fname:
                        wb = w
                        break
                except Exception:
                    continue

    if not wb:
        raise RuntimeError(
            f"Excel did not return a Workbook for '{path}'. "
            "Check file path, Protected View, permissions, and run context."
        )
    return wb


def get_excel_app():
    """Start Excel with robust handling for pywin32 gen_py cache corruption."""
    try:
        # Preferred: early-binding (faster; typed constants)
        return gencache.EnsureDispatch("Excel.Application")
    except Exception as e:
        msg = str(e)
        # Detect the known cache-corruption signature
        if "CLSIDToClassMap" in msg or "gen_py" in msg:
            logger.warning(
                "win32com gen_py cache looks corrupted; rebuilding it once..."
            )
            try:
                # Remove both the normal and temp generate paths
                paths = set()
                try:
                    paths.add(gencache.GetGeneratePath())  # type: ignore
                except Exception:
                    pass
                try:
                    paths.add(gencache.GetTempGeneratePath())  # type: ignore
                except Exception:
                    pass

                for p in filter(None, paths):
                    if os.path.exists(p):
                        shutil.rmtree(p, ignore_errors=True)

                # Ensure cache is writable and rebuild
                gencache.is_readonly = False  # type: ignore
                gencache.Rebuild()  # type: ignore

                # Retry early-binding
                return gencache.EnsureDispatch("Excel.Application")
            except Exception as rebuild_err:
                logger.warning(
                    f"Rebuild failed ({rebuild_err}); falling back to late-binding..."
                )

        # Late-binding fallback avoids importing broken gen_py modules
        return client.Dispatch("Excel.Application")


def cell_format(
    workbook,
    is_last_row=False,
    criteria_failed=False,
    is_new_hs=False,
    is_int=False,
):
    format_dict = {"border": 1}  # default thin border

    if is_int:
        format_dict["num_format"] = "0"  # type: ignore
    else:
        format_dict["num_format"] = "0.00"  # type: ignore

    if criteria_failed:
        format_dict["bg_color"] = "red"  # type: ignore

    if is_last_row or is_new_hs:
        format_dict["bottom"] = 5  # thick bottom border

    return workbook.add_format(format_dict)


def xl_write_header(workbook, worksheet, config, current_row):
    """
    Writes the header entry from the input file to the weather_window spreadsheet

    Args:
        workbook (obj):     Excel spreadsheet object
        worksheet (obj):    Excel spreadsheet sheet object
        config (dict):      Configuration dictionary with the input
        current_row (int):  Counter to track the current row being written

    Returns:
        current_row:        Last row written + 1
    """
    bold_right = workbook.add_format({"bold": True, "align": "right"})
    bold = workbook.add_format({"bold": True})

    worksheet.write(current_row, 3, "Base File: ", bold_right)
    worksheet.write(current_row, 4, config.get("base_file"))
    current_row += 1

    worksheet.write(current_row, 3, "Base File OF Version: ", bold_right)
    worksheet.write(current_row, 4, config.get("base_file_version"))
    current_row += 1

    file_path = config.get("base_file")
    timestamp = os.path.getmtime(file_path)
    modified_time = datetime.datetime.fromtimestamp(timestamp)
    formatted_time = modified_time.strftime("%Y-%m-%d %H:%M:%S")
    worksheet.write(current_row, 3, "Base File Save Date: ", bold_right)
    worksheet.write(current_row, 4, formatted_time)
    current_row += 1

    worksheet.write(current_row, 3, "Run using RLC Version: ", bold_right)
    worksheet.write(current_row, 4, __version__)
    current_row += 1

    current_row += 1

    worksheet.write(current_row, 1, "Header from input file:", bold)
    current_row += 1
    header = config.get("header", "")
    header_lines = header.splitlines()

    for line in header_lines:
        worksheet.write(current_row, 1, line)  # Column B is index 1
        current_row += 1

    return current_row


def xl_write_weather_window(workbook, worksheet, config, current_row):
    """
    Writes the weather window table to the weather_window spreadsheet

    Args:
        workbook (obj):     Excel spreadsheet object
        worksheet (obj):    Excel spreadsheet sheet object
        config (dict):      Configuration dictionary with the input
        current_row (int):  Counter to track the current row being written

    Returns:
        current_row:        Last row written + 1
    """

    # Add a blank row
    current_row += 1
    bold_left = workbook.add_format(
        {"bold": True, "align": "left", "valign": "vcenter"}
    )
    worksheet.write(
        current_row, 1, "Allowable Weather Window Table", bold_left
    )
    current_row += 1

    # Connect to the SQLite database
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        cursor.execute("SELECT DISTINCT hs FROM case_results")
        hs_values = sorted([row[0] for row in cursor.fetchall()])

        cursor.execute("SELECT DISTINCT period FROM case_results")
        period_values = sorted([row[0] for row in cursor.fetchall()])

        cursor.execute("SELECT hs, period, status FROM case_results")
        results = {
            (hs, period): status for hs, period, status in cursor.fetchall()
        }

    # Define formats
    style_header = workbook.add_format(
        {
            "bold": True,
            "bg_color": "#C0C0C0",
            "align": "center",
            "valign": "vcenter",
            "border": 1,
        }
    )
    style_ok = workbook.add_format(
        {
            "bg_color": "#00FF00",
            "align": "center",
            "valign": "vcenter",
            "border": 1,
        }
    )
    style_ng = workbook.add_format(
        {
            "bg_color": "#FF0000",
            "align": "center",
            "valign": "vcenter",
            "border": 1,
        }
    )
    style_na = workbook.add_format(
        {"align": "center", "valign": "vcenter", "border": 1}
    )

    # Write header row (periods)
    for col_index, period in enumerate(
        period_values, start=2
    ):  # Column C is index 2
        worksheet.write(current_row, col_index, period, style_header)

    # Left Corner Cell
    worksheet.write(
        current_row, 1, f"Hsd/{config.get('period_type')}", style_header
    )

    # Write hs values and status cells
    # Reduce Hs for alpha factor
    alpha_factor = config.get("alpha_factor")
    for row_index, hs in enumerate(hs_values, start=current_row + 1):
        worksheet.write(
            row_index, 1, hs * alpha_factor, style_header
        )  # hs in column B
        for col_index, period in enumerate(period_values, start=2):
            status = results.get((hs, period), "")
            if status == "OK":
                fmt = style_ok
            elif status == "NG":
                fmt = style_ng
            else:
                fmt = style_na

            worksheet.write(row_index, col_index, status, fmt)

    current_row = row_index + 1  # type: ignore

    worksheet.write(
        current_row,
        1,
        "- 'X' indicates cases where the Hs is too great for the period",
        bold_left,
    )
    current_row += 1
    worksheet.write(
        current_row,
        1,
        "- Hs is in meters, Period is in seconds",
        bold_left,
    )
    current_row += 1
    worksheet.write(
        current_row,
        1,
        "- Tp (spectral peak period) and Tz (zero-crossing period) are different parameters and cannot be interchanged.",
        bold_left,
    )
    current_row += 1
    if alpha_factor != 1:
        worksheet.write(
            current_row,
            1,
            f"- Hs has been reduced by an alpha factor of {alpha_factor}",
            bold_left,
        )
    else:
        worksheet.write(
            current_row,
            1,
            "- No alpha factor was specified for this analysis",
            bold_left,
        )
    current_row += 2

    return current_row  # type: ignore


def xl_write_summary_table(workbook, worksheet, config, current_row):
    """
    Writes the summary table to the weather_window spreadsheet

    Args:
        workbook (obj):     Excel spreadsheet object
        worksheet (obj):    Excel spreadsheet sheet object
        config (dict):      Configuration dictionary with the input
        current_row (int):  Counter to track the current row being written

    Returns:
        current_row:        Last row written + 1
    """

    # defines some styles to be used in the table
    style_header = workbook.add_format(
        {
            "bold": True,
            "bg_color": "gray",
            "align": "center",
            "border": True,
            "text_wrap": True,
        }
    )
    style_zero_waves = workbook.add_format(
        {
            "align": "center",
            "border": True,
            "num_format": "0.00",
            "italic": True,
            "bottom": 5,
        }
    )
    style_num_table = workbook.add_format(
        {"num_format": "0.00", "border": True}
    )

    style_thick_bottom = workbook.add_format(
        {"num_format": "0.00", "border": True, "bottom": 5}
    )

    bold_left = workbook.add_format(
        {"bold": True, "align": "left", "valign": "vcenter"}
    )

    # Table Title
    worksheet.write(
        current_row,
        1,
        "Summary of Loads for Limiting Acceptable Sea States",
        bold_left,
    )
    current_row += 1

    # Top Row
    worksheet.write(current_row, 1, "Hsd\n[m]", style_header)
    if config.get("period_type") == "Tp":
        worksheet.write(current_row, 2, "Tp\n[s]", style_header)
    else:
        worksheet.write(current_row, 2, "Tz\n[s]", style_header)

    first_criteria_column = 3

    # Criteria List
    for i, criterion in enumerate(config.get("analysis_criteria")):
        worksheet.write(
            current_row,
            first_criteria_column + i,
            utils.construct_criterion_name_no_prob_no_mag(criterion),
            style_header,
        )
    current_row += 1

    # mode Parameter
    worksheet.merge_range(current_row, 1, current_row, 2, "Mode", style_header)
    for i, criterion in enumerate(config.get("analysis_criteria")):
        worksheet.write(
            current_row,
            first_criteria_column + i,
            criterion["mode"],
            style_header,
        )
    current_row += 1

    # Criteria Limits
    worksheet.merge_range(
        current_row, 1, current_row, 2, "Limit", style_header
    )
    for i, criterion in enumerate(config.get("analysis_criteria")):
        worksheet.write(
            current_row,
            first_criteria_column + i,
            criterion["value"],
            style_header,
        )
    current_row += 1

    # Probability Level
    worksheet.merge_range(
        current_row, 1, current_row, 2, "Probability Level", style_header
    )
    for i, criterion in enumerate(config.get("analysis_criteria")):
        worksheet.write(
            current_row,
            first_criteria_column + i,
            criterion["probability_level"],
            style_header,
        )
    current_row += 1

    zero_wave_results = _load_zero_wave_results()

    # Units
    worksheet.merge_range(
        current_row, 1, current_row, 2, "Units", style_header
    )
    for i, criterion in enumerate(config.get("analysis_criteria")):
        for entry in zero_wave_results:
            if (
                entry.get("orcaflex_object_name")
                == criterion.get("orcaflex_object_name")
                and entry.get("orcaflex_object_parameter")
                == criterion.get("orcaflex_object_parameter")
                and entry.get("mode") == criterion.get("mode")
                and (
                    criterion.get("orcaflex_object_argument") is None
                    or entry.get("orcaflex_object_argument")
                    == criterion.get("orcaflex_object_argument")
                )
            ):
                worksheet.write(
                    current_row,
                    first_criteria_column + i,
                    entry.get("units"),
                    style_header,
                )
    current_row += 1

    worksheet.merge_range(
        current_row, 1, current_row, 2, "No waves", style_zero_waves
    )
    for i, criterion in enumerate(config.get("analysis_criteria")):
        for entry in zero_wave_results:
            if (
                entry.get("orcaflex_object_name")
                == criterion.get("orcaflex_object_name")
                and entry.get("orcaflex_object_parameter")
                == criterion.get("orcaflex_object_parameter")
                and entry.get("mode") == criterion.get("mode")
                and (
                    criterion.get("orcaflex_object_argument") is None
                    or entry.get("orcaflex_object_argument")
                    == criterion.get("orcaflex_object_argument")
                )
            ):
                worksheet.write(
                    current_row,
                    first_criteria_column + i,
                    float(entry.get("value")),
                    style_zero_waves,
                )

    current_row += 1

    # Results for each period
    # Get list of unique periods from rlc_results.db database table case_results
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT period FROM case_results")
        periods = [row[0] for row in cursor.fetchall()]

    # Get alpha_factor
    alpha_factor = config.get("alpha_factor")

    # Filter the case_results table for each period.  Find the largest hs value that has a status of "OK."
    # Report the values for each criteria.
    current_hs = 0
    for period in periods:
        # Get the largest hs value for the period that has a status of "OK"
        cursor.execute(
            """
            SELECT MAX(hs) FROM case_results
            WHERE period = ? AND status = 'OK'
        """,
            (period,),
        )
        largest_hs = cursor.fetchone()[0]

        # If there is no "OK" status for the period, skip to the next period
        if largest_hs is None:
            continue

        # Get the criteria values for the largest hs value
        cursor.execute(
            """
            SELECT * FROM case_results
            WHERE hs = ? AND period = ?
        """,
            (largest_hs, period),
        )
        # Get the values from the table and store in dictionary according to column heading

        criteria_values = {
            utils.criteria_to_column_name(criterion): value
            for criterion, value in zip(
                config.get("analysis_criteria"),
                cursor.fetchone()[5:],
            )
        }

        # Write the period and hs values
        if largest_hs == current_hs:
            hs_style = style_num_table
        else:
            hs_style = style_thick_bottom
            current_hs = largest_hs

        # Reduce Hs for alpha factor
        worksheet.write(current_row, 1, largest_hs * alpha_factor, hs_style)
        worksheet.write(current_row, 2, period, hs_style)

        # Write the criteria values
        for i, criterion in enumerate(config.get("analysis_criteria")):
            worksheet.write(
                current_row,
                first_criteria_column + i,
                criteria_values[utils.criteria_to_column_name(criterion)],
                hs_style,
            )

        current_row += 1

    # Add a note to the bottom of the table
    if alpha_factor != 1:
        worksheet.write(
            current_row,
            1,
            f"- Hs has been reduced by an alpha factor of {alpha_factor}",
            bold_left,
        )
    else:
        worksheet.write(
            current_row,
            1,
            "- No alpha factor was specified for this analysis",
            bold_left,
        )
    # Add a blank row
    current_row += 2
    return current_row


def xl_write_detailed_table(workbook, worksheet, config, current_row):
    """
    Writes the detailed results table to the weather_window spreadsheet

    Args:
        workbook (obj):     Excel spreadsheet object
        worksheet (obj):    Excel spreadsheet sheet object
        config (dict):      Configuration dictionary with the input
        current_row (int):  Counter to track the current row being written

    Returns:
        current_row:        Last row written + 1
    """

    # defines some styles to be used in the table
    style_header = workbook.add_format(
        {
            "bold": True,
            "bg_color": "gray",
            "align": "center",
            "border": True,
            "text_wrap": True,
        }
    )
    style_zero_waves = workbook.add_format(
        {
            "align": "center",
            "border": True,
            "num_format": "0.00",
            "italic": True,
            "bottom": 5,
        }
    )
    style_num_table = workbook.add_format(
        {"num_format": "0.00", "border": True}
    )

    style_num_table_seeds = workbook.add_format(
        {"num_format": "0", "border": True}
    )

    style_thick_bottom = workbook.add_format(
        {"num_format": "0.00", "border": True, "bottom": 5}
    )

    style_thick_bottom_seeds = workbook.add_format(
        {"num_format": "0", "border": True, "bottom": 5}
    )

    bold_left = workbook.add_format(
        {"bold": True, "align": "left", "valign": "vcenter"}
    )

    # Table Title
    worksheet.write(
        current_row, 1, "Full Table with Loads for all Sea States ", bold_left
    )
    current_row += 1

    # Top Row
    worksheet.write(current_row, 1, "Hsd\n[m]", style_header)
    if config.get("period_type") == "Tp":
        worksheet.write(current_row, 2, "Tp\n[s]", style_header)
    else:
        worksheet.write(current_row, 2, "Tz\n[s]", style_header)
    worksheet.write(current_row, 3, "Wave Dir\n[m]", style_header)
    worksheet.write(current_row, 4, "Number Seeds Run", style_header)

    first_criteria_column = 5

    # Criteria List
    for i, criterion in enumerate(config.get("analysis_criteria")):
        worksheet.write(
            current_row,
            5 + i,
            utils.construct_criterion_name_no_prob_no_mag(criterion),
            style_header,
        )
    current_row += 1

    # Mode Parameter
    worksheet.merge_range(current_row, 1, current_row, 4, "Mode", style_header)
    for i, criterion in enumerate(config.get("analysis_criteria")):
        worksheet.write(
            current_row,
            first_criteria_column + i,
            criterion["mode"],
            style_header,
        )
    current_row += 1

    # Criteria Limits
    worksheet.merge_range(
        current_row,
        1,
        current_row,
        first_criteria_column - 1,
        "Limit",
        style_header,
    )
    for i, criterion in enumerate(config.get("analysis_criteria")):
        worksheet.write(
            current_row,
            first_criteria_column + i,
            criterion["value"],
            style_header,
        )
    current_row += 1

    # Probability Level
    worksheet.merge_range(
        current_row,
        1,
        current_row,
        first_criteria_column - 1,
        "Probability Level",
        style_header,
    )
    for i, criterion in enumerate(config.get("analysis_criteria")):
        worksheet.write(
            current_row,
            first_criteria_column + i,
            criterion["probability_level"],
            style_header,
        )
    current_row += 1

    # Units
    worksheet.merge_range(
        current_row,
        1,
        current_row,
        first_criteria_column - 1,
        "Units",
        style_header,
    )

    zero_wave_results = _load_zero_wave_results()

    for i, criterion in enumerate(config.get("analysis_criteria")):
        for entry in zero_wave_results:
            if (
                entry.get("orcaflex_object_name")
                == criterion.get("orcaflex_object_name")
                and entry.get("orcaflex_object_parameter")
                == criterion.get("orcaflex_object_parameter")
                and entry.get("mode") == criterion.get("mode")
                and (
                    criterion.get("orcaflex_object_argument") is None
                    or entry.get("orcaflex_object_argument")
                    == criterion.get("orcaflex_object_argument")
                )
            ):
                worksheet.write(
                    current_row,
                    first_criteria_column + i,
                    entry.get("units"),
                    style_header,
                )

    current_row += 1

    worksheet.merge_range(
        current_row,
        1,
        current_row,
        first_criteria_column - 1,
        "No waves",
        style_zero_waves,
    )

    for i, criterion in enumerate(config.get("analysis_criteria")):
        for entry in zero_wave_results:
            if (
                entry.get("orcaflex_object_name")
                == criterion.get("orcaflex_object_name")
                and entry.get("orcaflex_object_parameter")
                == criterion.get("orcaflex_object_parameter")
                and entry.get("mode") == criterion.get("mode")
                and (
                    criterion.get("orcaflex_object_argument") is None
                    or entry.get("orcaflex_object_argument")
                    == criterion.get("orcaflex_object_argument")
                )
            ):
                worksheet.write(
                    current_row,
                    first_criteria_column + i,
                    float(entry.get("value")),
                    style_zero_waves,
                )

    current_row += 1

    # Get list of unique hs from rlc_results.db database table stat_results
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT hs FROM stat_results")
        # hss = sorted([row[0] for row in cursor.fetchall()])

    # Get list of unique periods from rlc_results.db database table stat_results
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT period FROM stat_results")
        # periods = sorted([row[0] for row in cursor.fetchall()])

    # Results for each wave_dir
    # Get list of unique wave_dir from rlc_results.db database table stat_results
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT wave_dir FROM stat_results")
        # wave_dirs = sorted([row[0] for row in cursor.fetchall()])

    first_probabilistic_result = utils.criteria_to_column_name(
        config.get("analysis_criteria")[0]
    )

    # Get alpha_factor
    alpha_factor = config.get("alpha_factor")

    # Get table of values
    utils.custom_execute(
        cursor,
        f"""
        SELECT *
        FROM stat_results
        WHERE "{first_probabilistic_result}" IS NOT NULL
        ORDER BY hs ASC, period ASC, wave_dir ASC;
        """,
    )

    rows = cursor.fetchall()

    for i, row in enumerate(rows):
        rowid, hs, period, wave_dir, no_seeds = row[:5]

        criteria_values = {
            utils.criteria_to_column_name(criterion): value
            for criterion, value in zip(
                config.get("analysis_criteria"),
                row[6:],
            )
        }

        # Write the period and hs values
        if i == len(rows) - 1:
            is_last_row = True
            is_new_hs = False
        else:
            is_last_row = False

            if rows[i + 1][1] != hs:
                is_new_hs = True
            else:
                is_new_hs = False

        if i == len(rows) - 1:
            hs_style = style_thick_bottom
            seed_style = style_thick_bottom_seeds
        else:
            if rows[i + 1][1] != hs:
                # This is the last row for that Hs
                hs_style = style_thick_bottom
                seed_style = style_thick_bottom_seeds
            else:
                hs_style = style_num_table
                seed_style = style_num_table_seeds

        worksheet.write(current_row, 1, hs * alpha_factor, hs_style)
        worksheet.write(current_row, 2, period, hs_style)
        worksheet.write(current_row, 3, wave_dir, hs_style)
        worksheet.write(current_row, 4, no_seeds, seed_style)  # type: ignore

        # Write the criteria values
        for i, criterion in enumerate(config.get("analysis_criteria")):
            # Check to see if criteria exceeds limit

            criteria_failed = False
            if config.get("analysis_criteria")[i].get("mode") == "max":
                if criteria_values[
                    utils.criteria_to_column_name(criterion)
                ] > config.get("analysis_criteria")[i].get("value"):
                    # Criteria Failed
                    criteria_failed = True

            if config.get("analysis_criteria")[i].get("mode") == "min":
                if criteria_values[
                    utils.criteria_to_column_name(criterion)
                ] < config.get("analysis_criteria")[i].get("value"):
                    # Criteria Failed
                    criteria_failed = True

            worksheet.write(
                current_row,
                first_criteria_column + i,
                criteria_values[utils.criteria_to_column_name(criterion)],
                cell_format(
                    workbook,
                    is_last_row=is_last_row,
                    criteria_failed=criteria_failed,
                    is_new_hs=is_new_hs,
                ),
            )

        current_row += 1
    if alpha_factor != 1:
        worksheet.write(
            current_row,
            1,
            f"- Hs has been reduced by an alpha factor of {alpha_factor}",
            bold_left,
        )
    else:
        worksheet.write(
            current_row,
            1,
            "- No alpha factor was specified for this analysis",
            bold_left,
        )
    current_row += 2

    return current_row


def is_file_locked(filepath):
    """Check if a file is locked by trying to open it in append mode."""
    if not os.path.exists(filepath):
        return False
    try:
        with open(filepath, "a"):
            return False
    except PermissionError:
        return True


def get_attempt_path(attempt):
    """Generate the path for weather_window ({attempt}).xlsx."""
    # Extract the directory and file name from WEATHER_WINDOW_XLSX_PATH
    directory = os.path.dirname(cfg.WEATHER_WINDOW_XLSX_PATH)  # results
    filename = os.path.basename(
        cfg.WEATHER_WINDOW_XLSX_PATH
    )  # weather_window.xlsx
    # Split filename into name and extension
    name, ext = os.path.splitext(filename)  # weather_window, .xlsx
    # Construct the new filename with attempt number
    attempt_filename = f"{name} ({attempt}){ext}"
    # Return the full path
    return os.path.join(directory, attempt_filename)


_ZERO_WAVE_JSON = os.path.join(
    "runs", "Hs0.00_T08.00_WD180_seed1_results.json"
)


def _load_zero_wave_results():
    """Load the zero-wave JSON, raising a clear error if it is missing."""
    if not os.path.exists(_ZERO_WAVE_JSON):
        raise FileNotFoundError(
            f"Zero-wave results file not found: '{_ZERO_WAVE_JSON}'.\n"
            "The zero-wave case did not complete or its output is unavailable.\n"
            "Please run the zero-wave case manually "
            "(Hs=0.00 m, T=8.00 s, WD=180°, seed 1) and re-run RLC."
        )
    with open(_ZERO_WAVE_JSON, "r") as f:
        return json.load(f)["results"]


def create_weather_window_file(config):
    _load_zero_wave_results()  # fail early with a clear message if missing
    current_row = 0
    attempt = 1
    final_xlsx_path = cfg.WEATHER_WINDOW_XLSX_PATH

    # If the base file is locked, choose "weather_window (n).xlsx"
    while is_file_locked(cfg.WEATHER_WINDOW_XLSX_PATH):
        final_xlsx_path = get_attempt_path(attempt)
        attempt += 1

    if final_xlsx_path != cfg.WEATHER_WINDOW_XLSX_PATH:
        logger.info(
            f"File {cfg.WEATHER_WINDOW_XLSX_PATH} is locked. "
            f"Saving as {final_xlsx_path}"
        )
    else:
        logger.info(f"Creating {final_xlsx_path}...")

    workbook = xlsxwriter.Workbook(final_xlsx_path)
    worksheet = workbook.add_worksheet("weather_window")

    # Write sections
    current_row = xl_write_header(workbook, worksheet, config, current_row)
    current_row = xl_write_weather_window(
        workbook, worksheet, config, current_row
    )
    current_row = xl_write_summary_table(
        workbook, worksheet, config, current_row
    )
    current_row = xl_write_detailed_table(
        workbook, worksheet, config, current_row
    )

    workbook.close()
    logger.info(f"Workbook saved as {final_xlsx_path}")

    return final_xlsx_path


def convert_excel_to_pdf(xlsx_path=None, pdf_path=None):
    xlsx_path = os.path.abspath(xlsx_path or cfg.WEATHER_WINDOW_XLSX_PATH)
    pdf_path = os.path.abspath(pdf_path or cfg.WEATHER_WINDOW_PDF_PATH)

    if not os.path.exists(xlsx_path):
        logger.error(f"Excel file not found: {xlsx_path}")
        return

    logger.info(f"Converting {os.path.basename(xlsx_path)} to PDF")

    excel = None
    workbook = None
    try:
        excel = (
            get_excel_app_late_bound()
        )  # fresh instance; avoids gen_py entirely
        logger.info("Excel version: %s", getattr(excel, "Version", "unknown"))

        # Open robustly (handles Protected View and None returns)
        workbook = open_workbook_robust(excel, xlsx_path)

        # Grab the sheet (try Worksheets then Sheets)
        try:
            sheet = workbook.Worksheets("weather_window")
        except Exception:
            sheet = workbook.Sheets("weather_window")

        # Page setup: 1 page wide, unlimited tall
        ps = sheet.PageSetup
        ps.Zoom = False
        ps.FitToPagesWide = 1
        ps.FitToPagesTall = False

        os.makedirs(os.path.dirname(pdf_path), exist_ok=True)

        sheet.ExportAsFixedFormat(
            Type=0,  # PDF
            Filename=pdf_path,
            Quality=0,  # standard
            IncludeDocProperties=True,
            IgnorePrintAreas=False,
            OpenAfterPublish=False,
        )
        logger.info(f"PDF file created successfully at {pdf_path}")

    except Exception as e:
        logger.error(f"Failed during PDF export: {e}", exc_info=True)
    finally:
        if workbook is not None:
            try:
                workbook.Close(False)
            except Exception as e:
                logger.error(f"Error closing workbook: {e}")
        if excel is not None:
            try:
                excel.Quit()
            except Exception as e:
                logger.error(f"Error quitting Excel: {e}")


def db_to_spreadsheet(
    db_path=cfg.LOCAL_DB_PATH, excel_path=cfg.RLC_RESULTS_PATH
):
    used_sheet_names = set()

    def get_unique_sheet_name(base_name):
        name = base_name[:31]
        if name not in used_sheet_names:
            used_sheet_names.add(name)
            return name

        for i in range(1, 1000):
            suffix = f"_{i}"
            truncated = name[: 31 - len(suffix)] + suffix
            if truncated not in used_sheet_names:
                used_sheet_names.add(truncated)
                return truncated

        raise ValueError("Too many duplicate sheet names.")

    logger.info(f"Starting export from '{db_path}' to '{excel_path}'")

    workbook = xlsxwriter.Workbook(excel_path)
    logger.info("Excel workbook created.")

    # Define header format
    header_format = workbook.add_format(
        {
            "bold": True,
            "bg_color": "#D3D3D3",  # light grey
            "border": 1,
            "text_wrap": True,
        }
    )

    # Define data cell format
    data_format = workbook.add_format({"border": 1})

    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        logger.info("Connected to SQLite database.")

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [t[0] for t in cursor.fetchall()]
        logger.info(f"Found {len(tables)} tables.")

        # Ensure sqlite_sequence is first
        priority_order = [
            "sqlite_sequence",
            "case_results",
            "stat_results",
            "seed_results",
        ]
        tables_sorted = sorted(
            tables,
            key=lambda x: (
                priority_order.index(x)
                if x in priority_order
                else len(priority_order),
                x,
            ),
        )

        for table_name in tables_sorted:
            sheet_name = get_unique_sheet_name(table_name)
            worksheet = workbook.add_worksheet(sheet_name)
            logger.info(
                f"Writing table '{table_name}' to sheet '{sheet_name}'"
            )

            # Write full table name in A1
            worksheet.write("A1", f"Table: {table_name}")

            # Get column names
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [info[1] for info in cursor.fetchall()]

            # Write column headers starting at row 1 (Excel row 2)
            for col_num, col_name in enumerate(columns):
                worksheet.write(1, col_num, col_name, header_format)

            # Get all rows from the table
            cursor.execute(f"SELECT * FROM {table_name}")
            rows = cursor.fetchall()

            # Write data rows starting at row 2 (Excel row 3)
            for row_num, row in enumerate(rows, start=2):
                for col_num, cell in enumerate(row):
                    worksheet.write(row_num, col_num, cell, data_format)

    workbook.close()
    logger.info(f"{cfg.WEATHER_WINDOW_PREFIX}.xlsx file created.")


def rlc_output(config):
    # Create Weather Window file and capture the real path
    xlsx_path = create_weather_window_file(config)

    # Convert that exact file to PDF
    convert_excel_to_pdf(
        xlsx_path=xlsx_path, pdf_path=cfg.WEATHER_WINDOW_PDF_PATH
    )

    # Export DB tables to a separate Excel workbook
    db_to_spreadsheet()
    # Export DB tables to a separate Excel workbook
    db_to_spreadsheet()
