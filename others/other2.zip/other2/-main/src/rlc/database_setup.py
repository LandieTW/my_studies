import hashlib
import logging
import os
import random
import sqlite3
import sys
from decimal import Decimal

import rlc.config as cfg
import rlc.utils as utils

logger = logging.getLogger("RLC")


def identify_X_cases(config):
    # Open Database and Identify Cases that will never be run
    # Period is below min period per DNv-RP-N103
    # Skip if calculate_min_period is disabled
    if not config.get("calculate_min_period", True):
        return
    # Connect to the database
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        results_tables = ["case_results", "stat_results", "seed_results"]

        for table in results_tables:
            # Case Result Table
            # Fetch all rows from table
            utils.custom_execute(
                cursor, f"SELECT rowid, hs, period FROM {table}"
            )
            rows = cursor.fetchall()

            # Iterate through each row
            for row in rows:
                rowid, hs, period = row
                # Check if the row meets the criteria
                if utils.check_period_against_dnv_min(
                    hs, period, config["period_type"]
                ):
                    # Update the status column with 'X' for this row
                    utils.custom_execute(
                        cursor,
                        f"UPDATE {table} SET status = ? WHERE rowid = ?",
                        ("X", rowid),
                    )


def generate_unique_integers(
    int_val: int, float1: float, float2: float, float3: float, count: int
) -> list[int]:
    """Generate a list of unique integers based on the provided parameters.
    This function uses the provided integer and float values to create a unique seed
    for a random number generator, ensuring that the generated integers are repeatable
    and unique for the same input values.
    Args:
        int_val (int): An integer value to be used in the seed generation from the input file.
        float1 (float): A float value to be used in the seed generation (hs)
        float2 (float): Another float value to be used in the seed generation (period)
        float3 (float): A third float value to be used in the seed generation (wave_dir)
        count (int): The number of unique integers to generate (based on min_seed or probability level).

    Returns:
        list[int]: A list of unique integers generated based on the input parameters.
    """

    # Combine all inputs into a single string
    input_string = f"{int_val}-{float1}-{float2}-{float3}"

    # Create a SHA-256 hash of the input string
    hash_digest = hashlib.sha256(input_string.encode()).hexdigest()

    # Convert the hash to an integer and use it as a seed
    seed = int(hash_digest, 16)
    rng = random.Random(seed)

    # Generate a list of repeatable random integers
    return [rng.randint(-(2**31), 2**31 - 1) for _ in range(count)]


def case_dict(config):
    """
    Generate a list of cases based on the configuration.

    This function creates a list of cases to be processed based on the provided configuration.
    It extracts the necessary parameters from the configuration dictionary and returns a list of tuples,
    where each tuple represents a case with its parameters.

    Args:
        config (dict): The configuration dictionary containing parameters for the cases.

    Returns:
        list: A list of tuples, each representing a case with its parameters.
    """
    hs_start = Decimal(str(config.get("hs_start")))
    hs_fine_step = Decimal(str(config.get("hs_fine_step")))
    hs_min = Decimal(str(config.get("hs_min")))
    t_end = Decimal(str(config.get("t_end")))
    t_start = Decimal(str(config.get("t_start")))
    t_step = Decimal(str(config.get("t_step")))
    t_step2 = Decimal(str(config.get("t_step2")))
    t_step_change = Decimal(str(config.get("t_step_change")))
    wave_dirs = config.get("wave_dirs")

    hs = hs_start
    # Create List of Potential hs values
    hs_list = []
    while True:
        hs_list.append(float(hs))
        hs -= Decimal(hs_fine_step)
        if hs < hs_min:
            logger.debug(hs_list)
            break

    # Create List of Potential Periods
    period_list = []
    period = t_start
    while True:
        period_list.append(float(period))
        if period >= t_step_change:
            period += t_step2
        else:
            period += t_step
        if period > t_end:
            logger.debug(period_list)
            break

    cases_dict = {}
    for hs in hs_list:
        for period in period_list:
            for wave_dir in wave_dirs:
                case_key = (hs, period, wave_dir)
                cases_dict[case_key] = {
                    "hs": float(hs),
                    "period": float(period),
                    "wave_dir": wave_dir,
                }

    logger.debug(
        f"Generated {len(cases_dict)} cases based on the configuration."
    )
    # Output the cases to the debug logger
    for case in cases_dict:
        logger.debug(f"Case: {case} -> {cases_dict[case]}")

    return cases_dict


def setup_database(config):
    """
    Set up the database for the RLC application.

    This function initializes the database connection and creates necessary tables.
    It should be called at the start of the application to ensure the database is ready for use.

    Args:
        None
    Returns:
        sqlite3.Connection: The database connection object.
    """

    logger.info("Setting up the database...")
    min_seeds = config.get("min_seeds")

    # Delete the existing local temp database file if it exists
    if os.path.exists(cfg.LOCAL_DB_PATH):
        try:
            os.remove(cfg.LOCAL_DB_PATH)
            logger.debug("Existing local temp database removed.")
        except OSError as e:
            logger.error(f"Cannot delete local temp database: {e}")
            sys.exit(0)

    # Delete the existing network database file if it exists
    if os.path.exists(cfg.DATABASE_PATH):
        try:
            # Check if the file is accessible (not locked)
            with open(cfg.DATABASE_PATH, "a"):
                logger.debug("Database file is accessible for appending.")
            os.remove(cfg.DATABASE_PATH)
            logger.info(
                "Existing database file 'rlc_results.db' removed successfully."
            )
        except (PermissionError, OSError) as e:
            logger.error(
                f"Error: Cannot delete the database file 'rlc_results.db'. "
                f"It may be in use by another process or you lack permissions: {e}"
            )
            logger.info(
                "Please ensure the database is not open in another application and try again."
            )
            sys.exit(0)  # Controlled exit with error code
        except Exception as e:
            logger.error(
                f"Unexpected error while attempting to delete 'rlc_results.db': {e}"
            )
            sys.exit(0)  # Controlled exit for unexpected errors

    # Create and connect the sqlite database (local temp path)
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        #############################
        # Setup 'case_results' table
        #############################
        logger.info("Setting up 'case_results' table in 'rcl_results.db' ...")
        # Base columns for the case results table
        case_columns = [
            "hs REAL",
            "period REAL",
            "status TEXT",
            "no_seeds INT",
        ]
        # Generate dynamic columns from acceptance criteria
        for criterion in config.get("analysis_criteria", []):
            # Build the column name based on the criterion
            # Omit orcaflex_object_argument if it is not provided
            if criterion.get("orcaflex_object_argument") is None:
                col_name = f"{criterion['orcaflex_object_name']}_{criterion['orcaflex_object_parameter']}_{criterion['probability_level']}_{criterion['mode']}"
            else:
                # Include orcaflex_object_argument in the column name
                col_name = f"{criterion['orcaflex_object_name']}_{criterion['orcaflex_object_argument']}_{criterion['orcaflex_object_parameter']}_{criterion['probability_level']}_{criterion['mode']}"

            col_name = col_name.replace(
                " ", "_"
            )  # Ensure valid SQLite column name
            col_name = f'"{col_name}" REAL'
            if col_name not in case_columns:
                case_columns.append(col_name)

        for col in case_columns:
            logger.debug(f"{col}")

        # SQL to create the table
        rcl_case_results_sql = f"""
        CREATE TABLE IF NOT EXISTS case_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            {", ".join(case_columns)},
            UNIQUE(hs, period)
        );
        """
        utils.custom_execute(cursor, rcl_case_results_sql)

        # Generate the case list based on the configuration
        cases = case_dict(config)
        # Insert the case list into the database

        for case in cases.values():
            rlc_case_sql = """
            INSERT OR IGNORE INTO case_results (hs, period, status, no_seeds)
            VALUES (?, ?, ?, ?);
            """
            utils.custom_execute(
                cursor,
                rlc_case_sql,
                (case["hs"], case["period"], "-", min_seeds),
            )

        #############################
        # Setup 'stat_results' table
        #############################
        # Create the database for full results
        logger.info("Setting up 'stat_results' table in 'rcl_results.db' ...")

        columns = [
            "hs REAL",
            "period REAL",
            "wave_dir REAL",
            "no_seeds INT",
            "status TEXT",
        ]

        # Generate dynamic columns from acceptance criteria
        for criterion in config.get("analysis_criteria", []):
            # Build the column name based on the criterion
            # Omit orcaflex_object_argument if it is not provided
            if criterion.get("orcaflex_object_argument") is None:
                col_name = f"{criterion['orcaflex_object_name']}_{criterion['orcaflex_object_parameter']}_{criterion['probability_level']}_{criterion['mode']}"
            else:
                # Include orcaflex_object_argument in the column name
                col_name = f"{criterion['orcaflex_object_name']}_{criterion['orcaflex_object_argument']}_{criterion['orcaflex_object_parameter']}_{criterion['probability_level']}_{criterion['mode']}"

            col_name = col_name.replace(
                " ", "_"
            )  # Ensure valid SQLite column name
            sql_col_name = f'"{col_name}" REAL'
            if sql_col_name not in columns:
                columns.append(sql_col_name)

        # SQL to create the table
        rlc_stat_sql = f"""
        CREATE TABLE IF NOT EXISTS stat_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            {", ".join(columns)}
        );
        """
        utils.custom_execute(cursor, rlc_stat_sql)

        # Determine how many potential seeds there may be
        # Maximum of min_seeds and the larges probability level in the acceptance criteria
        max_probability_level = max(
            criterion.get("probability_level")
            for criterion in config.get("analysis_criteria")
        )
        num_seeds = max(min_seeds, int(1 / (1 - max_probability_level) + 1))
        logger.info(
            f"Number of seeds to be generated based on input and requested probability levels: {num_seeds}"
        )

        # Cycle through each case and add seeds equal to the configuration parameter min_seeds
        for case in cases.values():
            # Insert the case list into the database
            seed_list = generate_unique_integers(
                config.get("seed_random_generator"),
                case["hs"],
                case["period"],
                case["wave_dir"],
                num_seeds,
            )

            insert_sql = """
            INSERT INTO stat_results (hs, period, wave_dir, no_seeds, status)
            VALUES (?, ?, ?, ?, ?);
            """
            utils.custom_execute(
                cursor,
                insert_sql,
                (case["hs"], case["period"], case["wave_dir"], min_seeds, "-"),
            )

        #############################
        # Setup 'seed_results' table
        #############################
        # Create the database for full results
        logger.info("Setting up 'seed_results' table in 'rcl_results.db' ...")
        columns = [
            "hs REAL",
            "period REAL",
            "wave_dir REAL",
            "status TEXT",
            "seed_number INTEGER",
            "seed_value INTEGER",
        ]

        # Generate dynamic columns from acceptance criteria
        for criterion in config.get("analysis_criteria", []):
            # Build the column name based on the criterion
            # Omit orcaflex_object_argument if it is not provided
            if criterion.get("orcaflex_object_argument") is None:
                col_name = f"{criterion['orcaflex_object_name']}_{criterion['orcaflex_object_parameter']}_{criterion['mode']}"
            else:
                # Include orcaflex_object_argument in the column name
                col_name = f"{criterion['orcaflex_object_name']}_{criterion['orcaflex_object_parameter']}_{criterion['orcaflex_object_argument']}_{criterion['mode']}"

            col_name = col_name.replace(
                " ", "_"
            )  # Ensure valid SQLite column name
            col_name = f'"{col_name}" REAL'
            if col_name not in columns:
                columns.append(col_name)

        # SQL to create the table
        rlc_stat_sql = f"""
        CREATE TABLE IF NOT EXISTS seed_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            {", ".join(columns)}
        );
        """
        utils.custom_execute(cursor, rlc_stat_sql)

        # Determine how many potential seeds there may be
        # Maximum of min_seeds and the larges probability level in the acceptance criteria
        max_probability_level = max(
            criterion.get("probability_level")
            for criterion in config.get("analysis_criteria")
        )
        num_seeds = max(min_seeds, int(1 / (1 - max_probability_level) + 1))
        logger.info(
            f"Number of seeds to be generated based on input and requested probability levels: {num_seeds}"
        )

        # Cycle through each case and add seeds equal to the configuration parameter min_seeds
        for case in cases.values():
            # Insert the case list into the database
            seed_list = generate_unique_integers(
                config.get("seed_random_generator"),
                case["hs"],
                case["period"],
                case["wave_dir"],
                num_seeds,
            )

            for i, seed_number in enumerate(range(num_seeds)):
                insert_sql = """
                INSERT INTO seed_results (hs, period, wave_dir, seed_number, seed_value, status)
                VALUES (?, ?, ?, ?, ?, ?);
                """
                utils.custom_execute(
                    cursor,
                    insert_sql,
                    (
                        case["hs"],
                        case["period"],
                        case["wave_dir"],
                        i + 1,
                        seed_list[i],
                        "-",
                    ),
                )

        #############################
        # Setup 'X_results' table
        #############################
        # Create tables for each individual criteria to store statistical results
        logger.info("Setting up 'seed_results' table in 'rcl_results.db' ...")

        for criterion in config.get("analysis_criteria", []):
            if criterion.get("orcaflex_object_argument") is None:
                table_name = f"{criterion['orcaflex_object_name']}_{criterion['orcaflex_object_parameter']}_{criterion['mode']}"
            else:
                # Include orcaflex_object_argument in the column name
                table_name = f"{criterion['orcaflex_object_name']}_{criterion['orcaflex_object_parameter']}_{criterion['orcaflex_object_argument']}_{criterion['mode']}"

            table_name = table_name.replace(
                " ", "_"
            )  # Ensure valid SQLite column name

            # SQL to create the table
            rlc_stat_sql = f"""
            CREATE TABLE IF NOT EXISTS {table_name}_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hs REAL,
                period REAL,
                wave_dir REAL,
                status TEXT,
                no_seeds INTEGER,
                "gumbel_mu" REAL,
                "gumbel_beta" REAL,
                "ks_statistic" REAL,
                "ks_critical_value" REAL,
                "ad_statistic" REAL,
                "ad_critical_value" REAL,
                UNIQUE(hs, period, wave_dir)
            );
            """

            utils.custom_execute(cursor, rlc_stat_sql)

            # Cycle through each case and add seeds equal to the configuration parameter min_seeds
            for case in cases.values():
                # Insert the case list into the database
                seed_list = generate_unique_integers(
                    config.get("seed_random_generator"),
                    case["hs"],
                    case["period"],
                    case["wave_dir"],
                    num_seeds,
                )

                insert_sql = f"""
                INSERT OR IGNORE INTO {table_name}_results (hs, period, wave_dir, no_seeds, status)
                VALUES (?, ?, ?, ?, ?);
                """
                utils.custom_execute(
                    cursor,
                    insert_sql,
                    (
                        case["hs"],
                        case["period"],
                        case["wave_dir"],
                        min_seeds,
                        "-",
                    ),
                )

    # Insert X for cases that will never be run
    # i.e. period is less than DNV-RP-N103 minimum period for hs
    identify_X_cases(config)

    logger.info("'rlc_full_results.db' setup completed.")

    utils.sync_db_to_network()

    return cases
