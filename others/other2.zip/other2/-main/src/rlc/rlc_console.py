import os
import sqlite3

from rich import box
from rich.align import Align
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

import rlc.config as cfg
from rlc import __version__
from rlc.logger_config import log_messages

# Global state to track current display values
current_display_data = {}


# ---------------------------
# Helper for safe layout access
# ---------------------------
def _child(layout: Layout, name: str):
    """Return the child Layout with a given name, or None if missing."""
    for c in layout.children:
        if c.name == name:
            return c
    return None


# ---------------------------
# Helper to fit log messages
# ---------------------------
def _get_fitting_log_messages(console, max_lines=4):
    """Get the most recent log messages that fit within max_lines, accounting for wrapping."""
    panel_width = console.width - 4  # Account for panel borders and padding
    messages_to_show = []
    total_lines = 0

    for msg in reversed(list(log_messages)):
        msg_length = len(msg)
        lines_needed = (
            msg_length + panel_width - 1
        ) // panel_width  # Ceiling division

        if total_lines + lines_needed <= max_lines:
            messages_to_show.insert(
                0, msg
            )  # Insert at beginning to maintain order
            total_lines += lines_needed
        else:
            break

    return messages_to_show


# ---------------------------
# Setup console
# ---------------------------
def setup_console(data, config, logger):
    """
    Set up the Rich Console for manual updates.
    Returns console, hs_values, period_values, layout, main_table, legend_table, live.
    """
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT hs FROM case_results")
        hs_values = [row[0] for row in cursor.fetchall()]
        hs_values.sort()

        cursor.execute("SELECT DISTINCT period FROM case_results")
        period_values = [row[0] for row in cursor.fetchall()]
        period_values.sort()

        for i, hs in enumerate(hs_values):
            for j, period in enumerate(period_values):
                data[(i + 1, j + 1)] = "-"

        for i, hs in enumerate(hs_values):
            for j, period in enumerate(period_values):
                cursor.execute(
                    """
                    SELECT EXISTS(
                        SELECT 1 FROM case_results
                        WHERE hs = ? AND period = ? AND status = 'X'
                    )
                    """,
                    (hs, period),
                )
                exists = cursor.fetchone()[0]
                if exists:
                    data[(i + 1, j + 1)] = "X"

    console = Console(record=True)
    main_table = None
    legend_table = None
    layout = create_table(
        data, hs_values, period_values, console, main_table, legend_table
    )
    live = Live(
        layout, console=console, refresh_per_second=0.25, transient=True
    )
    live.start()

    return (
        console,
        hs_values,
        period_values,
        layout,
        main_table,
        legend_table,
        live,
    )


# ---------------------------
# Create table layout
# ---------------------------
def create_table(
    data, hs_values, period_values, console, main_table=None, legend_table=None
):
    legend_mapping = {
        "X": "Period is below the min per DNV-RP-N103",
        "-": "To be assessed",
        "N": "Analysis needed, next up",
        "Y": "Creating YML Files",
        "Q": "Queued for analysis",
        "R": "Running using min_seeds",
        "A": "Assessing min seeds results",
        "N+": "More seeds needed, next up",
        "Y+": "Creating More YML Files",
        "Q+": "Queued for more seeds analysis",
        "R+": "Running using extra seeds",
        "A+": "Assessing extra seeds results",
        "OK": "All criteria passed!",
        "NG": "Criteria failed",
        "Fi": "File(s) failed, 'i' bisections performed",
    }

    # Main table
    if main_table is None:
        main_table = Table(
            show_header=True,
            header_style="bold magenta",
            box=box.SIMPLE,
            padding=(0, 1),
        )
        main_table.add_column("Hs (m)", style="cyan", width=6)
        for j in range(1, len(period_values) + 1):
            main_table.add_column(
                f"T={period_values[j - 1]}s", justify="right", style="green"
            )
    else:
        main_table.rows.clear()

    for i in range(1, len(hs_values) + 1):
        row = [f"{hs_values[i - 1]}"]
        row.extend(
            [
                str(data.get((i, j), "-"))
                for j in range(1, len(period_values) + 1)
            ]
        )
        main_table.add_row(*row)

    # Legend table
    if legend_table is None:
        legend_table = Table(
            show_header=True,
            header_style="bold yellow",
            box=box.MINIMAL,
            padding=(0, 1),
            show_lines=False,
            show_edge=True,
        )
        console_width = console.width
        total_column_width = console_width - 4
        value_width = 8
        description_width = max(
            20, (total_column_width // 2) - value_width - 2
        )
        legend_table.add_column(
            "Value", style="cyan", width=value_width, justify="center"
        )
        legend_table.add_column(
            "Description", style="white", width=description_width
        )
        legend_table.add_column(
            "Value", style="cyan", width=value_width, justify="center"
        )
        legend_table.add_column(
            "Description", style="white", width=description_width
        )

        legend_items = list(legend_mapping.items())
        mid_point = (len(legend_items) + 1) // 2
        left_items = legend_items[:mid_point]
        right_items = legend_items[mid_point:]
        right_items.extend([("", "")] * (len(left_items) - len(right_items)))

        for (left_val, left_desc), (right_val, right_desc) in zip(
            left_items, right_items
        ):
            legend_table.add_row(left_val, left_desc, right_val, right_desc)

    # Logs panel
    log_text = Text()
    fitting_messages = _get_fitting_log_messages(console, max_lines=4)
    for msg in fitting_messages:
        if "DEBUG" in msg:
            log_text.append(f"{msg}\n", style="dim")
        elif "INFO" in msg:
            log_text.append(f"{msg}\n", style="white")
        elif "WARNING" in msg:
            log_text.append(f"{msg}\n", style="yellow")
        elif "ERROR" in msg:
            log_text.append(f"{msg}\n", style="bold red")
        elif "CRITICAL" in msg:
            log_text.append(f"{msg}\n", style="bold white on red")
        else:
            log_text.append(f"{msg}\n", style="white")

    layout = Layout()
    layout.split_column(
        Layout(name="main", ratio=1),
        Layout(name="legend", size=13),
        Layout(name="logs", size=6),
    )

    _child(layout, "main").update(
        Panel(
            main_table,
            title=f"Analysis Results - {os.getcwd()}",
            border_style="blue",
        )
    )
    _child(layout, "legend").update(
        Panel(legend_table, title="Legend", border_style="yellow")
    )
    _child(layout, "logs").update(
        Panel(
            Align(log_text, vertical="bottom"),
            title="Logs",
            border_style="red",
            subtitle=f"v{__version__}",
            subtitle_align="right",
        )
    )

    return layout


# ---------------------------
# Update table
# ---------------------------
def update_table(
    console,
    data,
    hs_values,
    period_values,
    new_log_message=None,
    layout=None,
    main_table=None,
    legend_table=None,
    live=None,
):
    if new_log_message:
        log_messages.append(new_log_message)

    if layout is None or not isinstance(layout, Layout):
        layout = Layout()
        layout.split_column(
            Layout(name="main", ratio=1),
            Layout(name="legend", size=13),
            Layout(name="logs", size=8),
        )

    if main_table is None:
        main_table = Table(
            show_header=True,
            header_style="bold magenta",
            box=box.SIMPLE,
            padding=(0, 1),
        )
        main_table.add_column("Hs (m)", style="cyan", width=6)
        for j in range(1, len(period_values) + 1):
            main_table.add_column(
                f"T={period_values[j - 1]}s", justify="right", style="green"
            )

    main_table.rows.clear()
    for i in range(1, len(hs_values) + 1):
        row = [f"{hs_values[i - 1]}"]
        row.extend(
            [
                str(data.get((i, j), "-"))
                for j in range(1, len(period_values) + 1)
            ]
        )
        main_table.add_row(*row)

    log_text = Text()
    fitting_messages = _get_fitting_log_messages(console, max_lines=4)
    for msg in fitting_messages:
        if "DEBUG" in msg:
            log_text.append(f"{msg}\n", style="dim")
        elif "INFO" in msg:
            log_text.append(f"{msg}\n", style="white")
        elif "WARNING" in msg:
            log_text.append(f"{msg}\n", style="yellow")
        elif "ERROR" in msg:
            log_text.append(f"{msg}\n", style="bold red")
        elif "CRITICAL" in msg:
            log_text.append(f"{msg}\n", style="bold white on red")
        else:
            log_text.append(f"{msg}\n", style="white")

    main_layout = _child(layout, "main")
    if main_layout:
        main_layout.update(
            Panel(
                main_table,
                title=f"Analysis Results - {os.getcwd()}",
                border_style="blue",
            )
        )

    logs_layout = _child(layout, "logs")
    if logs_layout:
        logs_layout.update(
            Panel(
                Align(log_text, vertical="bottom"),
                title="Logs",
                border_style="red",
                subtitle=f"v{__version__}",
                subtitle_align="right",
            )
        )

    if legend_table is not None:
        legend_layout = _child(layout, "legend")
        if legend_layout:
            legend_layout.update(
                Panel(legend_table, title="Legend", border_style="yellow")
            )

    if live and isinstance(live, Live):
        live.update(layout)
    else:
        console.clear()
        console.print(layout)
        console.file.flush()

    return layout, main_table


# ---------------------------
# Update a single cell
# ---------------------------
def update_console_table(
    hs,
    period,
    status,
    data,
    hs_values,
    period_values,
    console,
    layout,
    main_table,
    legend_table,
    live,
):
    try:
        i = hs_values.index(hs) + 1
        j = period_values.index(period) + 1
        data[(i, j)] = status
        update_table(
            console,
            data,
            hs_values,
            period_values,
            new_log_message=None,
            layout=layout,
            main_table=main_table,
            legend_table=legend_table,
            live=live,
        )
    except ValueError as e:
        console.log(
            f"[red]Error:[/red] {e} — Hs or Period not found in table."
        )


# ---------------------------
# Finalize console
# ---------------------------
def finalize_console(
    console,
    data,
    hs_values,
    period_values,
    layout,
    main_table,
    legend_table,
    live=None,
):
    if live:
        live.stop()
    console.clear()
    console.print(
        create_table(
            data, hs_values, period_values, console, main_table, legend_table
        )
    )
