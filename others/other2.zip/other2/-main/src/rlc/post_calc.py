import importlib.resources as pkg_resources
import json
import logging
import os
import shutil
import time

from rlc import data  # assuming 'data' is a subpackage with __init__.py

logger = logging.getLogger("RLC")


def copy_post_calc_action(config):
    """
    If automatic_post_calc is True in the input then create the post calc action file
    The copy the post calc action file (either automatic or manual) to the folder

    Args:
        config (dict): Configuration dictionary containing the input file path and other settings.
    """
    auto_post_calc = config.get("automatic_post_calc")

    # Load Orcaflex API
    try:
        from OrcFxAPI import DLLError as ofDLLError
        from OrcFxAPI import Model as ofModel
        from OrcFxAPI import stLicensingError as ofstLicensingError

        logger.info("OrcaFlex API (OrcFxAPI) loaded")
    except ImportError:
        logger.error("Not able to load OrcFxAPI.")
        return False

    # Load the OF model
    logger.info("Reading name of post calculation actions scripts from model.")
    while True:
        try:
            m = ofModel(config.get("base_file"))
            break
        except ofDLLError as err:
            if not err.status == ofstLicensingError:
                raise
            else:
                logger.info("Trying to get an OrcaFlex license...")
                time.sleep(3)

    number_post_calc_actions = m.general.GetData(
        "NumberOfPostCalculationActions", 0
    )

    # Create auto_post_calc_action.py file if needed
    if auto_post_calc:
        logger.info("Creating auto_post_calc_action.py file ...")
        create_auto_post_calc_action(config)
        logger.info("auto_post_calc_action.py file created.")

    else:
        # Check if post calc action name file name is included in the post calc actions.
        for i in range(number_post_calc_actions):  # type: ignore
            m.general.SelectedPostCalculationAction = m.general.GetData(
                "PostCalculationActionName", i
            )
            post_calc_script_name = m.general.GetData(
                "PostCalculationActionScriptFileName", 0
            )

            # Copy the post calc action file to the runs folder
            post_calc_action_file = os.path.join(
                os.getcwd(), post_calc_script_name
            )  # type: ignore
            logger.debug(
                f"Post calc action file in OrcaFlex Model: {post_calc_action_file}"
            )
            shutil.copy2(post_calc_script_name, "runs")  # type: ignore
            logger.info(
                f"Post calc action file copied to: {post_calc_action_file}"
            )


def create_auto_post_calc_action(config):
    try:
        with pkg_resources.path(
            data, "auto_post_calc_action_tmp.py"
        ) as template_path:
            with open(template_path, "r") as file:
                template = file.read()
    except FileNotFoundError:
        logger.error("Template file not found.")
        return False

    # Format the analysis_criteria with proper indentation
    data_str = json.dumps(config.get("analysis_criteria", []), indent=4)

    # Substitute the placeholder
    filled_template = template.replace('"__DATA_PLACEHOLDER__"', data_str)

    # Ensure the 'runs' directory exists
    os.makedirs("runs", exist_ok=True)

    with open("runs/auto_post_calc_action.py", "w") as f:
        f.write(filled_template)
