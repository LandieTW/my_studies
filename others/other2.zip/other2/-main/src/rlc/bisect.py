import logging
import yaml
import rlc.utils_core as utils_core
import rlc.utils as utils


logger = logging.getLogger("RLC")


def update_yaml_time_step(file_path, new_time_step, variable=False):
    try:
        # Read the existing YAML file
        with open(file_path, "r") as file:
            data = yaml.safe_load(file) or {}

        # Ensure General section exists
        if "General" not in data:
            data["General"] = {}

        # Update or add ImplicitConstantTimeStep in the General section
        if variable:
            data["General"]["ImplicitVariableMaxTimeStep"] = new_time_step
        else:
            data["General"]["ImplicitConstantTimeStep"] = new_time_step
        # Write back to the YAML file
        with open(file_path, "w") as file:
            yaml.safe_dump(data, file, default_flow_style=False)

    except FileNotFoundError:
        logger.error(f"Error: File {file_path} not found")
    except yaml.YAMLError as e:
        logger.error(f"Error processing YAML file: {e}")
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")


def bisect_time_step(file_name, num_bisections, config):
    """
    Bisects the time step in the given file.

    Args:
        file_name (str): The name of the file to bisect.
        num_bisections (int): Current number of bisections that have already been done
        config (dict): Dictionary of configuration

    Returns:
        None
    """
    # logger.info(f"Bisecting time step in {file_name}...")

    new_time_step = config.get("base_time_step") / (2 ** (num_bisections + 1))

    # Open YAML File and append the new time step at the end.
    update_yaml_time_step(file_name, new_time_step)


def main(failed_files, config, num_bisections, console_manager):
    """
    Bisects the time step in the given list of YAML files.  Submit to DOF
    or HPC-Flex

    Args:
        yml_files (list): A list of YAML file names.

    Returns:
        None
    """

    progress_previous = 0
    logger.info(f"Cases unstable, executing bisection #{num_bisections + 1}")
    logger.info(f"Bisecting {len(failed_files)} YML files")
    for i, failed_yml in enumerate(failed_files):
        bisect_time_step(failed_yml, num_bisections, config)
        parameters = utils.extract_values_from_filename(failed_yml, logger)
        hs = parameters["hs"]
        t = parameters["t"]
        wave_dir = parameters["wave_dir"]
        seed = parameters["seed"]

        # Rewrite _failed.json marker with retry_bisection to signal that
        # the YAML has been prepared with a halved timestep.  On restart,
        # create_txt_package() will see retry_bisection, delete the marker,
        # and allow the file to be re-run.
        base_name = utils_core.file_name_gen(hs, t, wave_dir, seed)
        utils.write_failed_json(
            base_name,
            bisection=num_bisections,
            reason="Simulation unstable",
            retry_bisection=num_bisections + 1,
        )

        utils.seed_results_update(hs, t, wave_dir, seed, f"F{num_bisections}")
        utils.stat_results_update(hs, t, wave_dir, f"F{num_bisections}")
        utils.case_results_update(hs, t, f"F{num_bisections}")
        # console_manager.update_from_database()

        # Update Progress in Logging Messages
        progress_fraction = (i + 1) / len(failed_files)
        progress_current = int(progress_fraction * 100)
        if progress_current > progress_previous:
            logger.info(
                f"Bisecting YMLs ({i}/{len(failed_files)}): {utils_core.progress_bar(progress_fraction)}"
            )
            progress_previous = progress_current
