import logging
import sqlite3 as sqlite3

import rlc.config as cfg
import rlc.utils as utils

logger = logging.getLogger("RLC")


def get_criteria_value(data, name, parameter, argument=None):
    for item in data["analysis_criteria"]:
        if (
            item["orcaflex_object_name"] == name
            and item["orcaflex_object_parameter"] == parameter
            and (
                argument is None
                or item.get("orcaflex_object_argument") == argument
            )
        ):
            return item["value"]
    return None


def update_case_results_status(cursor):
    # Get all unique (hs, period) combinations from stat_results
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        utils.custom_execute(
            cursor, "SELECT DISTINCT hs, period FROM stat_results"
        )
        hs_period_combinations = cursor.fetchall()

        for hs, period in hs_period_combinations:
            # Get all statuses for this hs/period
            utils.custom_execute(
                cursor,
                """
                SELECT status FROM stat_results
                WHERE hs = ? AND period = ?
            """,
                (hs, period),
            )
            statuses = [row[0] for row in cursor.fetchall()]

            # Determine new status for case_results
            if "F" in statuses:
                new_status = "F"
            elif "NG" in statuses:
                new_status = "NG"
            elif all(status == "OK" for status in statuses):
                new_status = "OK"
            else:
                continue  # Do not update if none of the above conditions are met

            # Update case_results
            utils.custom_execute(
                cursor,
                """
                UPDATE case_results
                SET status = ?
                WHERE hs = ? AND period = ?
            """,
                (new_status, hs, period),
            )
    utils.sync_db_to_network()


def lower_ok():
    """
    Opens the rlc_results.db file, finds hs/period combinations in case_results where the status is OK.
    Sets the status for all hs values lower than that hs for that period to OK as well.

    Args:
        None

    Return:
        None
    """

    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Step 1: Get all hs/period combinations where status is 'OK'
        utils.custom_execute(
            cursor,
            """
            SELECT hs, period
            FROM case_results
            WHERE status = 'OK'
            """,
        )
        ok_rows = cursor.fetchall()

        # Step 2: For each OK row, update all lower hs values for the same period
        for hs, period in ok_rows:
            utils.custom_execute(
                cursor,
                """
                UPDATE case_results
                SET status = 'OK'
                WHERE period = ? AND hs < ? AND status != 'X'
                """,
                (period, hs),
            )

        # Step 3: Update the stat_results table where the hs and period also match
        for hs, period in ok_rows:
            utils.custom_execute(
                cursor,
                """
                UPDATE stat_results
                SET status = 'OK'
                WHERE period = ? AND hs < ? AND status != 'X'
                """,
                (period, hs),
            )
    utils.sync_db_to_network()


def higher_ng(config):
    """
    Opens the rlc_results.db file, finds hs/period combinations in case_results where the status is NG.
    Sets the status for all hs values for that period to also NG

    Args:
        config (dict): The configuration dictionary

    Return:
        None
    """
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Step 1: Get all hs/period combinations where status is 'NG'
        utils.custom_execute(
            cursor,
            """
            SELECT hs, period
            FROM case_results
            WHERE status = 'NG'
            """,
        )
        ng_rows = cursor.fetchall()

        # Step 2: For each NG row, update all higher hs values for the same period
        for hs, period in ng_rows:
            utils.custom_execute(
                cursor,
                """
                UPDATE case_results
                SET status = 'NG'
                WHERE period = ? AND hs > ? AND status = '-'
                """,
                (period, hs),
            )

        # Step 3: Update the stat_results table where the hs and period also match
        for hs, period in ng_rows:
            utils.custom_execute(
                cursor,
                """
                UPDATE stat_results
                SET status = 'NG'
                WHERE period = ? AND hs > ? AND status = '-'
                """,
                (period, hs),
            )
    utils.sync_db_to_network()


def check_criteria(config, hs, period, wave_dir, criteria):
    """_summary_

    Args:
        config (_type_): _description_
        hs (_type_): _description_
        period (_type_): _description_
        wave_dir (_type_): _description_
        criteria (_type_): _description_
    """

    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        utils.custom_execute(
            cursor,
            f"""
                SELECT rowid, hs, period, wave_dir, no_seeds, status, "{criteria}"
                FROM stat_results
                WHERE hs = ? AND period = ? AND wave_dir = ?
                """,
            (hs, period, wave_dir),
        )

        row = cursor.fetchone()

    rowid, hs, period, wave_dir, no_seeds, status, result_value = row

    # Determine the criteria to pass
    # Cycle through each result criteria
    criteria_passed = True
    analysis_criteria = config.get("analysis_criteria")

    # Loop through analysis criteria
    for crit in analysis_criteria:
        # Check to see if this criteria matches the
        crit_name = utils.criteria_to_column_name(crit)
        if crit_name == criteria:
            # Check to see if the criteria is acceptable
            if crit["mode"] == "max":
                if result_value > crit["value"]:
                    criteria_passed = False
            elif crit["mode"] == "min":
                if result_value < crit["value"]:
                    criteria_passed = False

    # Store status in database:
    # Get current status value, don't write OK if value is currently NG
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        if status != "NG":
            if criteria_passed:
                """
                'K' is a temporary status to indicate that the criteria is being checked
                and that it hasn't hit a NG yet in the checking loop.  As the checking loops,
                cases that are no good triggers a change in this to 'NG'.  If after all
                of the loops the case is still 'K' (i.e. no criteria failed) the status is
                changed to 'OK'.
                """
                utils.custom_execute(
                    cursor,
                    f"""
                    UPDATE stat_results
                    SET status = 'K'
                    WHERE hs = {hs} AND period = {period} AND wave_dir = {wave_dir}
                    """,
                )
            else:
                utils.custom_execute(
                    cursor,
                    f"""
                    UPDATE stat_results
                    SET status = 'NG'
                    WHERE hs = {hs} AND period = {period} AND wave_dir = {wave_dir}
                    """,
                )
                utils.custom_execute(
                    cursor,
                    f"""
                    UPDATE case_results
                    SET status = 'NG'
                    WHERE hs = {hs} AND period = {period}
                    """,
                )
    utils.sync_db_to_network()

    return


def main(config):
    # Open results database and go through each criterion in each stat_results row to see if that criteria is acceptable.
    # If all criteria are acceptable, change the status to OK
    # If at least one criteria is not acceptable, change status to NG

    # Get list of criteria in input:
    criteria_names = utils.get_list_criteria_names(config)

    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        for criteria in criteria_names:
            utils.custom_execute(
                cursor,
                f"""
                SELECT s.rowid, s.hs, s.period, s.wave_dir, s.no_seeds, s.status, s."{criteria}"
                FROM stat_results s
                JOIN case_results c ON s.hs = c.hs AND s.period = c.period
                WHERE c.status != 'NG'
                """,
            )

            rows = cursor.fetchall()

            for row in rows:
                rowid, hs, period, wave_dir, no_seeds, status, result_value = (
                    row
                )
                if status == "A" or status == "A+" or status == "K":
                    # Only check criteria after it has just finished analysis
                    check_criteria(config, hs, period, wave_dir, criteria)

        # Update case_results table based on values in stat_result tables.
        # Cycle through each row in case_results then filter the stat_results table
        # for each case to get the status of each criteria.
        # If all criteria for all wave_dir are OK, then set the status to OK
        # If at least one criteria is NG, then set the status to NG

        # First change any stat_results that have a 'K' to an 'OK'
        utils.db_status_update(
            old_status="K",
            new_status="OK",
            case_results=False,
            seed_results=False,
        )

        update_case_results_status(cursor)  # type: ignore

        # Set status of lower hs to Ok if any cases are OK
        lower_ok()  # type: ignore

        # Set status of higher hs to NG if a lower hs which is a multiple of hs_fine_step has a status of NG
        higher_ng(config)
