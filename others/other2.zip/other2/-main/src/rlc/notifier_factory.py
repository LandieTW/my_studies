# rlc/notifier_factory.py
import logging

logger = logging.getLogger("RLC")


class NullNotifier:
    """Fallback notifier when Outlook is unavailable."""

    def send(self, *args, **kwargs):
        subject = kwargs.get("subject") or (args[0] if args else "")
        logger.info(
            "Notifications disabled; skipped email. Subject: %s", subject
        )

    def error(self, msg):
        logger.error("Notifications disabled; error message: %s", msg)

    def info(self, msg):
        logger.info("Notifications disabled; info message: %s", msg)


def get_notifier():
    try:
        from rlc.send_email import EmailNotifier

        return EmailNotifier()
    except Exception as e:
        logger.warning(
            "Email notifier unavailable (%s). Using NullNotifier.", e
        )
        return NullNotifier()
