import logging

import rlc.bisect as bisect
import rlc.dof_interface as dof_interface
import rlc.hpcflex_interface as hpcflex_interface
import rlc.local_interface as local_interface
import rlc.utils as utils
import rlc.utils_core as utils_core
from rlc.notifier_factory import get_notifier

logger = logging.getLogger("RLC")
notifier = get_notifier()


def running_to_assessing():
    """
    Sets the status of all jobs that are currently marked R to A
    """
    # Set status of remaining files
    utils.db_status_update(
        old_status="R",
        new_status="C",
        case_results=False,
        stat_results=False,
    )  # type: ignore
    utils.db_status_update(
        old_status="R+",
        new_status="C",
        case_results=False,
        stat_results=False,
    )  # type: ignore
    utils.db_status_update(old_status="R", new_status="A", seed_results=False)  # type: ignore
    utils.db_status_update(
        old_status="R+", new_status="A+", seed_results=False
    )  # type: ignore


def main(config, console_manager):
    """
    Controls the submission of files to local, dof or HPC-Flex.
    Args:
        config (dict): Configuration dictionary containing run method and other parameters

    """
    run_method = config.get("run_method")
    num_bisections = 0
    max_bisections = config.get("max_bisections")
    email_on_failure = config.get("email_on_failure")
    yml_files: list = []
    failed: list = []
    while num_bisections <= max_bisections:
        if run_method == "dof":
            yml_files, failed = dof_interface.main(config, console_manager)
        elif run_method == "local":
            yml_files, failed = local_interface.main(config, console_manager)
        else:
            yml_files, failed = hpcflex_interface.main(config, console_manager)
        # Update status in database
        # seed_results
        # - Failed Jobs will be marked as FX where X is bisection number
        # - Completed Jobs will be marked as C
        # stat_results
        # - If at least one yml file failed row will be marked as FX
        # - If all yml files completed for wave_dir row will be marked as C
        # case_results
        # - If at least one yml file failed row will be marked as FX
        # - If all yml files completed for wave_dir row will be marked as C

        if failed != [] and email_on_failure:
            """
            Sends an email if the email flag has been set to True
            """
            logger.info("Sending failure email")
            num_failed = len(failed)
            notifier_text = (
                f"<p>{num_failed} files have failed in the latest analysis loop. "
                f"{num_bisections} of a maximum of {max_bisections} bisections "
                f"have been performed.</p>"
                f"<p>Failed files:</p>"
            )

            for failed_yml in failed:
                notifier_text += f"<p>{failed_yml}</p>"

            notifier.info(notifier_text)

        if failed == []:
            """
            This covers the case where there were no failed cases.
            """
            if num_bisections != 0 and len(yml_files) > 0:
                """
                This covers when there was at least one bisection due to failed cases
                but now all cases have passed.  Change the failed cases to 'C'.
                """
                for yml_file in yml_files:
                    parameters = utils.extract_values_from_filename(
                        yml_file, logger
                    )
                    hs = parameters["hs"]
                    t = parameters["t"]
                    wave_dir = parameters["wave_dir"]
                    seed = parameters["seed"]
                    utils.seed_results_update(hs, t, wave_dir, seed, "C")
                    utils.stat_results_update(hs, t, wave_dir, "A")
                    utils.case_results_update(hs, t, "A")
                    # Delete _failed.json marker since the run recovered
                    base_name = utils_core.file_name_gen(hs, t, wave_dir, seed)
                    utils.delete_failed_json(base_name)
            else:
                """
                This covers the case when all files ran successfully the first
                time through.
                """
                logger.info("All files completed successfully")
                running_to_assessing()
                console_manager.update_from_database()
                break

        if failed != [] and num_bisections == max_bisections:
            """
            This covers the case where there are still failed cases but we've
            reached the bisection limit.  These cases are there considered NG.
            """
            logger.info(
                "Bisection limit reached, cases that still have failures are NG"
            )
            for failed_yml in failed:
                parameters = utils.extract_values_from_filename(
                    failed_yml, logger
                )
                hs = parameters["hs"]
                t = parameters["t"]
                wave_dir = parameters["wave_dir"]
                seed = parameters["seed"]
                utils.seed_results_update(hs, t, wave_dir, seed, "F")
                utils.stat_results_update(hs, t, wave_dir, "NG")
                utils.case_results_update(hs, t, "NG")
                # Write permanent _failed.json marker (bisection limit reached)
                base_name = utils_core.file_name_gen(hs, t, wave_dir, seed)
                utils.write_failed_json(
                    base_name,
                    num_bisections,
                    reason="Bisection limit reached",
                )

            running_to_assessing()
            # Update Console
            console_manager.update_from_database()
            # Exit the loop as bisection limit has reached
            break

        if failed != [] and num_bisections < max_bisections:
            """
            This covers the case where there are failed cases and we've haven't
            reached the bisection limit.  Need to bisect.
            """
            # Write _failed.json markers before bisecting.
            # bisect.main() will delete them after modifying the YAML timestep.
            for failed_yml in failed:
                parameters = utils.extract_values_from_filename(
                    failed_yml, logger
                )
                base_name = utils_core.file_name_gen(
                    parameters["hs"],
                    parameters["t"],
                    parameters["wave_dir"],
                    parameters["seed"],
                )
                utils.write_failed_json(
                    base_name,
                    num_bisections,
                    reason="Simulation unstable",
                )
            # Bisect YAML Files
            bisect.main(failed, config, num_bisections, console_manager)
            num_bisections += 1

    return
