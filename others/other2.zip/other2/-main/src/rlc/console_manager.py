# rlc/console_manager.py

import sqlite3

import rlc.config as cfg
from rlc import rlc_console


class ConsoleManager:
    def __init__(self):
        self.data = {}
        self.hs_values = []
        self.period_values = []
        self.console = None
        self.layout = None
        self.main_table = None
        self.legend_table = None
        self.live = None

    def initialize(self, config, logger):
        (
            self.console,
            self.hs_values,
            self.period_values,
            self.layout,
            self.main_table,
            self.legend_table,
            self.live,
        ) = rlc_console.setup_console(self.data, config, logger)

    def update_from_database(self):
        with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
            cursor = conn.cursor()

            for hs in self.hs_values:
                for period in self.period_values:
                    cursor.execute(
                        "SELECT status FROM case_results WHERE hs = ? AND period = ?",
                        (hs, period),
                    )
                    result = cursor.fetchone()
                    if result:
                        status = result[0]
                        rlc_console.update_console_table(
                            hs=hs,
                            period=period,
                            status=status,
                            data=self.data,
                            hs_values=self.hs_values,
                            period_values=self.period_values,
                            console=self.console,
                            layout=self.layout,
                            main_table=self.main_table,
                            legend_table=self.legend_table,
                            live=self.live,
                        )

    def finalize(self):
        rlc_console.finalize_console(
            console=self.console,
            data=self.data,
            hs_values=self.hs_values,
            period_values=self.period_values,
            layout=self.layout,
            main_table=self.main_table,
            legend_table=self.legend_table,
            live=self.live,
        )
