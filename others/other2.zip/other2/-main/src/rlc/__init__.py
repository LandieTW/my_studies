"""repeated-lowering-control"""

__version__ = "5.1.0"
__date__ = "2026-05-27"
__title__ = "rlc"
__author__ = "Andrew Blundon"
__email__ = "andrew.blundon@technipfmc.com"
__url__ = "https://github.com/tfmc-rgic/rlc"
__docs__ = "https://azsane02userlc.z13.web.core.windows.net/"
