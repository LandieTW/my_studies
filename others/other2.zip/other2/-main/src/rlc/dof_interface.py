import logging
import os
import random
import subprocess
import time
from typing import Any, Dict, Optional, Tuple

import yaml

import rlc.utils as utils

logger = logging.getLogger("RLC")


DOFCMD = r"C:\Program Files (x86)\Orcina\Distributed OrcaFlex\dofcmd.exe"
BASE_CMD = f'"{DOFCMD}" -list -yaml'


def _run_once(
    timeout_sec: float = 10.0,
) -> Tuple[Optional[Dict[str, Any]], str, int]:
    """
    Runs dofcmd one time and tries to parse YAML.
    Returns: (parsed_yaml_or_none, stderr_text, return_code)
    """
    try:
        result = subprocess.run(
            BASE_CMD,
            shell=True,  # using quotes around path already
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
    except subprocess.TimeoutExpired:
        # Treat timeout as a retryable condition
        return None, f"Timeout after {timeout_sec}s", 124

    stdout = result.stdout or ""
    stderr = result.stderr or ""
    rc = result.returncode

    # Quick checks before YAML parse
    if rc != 0:
        # Non-zero exit is retryable; return details to caller
        return None, f"ExitCode={rc}; stderr={stderr.strip()}", rc

    if not stdout.strip():
        # Empty output; likely busy or transient
        return None, "Empty stdout", rc

    # Try to parse YAML
    try:
        parsed = yaml.safe_load(stdout)
    except yaml.YAMLError as e:
        return None, f"YAML error: {e}", rc

    # Sometimes safe_load('') returns None; treat as retryable
    if parsed is None:
        return None, "Parsed YAML is None (empty document)", rc

    # If the spec guarantees a dict, validate it:
    if not isinstance(parsed, list):
        return None, f"Unexpected YAML type: {type(parsed).__name__}", rc

    return parsed, "", rc


def get_dof_progress(
    max_attempts: int = 10,
    base_delay: float = 0.5,  # seconds
    max_delay: float = 5.0,  # seconds
    timeout_per_call: float = 10.0,
    total_deadline: Optional[float] = None,  # absolute time.time() deadline
) -> Optional[dict]:
    """
    Keep trying until we get a valid dict from dofcmd, or attempts/deadline exhausted.
    Returns a dict on success, or None on failure.
    """
    last_error = ""

    for attempt in range(1, max_attempts + 1):
        # Respect an overall deadline if provided
        if total_deadline and time.time() >= total_deadline:
            break

        parsed, err, rc = _run_once(timeout_sec=timeout_per_call)
        if parsed is not None:
            return parsed  # success!

        last_error = err

        # Compute next backoff delay with jitter
        delay = min(max_delay, base_delay * (2 ** (attempt - 1)))
        delay *= random.uniform(0.8, 1.2)

        # If we have a total deadline, clamp delay to not exceed it
        if total_deadline:
            remaining = total_deadline - time.time()
            if remaining <= 0:
                break
            delay = min(delay, max(0.0, remaining))

        # Optional: log/debug
        logger.info(
            f"[get_dof_progress] attempt {attempt}/{max_attempts} failed: {err}. Retrying in {delay:.2f}s..."
        )

        time.sleep(delay)

    # Give the caller a chance to see why we failed
    logger.info(
        f"[get_dof_progress] Exhausted retries. Last error: {last_error}"
    )
    return None


def categorize_jobs(job_data, yml_files):
    # Filter only the jobs that match the filenames you're tracking
    tracked_jobs = [
        job for job in job_data if job.get("FileName") in yml_files
    ]

    jobs_running = []
    jobs_completed_successfully = []
    jobs_unstable = []

    for job in tracked_jobs:
        status = job.get("Status")
        progress = job.get("Progress") or ""
        filename = job.get("FileName")

        if status != "Completed":
            jobs_running.append(filename)
        elif progress.startswith("Simulation was unstable"):
            jobs_unstable.append(filename)
        else:
            jobs_completed_successfully.append(filename)

    return jobs_running, jobs_completed_successfully, jobs_unstable


def main(config, console_manager):
    # Create the text file for DOF
    dof_txt_file, yml_files = utils.create_txt_package(config, logger)
    total_files = len(yml_files)

    # Check if there are any files to run
    if total_files == 0 or dof_txt_file is None:
        logger.info("No YML files to run. Skipping DOF submission.")
        # Change Status of files to running
        utils.db_status_update(old_status="Q", new_status="R")
        utils.db_status_update(old_status="Q+", new_status="R+")
        return [], []  # Return empty lists for yml_files and unstable

    # Run using DOF
    # Get the path to the OrcaFlex DLL
    path_orcfx_dll = config.get(
        "path_orcfx_dll",
    )

    """
    Removed this section to clear jobs as this would cause an issue for users
    who run multiple jobs at once.
    
    logger.info(f"Clear completed DOF jobs for user: {getpass.getuser()}")
    # clear list of completed jobs in DOF fir current user

    cmd = (
        rf'"C:\Program Files (x86)\Orcina\Distributed OrcaFlex\dofcmd.exe" '
        f"-clearjobs={getpass.getuser()}"
    )

    subprocess.call(cmd, shell=True)
    """

    # call DOF, removed -wait option
    logger.info(f"Submitting DOF jobs with text file: {dof_txt_file}")
    logger.info(f"Submitting {total_files} *.yml files.")

    cmd = (
        rf'"C:\Program Files (x86)\Orcina\Distributed OrcaFlex\dofcmd.exe" '
        f'-dllname="{path_orcfx_dll}" '
        "-autosave=999 "
        f"-add {dof_txt_file}"
        " >> dof_call_err.txt"
    )

    # Temporarily change directory to 'runs' to run the command
    # This is necessary because the text file is created in the 'runs' directory
    os.chdir("runs")
    logger.info(f"Running command: {cmd}")
    subprocess.call(cmd, shell=True)
    # Change back to the original directory
    os.chdir("..")

    # Change Status of files to running
    utils.db_status_update(old_status="Q", new_status="R")
    utils.db_status_update(old_status="Q+", new_status="R+")

    # Update the console manager
    console_manager.update_from_database()

    # Watch the folder for json result files.  When all json files are created

    check_interval = 10  # 10 seconds
    max_resubmissions = 3
    resubmission_count = 0
    max_zero_running_checks = (
        3  # consecutive checks with 0 running before declaring dropped
    )
    zero_running_count = 0

    while True:
        job_data = get_dof_progress()
        if job_data is None:
            logger.warning(
                "Could not retrieve DOF progress; retrying in %ds...",
                check_interval,
            )
            time.sleep(check_interval)
            continue

        running, completed_ok, unstable = categorize_jobs(job_data, yml_files)
        num_running = len(running)
        num_completed_ok = len(completed_ok)
        num_unstable = len(unstable)

        logger.info(
            f"DOF Progress: Completed: {num_completed_ok}, Running: {num_running}, Unstable: {num_unstable}"
        )

        if num_completed_ok + num_unstable == total_files:
            logger.info("DOF Batch completed")
            logger.info(
                f"Completed Successfully: {num_completed_ok}, Unstable: {num_unstable}"
            )
            break

        # Detect DOF dropping jobs: nothing running but not all results accounted for
        if (
            num_running == 0
            and (num_completed_ok + num_unstable) < total_files
        ):
            zero_running_count += 1
            num_accounted = num_completed_ok + num_unstable
            logger.warning(
                f"No running DOF jobs but only {num_accounted}/{total_files} "
                f"accounted for. Check {zero_running_count}/{max_zero_running_checks}"
            )
            if zero_running_count >= max_zero_running_checks:
                logger.warning(
                    "DOF appears to have dropped jobs. Checking for missing result files..."
                )
                # Find yml files that don't have a result or failed json on disk
                missing = []
                for yml_file in yml_files:
                    base_name = os.path.splitext(os.path.basename(yml_file))[0]
                    json_path = os.path.join(
                        "runs", base_name + "_results.json"
                    )
                    failed_path = os.path.join(
                        "runs", base_name + "_failed.json"
                    )
                    if not os.path.isfile(json_path) and not os.path.isfile(
                        failed_path
                    ):
                        missing.append(yml_file)

                if not missing:
                    logger.info(
                        "All result files found on disk despite DOF dropping jobs."
                    )
                    break

                if resubmission_count >= max_resubmissions:
                    logger.error(
                        f"DOF resubmission limit ({max_resubmissions}) reached. "
                        f"{len(missing)} files still missing results."
                    )
                    break

                # Re-submit only the missing files
                resubmission_count += 1
                logger.info(
                    f"Re-submitting {len(missing)} missing files to DOF "
                    f"(attempt {resubmission_count}/{max_resubmissions})"
                )
                resubmit_txt = "resubmit.txt"
                with open(os.path.join("runs", resubmit_txt), "w") as f:
                    for yml_file in missing:
                        f.write(os.path.basename(yml_file) + "\n")

                resubmit_cmd = (
                    rf'"C:\Program Files (x86)\Orcina\Distributed OrcaFlex\dofcmd.exe" '
                    f'-dllname="{path_orcfx_dll}" '
                    "-autosave=999 "
                    f"-add {resubmit_txt}"
                    " >> dof_call_err.txt"
                )
                os.chdir("runs")
                logger.info(f"Running command: {resubmit_cmd}")
                subprocess.call(resubmit_cmd, shell=True)
                os.chdir("..")

                # Reset the counter so monitoring resumes normally
                zero_running_count = 0
        else:
            zero_running_count = 0

        time.sleep(check_interval)

    return yml_files, unstable
