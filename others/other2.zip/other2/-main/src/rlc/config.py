import hashlib
import os
import tempfile

# Database configuration
DATABASE_DIR = os.path.join(os.getcwd(), "database")
os.makedirs(DATABASE_DIR, exist_ok=True)
DATABASE_PATH = os.path.join(DATABASE_DIR, "rlc_results.db")

# Local (temp) database path — unique per working directory path
_path_hash = hashlib.md5(os.getcwd().encode()).hexdigest()[:8]
LOCAL_DB_PATH = os.path.join(tempfile.gettempdir(), f"rlc_{_path_hash}.db")

# Log configuration
LOG_DIR = os.path.join(os.getcwd(), "logs")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_PATH = os.path.join(LOG_DIR, "rlc.log")
ZERO_WAVE_LOG_PATH = os.path.join(LOG_DIR, "zero_wave.log")

# weather_window.xlsx configuration
RESULTS_DIR = os.path.join(os.getcwd(), "results")
os.makedirs(RESULTS_DIR, exist_ok=True)
WEATHER_WINDOW_PREFIX = "weather_window"
WEATHER_WINDOW_XLSX_PATH = os.path.join(
    RESULTS_DIR, WEATHER_WINDOW_PREFIX + ".xlsx"
)
WEATHER_WINDOW_PDF_PATH = os.path.join(
    RESULTS_DIR, WEATHER_WINDOW_PREFIX + ".pdf"
)

RLC_RESULTS_PATH = os.path.join(RESULTS_DIR, "rlc_results.xlsx")
