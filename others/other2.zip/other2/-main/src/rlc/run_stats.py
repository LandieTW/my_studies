import logging
import sqlite3

import numpy as np
import scipy.stats as stats

import rlc.config as cfg
import rlc.utils as utils
import rlc.utils_core as utils_core

logger = logging.getLogger("RLC")


def gumbel(config, hs, period, wave_dir):
    """
    Perform Gumbel statistical analysis on the given parameters.
    This function connects to the SQLite database, retrieves the necessary data,
    and performs the Gumbel analysis.  It then performs the KS and AD tests on the results.
    Possible outcomes are:
    - Passed all fit tests and criteria - Case is OK
    - Passed all fit tests but failed criteria - Case is NG
    - Failed fit tests - Need to run more seeds (if max seeds not reached)
    - Failed fit tests and max seeds reached - Perform empirical analysis

    Args:
        config (dict): Configuration dictionary containing database file path and other parameters
        hs (float): Significant wave height
        period (float): Wave period
        wave_dir (float): Wave direction

    Returns:
        AnalysisOutcome: Result of the Gumbel analysis
    """
    # Placeholder for Gumbel analysis logic
    # logger.debug(
    #     f"Attempting Gumbel analysis for hs: {hs}, period: {period}, wave_dir: {wave_dir}"
    # )
    # Implement Gumbel analysis here

    # Need to cycle through each result criteria and assess
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        unique_criteria = utils.get_unique_criteria(config)

        for criterion in unique_criteria:
            criteria = utils.construct_criterion_name_no_prob(criterion)
            # criteria = utils.criteria_to_column_name(criterion)
            # Search through the database case_results table for the given hs, period, wave_dir
            # Get the results for the given criterion and add to the list
            logger.info(f"- Criteria: {criteria}")
            result_values = []
            utils.custom_execute(
                cursor,
                f"""
                SELECT "{criteria}"
                FROM seed_results
                WHERE hs = ? AND period = ? AND wave_dir = ? AND STATUS = 'CS'
                """,
                (hs, period, wave_dir),
            )
            rows = cursor.fetchall()
            no_seeds = len(rows)
            for row in rows:
                result_values.append(row[0])

            # If all values in result_values are 0 or essentially zero need to
            # skip the gumbel fitting and indicate a failed fit otherwise the
            # fitting function will fail
            if utils_core.contains_all_zeros(result_values):
                status = "FF"
                gumbel_mu = 1e-6
                gumbel_beta = 0
                ks_critical_value = np.nan
                ks_statistic = np.nan
                ad_critical_value = np.nan
            else:
                # Fit data to the Gumbel distribution
                if criterion["mode"] == "max":
                    # Perform Gumbel fit for max values
                    gumbel_mu, gumbel_beta = stats.gumbel_r.fit(result_values)
                    # logger.debug(
                    #     f"Gumbel fit for {criteria}: beta={gumbel_mu}, gamma={gumbel_beta}"
                    # )

                    # Perform KS test (this one supports args)
                    ks_statistic, ks_p_value = stats.kstest(
                        result_values,
                        "gumbel_r",
                        args=(gumbel_mu, gumbel_beta),
                    )
                    # Standardize the data for AD test
                    standardized_values = (
                        result_values - gumbel_mu
                    ) / gumbel_beta
                    ad_result = stats.anderson(
                        standardized_values, dist="gumbel_r"
                    )

                elif criterion["mode"] == "min":
                    # Perform Gumbel fit for min values
                    gumbel_mu, gumbel_beta = stats.gumbel_l.fit(result_values)
                    # logger.debug(
                    #     f"Gumbel fit for {criteria}: beta={gumbel_mu}, gamma={gumbel_beta}"
                    # )

                    # Perform KS test (this one supports args)
                    ks_statistic, ks_p_value = stats.kstest(
                        result_values,
                        "gumbel_l",
                        args=(gumbel_mu, gumbel_beta),
                    )
                    # Standardize the data for AD test
                    standardized_values = (
                        result_values - gumbel_mu
                    ) / gumbel_beta
                    ad_result = stats.anderson(
                        standardized_values, dist="gumbel_l"
                    )

                # Perform KS Test
                alpha = config.get("ks_test_criteria", 0.05)
                n = len(result_values)  # sample size
                ks_critical_value = stats.kstwobign.ppf(1 - alpha) / np.sqrt(n)

                # Perform AD test on standardized data
                ad_statistic = ad_result.statistic  # type: ignore
                # Map ad_test_criteria to scipy anderson critical_values index
                # scipy returns critical values at [15%, 10%, 5%, 2.5%, 1%]
                _ad_significance_levels = [0.15, 0.10, 0.05, 0.025, 0.01]
                ad_alpha = config.get("ad_test_criteria", 0.05)
                _ad_idx = min(
                    range(len(_ad_significance_levels)),
                    key=lambda i: abs(_ad_significance_levels[i] - ad_alpha),
                )
                ad_critical_value = ad_result.critical_values[_ad_idx]  # type: ignore
                # ad_significance_level = ad_result.significance_level  # type: ignore

                # logger.debug(
                #     f"KS test for {criteria}: statistic={ks_statistic}, critical_value@0.05 ={ks_critical_value}, p-value={ks_p_value}"  # type: ignore
                # )
                # logger.debug(
                #     f"AD test for {criteria}: statistic={ad_statistic}, critical_values ={ad_critical_values}, significance_level={ad_significance_level}"
                # )

                # # Check to see if the case passed the criteria
                pass_fit = True

                if ks_statistic < ks_critical_value:  # type: ignore
                    pass
                    # logger.debug(
                    #     f"Case {hs}, {period}, {wave_dir} passed the KS test for {criteria}"
                    # )
                else:
                    # logger.debug(
                    #     f"Case {hs}, {period}, {wave_dir} failed the KS test for {criteria}"
                    # )
                    pass_fit = False

                if ad_statistic < ad_critical_value:
                    pass
                    # logger.debug(
                    #     f"Case {hs}, {period}, {wave_dir} passed the AD test for {criteria}"
                    # )
                else:
                    # logger.debug(
                    #     f"Case {hs}, {period}, {wave_dir} failed the AD test for {criteria}"
                    # )
                    pass_fit = False

                if pass_fit:
                    status = "PF"
                else:
                    status = "FF"

            # Add these results to the database for each criterion
            utils.custom_execute(
                cursor,
                f"""
                UPDATE "{criteria}_results"
                SET status = ?, no_seeds = ?, gumbel_mu = ?, gumbel_beta = ?, ks_statistic = ?, ks_critical_value = ?, ad_statistic = ?, ad_critical_value = ?
                WHERE hs = ? AND period = ? AND wave_dir = ?
                """,
                (
                    status,
                    no_seeds,
                    gumbel_mu,  # type: ignore
                    gumbel_beta,  # type: ignore
                    ks_statistic,  # type: ignore
                    ks_critical_value,  # Using the 5% significance level
                    ad_statistic,
                    ad_critical_value,  # Using the 5% significance level
                    hs,
                    period,
                    wave_dir,
                ),
            )

        # Update case_results and stat_results with number of seeds that were run.
        # This uses the no_seeds value from the last iteration for the criteria, which would be the
        # same for all criteria.

        # Overall this next command is actually run 3x even though it is only needed once (due to wave_dir).
        # OK for now.
        utils.custom_execute(
            cursor,
            """
            UPDATE case_results
            SET no_seeds = ?
            WHERE hs = ? AND period = ?
            """,
            (no_seeds, hs, period),  # type: ignore
        )

        utils.custom_execute(
            cursor,
            """
            UPDATE stat_results
            SET no_seeds = ?
            WHERE hs = ? AND period = ? AND wave_dir = ?
            """,
            (no_seeds, hs, period, wave_dir),  # type: ignore
        )
    utils.sync_db_to_network()

    return


def main(config):
    """
    Perfoms the statistical anlaysis of the available results.
    Flags each statistical analysis as in the stat_results database table.

    Args:
        config (_type_): Configuration dictionary containing database file path and other parameters
    """

    # Fit the data to the Gumbel distribution
    # Cycle through the stat_results database table for cases that are flagged as 'A'
    # Skip any stat_results whose parent case_results is already NG
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Mark any stat_results as NG if their parent case is already NG
        # This handles wave_dirs that weren't in the failed batch but whose
        # case has been marked NG due to other wave_dirs failing.
        utils.custom_execute(
            cursor,
            """
            UPDATE stat_results
            SET status = 'NG'
            WHERE status IN ('A', 'A+')
            AND EXISTS (
                SELECT 1 FROM case_results c
                WHERE c.hs = stat_results.hs AND c.period = stat_results.period
                AND c.status = 'NG'
            )
            """,
        )
        conn.commit()

        utils.custom_execute(  # type: ignore
            cursor,
            """
            SELECT s.rowid, s.hs, s.period, s.wave_dir
            FROM stat_results s
            JOIN case_results c ON s.hs = c.hs AND s.period = c.period
            WHERE (s.status = 'A' OR s.status = 'A+')
            AND c.status != 'NG'
            """,
        )
        rows = cursor.fetchall()

    if not rows:
        logger.info("No statistical results to update.")
        return

    for row in rows:
        # These are the cases that require statistical analysis
        rowid, hs, period, wave_dir = row
        # Fit the data to the Gumbel distribution
        gumbel(config, hs, period, wave_dir)

    # Load the database again and go to table stat_results and go through each status with a status of 'A'
    # Then for each criteria determine the probabilistic load (either using the results from the Gumbel analysis or emperical analysis

    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        utils.custom_execute(
            cursor,
            """
            SELECT s.rowid, s.hs, s.period, s.wave_dir
            FROM stat_results s
            JOIN case_results c ON s.hs = c.hs AND s.period = c.period
            WHERE (s.status = 'A' OR s.status = 'A+')
            AND c.status != 'NG'
            """,
        )
        rows = cursor.fetchall()

    if not rows:
        logger.info("No statistical results to update.")
        return
    for row in rows:
        # These are the cases that require statistical analysis
        rowid, hs, period, wave_dir = row
        # Get the results for the given criteria and add to the list
        logger.info(
            f"Updating probabilistic load for case {hs}, {period}, {wave_dir}"
        )
        utils.update_probabilistic_load(hs, period, wave_dir, config)

    utils.sync_db_to_network()
