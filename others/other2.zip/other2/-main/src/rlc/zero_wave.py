import json
import logging
import os
import sys

import rlc.config as cfg
from rlc.utils_core import zero_wave_analysis


def setup_logger():
    if os.path.exists(cfg.ZERO_WAVE_LOG_PATH):
        os.remove(cfg.ZERO_WAVE_LOG_PATH)

    logger = logging.getLogger("ZeroWaveLogger")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False  # Prevent bubbling to root logger

    # Clear existing handlers to avoid duplicates
    logger.handlers.clear()

    # File handler
    fh = logging.FileHandler(cfg.ZERO_WAVE_LOG_PATH)
    fh.setLevel(logging.DEBUG)

    # # Console handler
    # ch = logging.StreamHandler()
    # ch.setLevel(logging.DEBUG)

    # Formatter
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    fh.setFormatter(formatter)
    # ch.setFormatter(formatter)

    logger.addHandler(fh)
    # logger.addHandler(ch)

    return logger


def main():
    logger = setup_logger()
    logger.info("zero_wave.py has started execution.")

    try:
        if len(sys.argv) < 2:
            logger.error("No configuration argument provided.")
            sys.exit(1)

        config_json = sys.argv[1]
        config = json.loads(config_json)
        logger.info("Starting zero_wave_analysis with provided config.")
        zero_wave_analysis(config, logger)
        logger.info("zero_wave_analysis completed successfully.")

    except Exception:
        logger.exception(
            "An error occurred during zero_wave_analysis execution."
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
