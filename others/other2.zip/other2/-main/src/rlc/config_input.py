import ast
import importlib.util
import logging
import os
import re
import sys
import time
import tkinter as tk
from decimal import Decimal
from importlib.resources import files
from tkinter import messagebox

import prettytable
import yaml

import rlc.utils as utils
from rlc.notifier_factory import get_notifier

logger = logging.getLogger("RLC")


def load_valid_entries(file_name):
    data_path = files("rlc.data").joinpath(file_name)
    with data_path.open("r", encoding="utf-8") as f:
        return set(line.strip() for line in f if line.strip())


def extract_user_defined_result_names(script_text):
    """
    Parse a Python script to extract user-defined result names from
    the UserDefinedResults() function.

    OrcaFlex requires user-defined results to be returned from a function
    called UserDefinedResults(model) as a tuple/list of dicts, each with
    a "Name" key.

    Args:
        script_text (str): The Python script source code.

    Returns:
        set: A set of user-defined result name strings.
    """
    names = set()
    try:
        tree = ast.parse(script_text)
    except SyntaxError:
        logger.warning(
            "Could not parse user-defined results script (syntax error)."
        )
        return names

    for node in ast.walk(tree):
        if (
            isinstance(node, ast.FunctionDef)
            and node.name == "UserDefinedResults"
        ):
            # Walk the entire function body, not just the return statement,
            # because results may be built in a variable (e.g. base_results)
            # before being returned.
            for child in ast.walk(node):
                if isinstance(child, ast.Dict):
                    for key, value in zip(child.keys, child.values):
                        if (
                            isinstance(key, ast.Constant)
                            and key.value == "Name"
                            and isinstance(value, ast.Constant)
                        ):
                            names.add(value.value)
    return names


def get_user_defined_results(m, config):
    """
    Extract user-defined result names from the OrcaFlex model's external
    function script (embedded or external file).

    Args:
        m: The loaded OrcaFlex model object.
        config (dict): The RLC configuration dictionary.

    Returns:
        set: A set of user-defined result name strings.
    """
    try:
        source = m.general.GetData("UserDefinedResultScriptFileSource", 0)
    except Exception:
        return set()

    if source == "Embedded":
        try:
            script_text = m.general.GetData("UserDefinedResultScript", 0)
        except Exception:
            return set()
        if not script_text:
            return set()
        logger.info("Parsing embedded user-defined results script.")
        return extract_user_defined_result_names(script_text)

    elif source == "External file":
        try:
            script_file = m.general.GetData(
                "UserDefinedResultScriptFileName", 0
            )
        except Exception:
            return set()
        if not script_file:
            return set()

        # Validate that the external script is listed in extra_files
        extra_files = config.get("extra_files", [])
        script_basename = os.path.basename(script_file)
        extra_basenames = [os.path.basename(f) for f in extra_files]
        if script_basename not in extra_basenames:
            logger.error(
                f"User-defined results script '{script_basename}' is not "
                f"listed in extra_files. It must be included for the "
                f"simulation to work."
            )
            return None  # Signal validation failure

        # Read the external script file
        base_dir = os.path.dirname(config.get("base_file", ""))
        script_path = os.path.join(base_dir, script_file)
        if not os.path.isfile(script_path):
            logger.error(
                f"User-defined results script file not found: {script_path}"
            )
            return None
        with open(script_path, "r", encoding="utf-8") as f:
            script_text = f.read()
        logger.info(
            f"Parsing external user-defined results script: {script_file}"
        )
        return extract_user_defined_result_names(script_text)

    return set()


def extract_orcaflex_version(path):
    with open(path, "r", encoding="utf8") as f:
        for line in f:
            if line.startswith("# Program:"):
                match = re.search(
                    r"OrcaFlex\s+([0-9.]+[a-z]?)", line, re.IGNORECASE
                )
                if match:
                    return match.group(1)
    return None


def load_yaml_config(file_path):
    """
    Load and parse the YAML configuration file.

    Args:
        file_path (str): Path to the YAML file.

    Returns:
        dict: Parsed configuration as a dictionary.
    """

    # Load Orcaflex API
    try:
        from OrcFxAPI import FileCreatorVersion, Model

        logger.info("Orcaflex API (OrcFxAPI) loaded")
    except ImportError:
        logger.error("Not able to load OrcFxAPI.")
        return False

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            # Read the YML file and store in config dictionary
            config = yaml.safe_load(f)
            logger.info(f"Configuration loaded from {file_path}")
            base_file = config.get("base_file")

            # Open Orcaflex Base File
            # Need to handle if base file is a yml file or a dat file
            # If *.dat file
            if base_file.endswith(".dat"):
                version = FileCreatorVersion(base_file)
            elif base_file.endswith(".yml"):
                version = extract_orcaflex_version(base_file)
            model = Model(base_file)
            # Add the base file version to the config dictionary
            config["base_file_version"] = version
            logger.info(f"OrcaFlex Base File Version: {version}")
            # Add the time step value and time step method to the config dictionary
            if model.general.ImplicitUseVariableTimeStep == "No":
                base_time_step = model.general.ImplicitConstantTimeStep
                config["base_time_step"] = base_time_step
                config["variable_time_step"] = False
                logger.info(f"Model Constant Time Step: {base_time_step}")
            else:
                max_time_step = model.general.ImplicitVariableMaxTimeStep
                config["base_time_step"] = max_time_step
                config["variable_time_step"] = True
                logger.info(f"Model Max Variable Time Step: {max_time_step}")

            return config
    except yaml.YAMLError as e:
        logger.error(f"Error parsing YAML file: {e}")
        sys.exit(1)


def print_config_aligned(config):
    """Print the configuration in an aligned format.

    Args:
        config (dict): Configuration dictionary.

    Returns:
        None: Prints the configuration to the logger.
    """

    logger.info("Header...")
    for line in config["header"].strip().splitlines():
        logger.info(line)

    logger.info("Configuration Parameters:")
    # Exclude 'header' and 'analysis_criteria' from alignment calculation
    # and printing, as they are handled separately
    keys_to_print = [
        key
        for key in config.keys()
        if key != "header" and key != "analysis_criteria"
    ]
    max_key_length = max(len(str(key)) for key in keys_to_print)

    for key in keys_to_print:
        value = config[key]
        logger.info(f"{key.ljust(max_key_length)} : {value}")

    # Print the analysis criteria in a formatted way
    # Show in a table format
    logger.info("Analysis Criteria:")
    criteria = config.get("analysis_criteria", [])

    # Define headers by searching for keys in all of the dictionaries
    headers = [
        "orcaflex_object_name",
        "orcaflex_object_parameter",
        "orcaflex_object_argument",
        "probability_level",
        "mode",
        "value",
    ]

    table = prettytable.PrettyTable(headers)
    for item in criteria:
        row = [item.get(header, "") for header in headers]
        table.add_row(row)

    print(table)


def validate_header(config):
    header = config.get("header")
    """
    Validate the header of the configuration.

    Args:
        header (str): The header string to validate.

    Returns:
        bool: True if the header is valid, False otherwise.
    """

    logger.debug("Validating Parameter: header")

    if not isinstance(header, str):
        logger.error("Header must be a string.")
        return False
    if not header.strip():
        logger.error("Header cannot be empty.")
        return False
    return True


def validate_base_file(config):
    base_file = config.get("base_file")
    """
    Validate the base file name.

    Args:
        base_file (str): The base file name to validate.

    Returns:
        bool: True if the base file is valid, False otherwise.
    """

    logger.debug("Validating Parameter: base_file")

    if not isinstance(base_file, str):
        logger.error("Base file must be a string.")
        return False
    if not base_file.endswith((".dat", ".yml")):
        logger.error("Base file must have a .dat or .yml extension.")
        return False
    return True


def validate_base_file_version(config):
    """
    Validate the base file version.  This is not in the input file but instead obtained
    from the base_file directly.

    Args:
        config (dict): The configuration dictionary containing the base file version.

    Returns:
        bool: True if the base file version is valid, False otherwise.
    """
    base_file_version = config.get("base_file_version")
    run_method = config.get("run_method")

    if run_method == "hpcflex":
        logger.debug("Validating Parameter: base_file_version")

        latest_acceptable_versions = [
            "11.0g",
            "11.1e",
            "11.2e",
            "11.3g",
            "11.4e",
            "11.5f",
            "11.6b",
        ]

        full_acceptable_versions = []

        # Process each version
        for version in latest_acceptable_versions:
            # Split into major.minor and patch letter
            major_minor = version[:-1]  # e.g., '11.0' from '11.0g'
            patch_letter = version[-1]  # e.g., 'g' from '11.0g'
            # Generate all patch versions for this minor release
            full_acceptable_versions.extend(
                utils.generate_patch_versions(major_minor, patch_letter)
            )

        # Sort the list to ensure versions are in order
        full_acceptable_versions.sort()

        logger.info("Validating base file version for HPC-Flex")

        if base_file_version not in full_acceptable_versions:
            logger.error(
                f"Base file version {base_file_version} is not acceptable."
            )
            return False

        return True

    else:
        return True


def validate_input_file_critical_keys(
    config, ignore_interactive_warnings=False
):
    """
    Check if critical keys in the input file have changed compared to the
    baseline.
    Critical keys:  base_file, calculate_jonswap_gamma,
                    calculate_jonswap_gamma_method, jonswap_gamma

    Args:
        config (dict): Configuration dictionary
        ignore_interactive_warnings (bool): If True, skip interactive dialog

    Returns:
        bool: True if validation passes or user chooses to continue, False
        otherwise
    """
    runs_folder = "runs"
    input_file = config.get("input_file_path")

    if not input_file or not os.path.exists(input_file):
        return True

    input_file_name = os.path.basename(input_file)
    baseline_name = input_file_name + ".original"
    baseline_path = os.path.join(runs_folder, baseline_name)

    if not os.path.exists(runs_folder) or not os.path.exists(baseline_path):
        return True

    # Load baseline config
    try:
        with open(baseline_path, "r", encoding="utf-8") as f:
            baseline_config = yaml.safe_load(f)
    except Exception as e:
        logger.warning(f"Could not load baseline input file: {e}")
        return True

    # Critical keys to check
    critical_keys = [
        "base_file",
        "period_type",
        "calculate_jonswap_gamma",
        "calculate_jonswap_gamma_method",
        "jonswap_gamma",
    ]

    changed_keys = []
    for key in critical_keys:
        # Only compare if key exists in baseline (not added at runtime)
        if key in baseline_config and config.get(key) != baseline_config.get(
            key
        ):
            changed_keys.append(key)

    if not changed_keys:
        logger.info("Input file critical parameters unchanged")
        return True

    # Critical parameters changed
    logger.error(
        f"Critical input file parameters have changed: {', '.join(changed_keys)}"
    )

    return False


def validate_base_file_hash(config, ignore_interactive_warnings=False):
    """
    This function checks to see if the 'runs' folder exists and if there is
    the Orcaflex base file already exists.  It then hashs the Orcaflex base
    file in the current working folder and compares the hash to the hash
    of the Orcaflex base file in the 'runs' folder to determine if the file has
    changed.

    Args:
        config (dict): Configuration dictionary
        ignore_interactive_warnings (bool): If True, skip interactive dialog
    """

    runs_folder = "runs"
    base_file = config.get("base_file")
    base_file_name = os.path.basename(base_file)

    # Check if runs folder exists
    if not os.path.exists(runs_folder):
        # No need to check, runs folder will be created later
        return True

    # Check if base file exists in runs folder
    base_file_in_runs = os.path.join(runs_folder, base_file_name)
    if not os.path.exists(base_file_in_runs):
        # No need to check, file doesn't exist in runs folder
        return True

    # Hash the base file in the current working directory
    current_hash = utils.hash_file(base_file)

    # Hash the base file in the runs folder
    runs_hash = utils.hash_file(base_file_in_runs)

    # Compare the hashes
    if current_hash != runs_hash:
        logger.warning("Base file has changed since last run.")

        # Skip dialog if ignore_interactive_warnings is True
        if ignore_interactive_warnings:
            logger.info(
                "Ignoring interactive warning (--ignore-interactive-warnings flag set)"
            )
            return True

        # Create hidden root window
        root = tk.Tk()
        root.withdraw()

        # Display dialog box
        result = messagebox.askyesno(
            "'runs' Folder Exists and Base File Changed",
            "The 'runs' folder exists and the base file has changed since "
            + "the last run.\n\nDo you want to continue?\n\n"
            + "RESULTS MAY NOT BE CORRECT IF THE BASE FILE HAS CHANGED AND"
            + "PREVIOUS RUNS HAVEN'T BEEN DELETED.",
            icon="warning",
        )

        root.destroy()

        if not result:
            logger.info("User chose to stop due to base file change.")
            return False
        else:
            logger.info("User chose to continue despite base file change.")
            return True

    else:
        logger.info("Base file in runs folder unchanged")

    return True


def validate_hs_start(config):
    hs_start = config.get("hs_start")
    """
    Validate the hs_start value.

    Args:
        hs_start (float): The hs_start value to validate.

    Returns:
        bool: True if the hs_start is valid, False otherwise.
    """

    logger.debug("Validating Parameter: hs_start")

    if not isinstance(hs_start, (int, float)):
        logger.error("'hs_start' must be a numeric value.")
        return False
    if hs_start < 0.1:
        logger.error("'hs_start' must be greater than 0.1 m.")
        return False
    if hs_start > 5:
        logger.warning("'hs_start' seems high.")
    if hs_start > 20:
        logger.warning("'hs_start' must be less than 20 m.")
    return True


def validate_hs_course_step(config):
    hs_course_step = config.get("hs_course_step")
    """
    Validate the hs_course_step value.

    Args:
        hs_course_step (float): The hs_course_step value to validate.

    Returns:
        bool: True if the hs_course_step is valid, False otherwise.
    """

    logger.debug("Validating Parameter: hs_course_step")

    if not isinstance(hs_course_step, (int, float)):
        logger.error("hs_course_step must be a numeric value.")
        return False
    if hs_course_step < 0.1:
        logger.error("hs_course_step must be greater than 0.1 m.")
        return False

    # Check if hs_course_step is a multiple of hs_start
    # This will also identify if hs_course_step is greater than hs_start
    hs_start = config.get("hs_start", 3.5)  # Default to 3.5 if not found
    hs_start_dec = Decimal(str(hs_start))
    hs_course_step_dec = Decimal(str(hs_course_step))
    if hs_start_dec > 0 and hs_start_dec % hs_course_step_dec != 0:
        logger.error(
            "hs_start must be a multiple of hs_course_step. "
            f"Current values: hs_course_step={hs_course_step}, hs_start={hs_start}"
        )
        return False

    return True


def validate_hs_fine_step(config):
    hs_fine_step = config.get("hs_fine_step")
    """
    Validate the hs_fine_step value.

    Args:
        hs_fine_step (float): The hs_fine_step value to validate.

    Returns:
        bool: True if the hs_fine_step is valid, False otherwise.
    """

    logger.debug("Validating Parameter: hs_fine_step")
    hs_course_step = config.get(
        "hs_course_step", 0.0
    )  # Default to 0.0 if not found

    if not isinstance(hs_fine_step, (int, float)):
        logger.error("hs_fine_step must be a numeric value.")
        return False
    if hs_fine_step < 0.1:
        logger.error("hs_fine_step must be greater than or equal to 0.1 m.")
        return False
    if hs_fine_step > hs_course_step:
        logger.error(
            "hs_fine_step must be less than or equal to hs_course step m."
        )
        return False

    # Check if hs_course_step is a multiple of hs_fine_step
    # This will also identify if hs_fine_step is greater than hs_course_step
    hs_course_step_dec = Decimal(str(hs_course_step))
    hs_fine_step_dec = Decimal(str(hs_fine_step))
    if hs_fine_step_dec > 0 and hs_course_step_dec % hs_fine_step_dec != 0:
        logger.error(
            "hs_course_step must be a multiple of hs_fine_step. "
            f"Current values: hs_course_step={hs_course_step}, hs_fine_step={hs_fine_step}"
        )
        return False

    return True


def validate_hs_min(config):
    hs_min = config.get("hs_min")
    """
    Validate the hs_min value.

    Args:
        hs_min (float): The hs_min value to validate.

    Returns:
        bool: True if the hs_min is valid, False otherwise.
    """

    logger.debug("Validating Parameter: hs_min")

    if not isinstance(hs_min, (int, float)):
        logger.error("hs_min must be a numeric value.")
        return False
    if hs_min < 0.1:
        logger.error("hs_min must be greater than or equal to 0.1 m.")
        return False

    # Check if hs_min is a multiple of hs_fine_step
    hs_fine_step = config.get(
        "hs_fine_step", 0.25
    )  # Default to 0.25 if not found
    hs_min_dec = Decimal(str(hs_min))
    hs_fine_step_dec = Decimal(str(hs_fine_step))
    if hs_min_dec > 0 and hs_min_dec % hs_fine_step_dec != 0:
        logger.error(
            "hs_fine_step must be a multiple of hs_min. "
            f"Current values: hs_fine_step={hs_fine_step}, hs_min={hs_min}"
        )
        return False

    return True


def validate_calculate_jonswap_gamma(config):
    calculate_jonswap_gamma = config.get("calculate_jonswap_gamma")
    """
    Validate the calculate_jonswap_gamma value.

    Args:
        calculate_jonswap_gamma (bool): The calculate_jonswap_gamma value to
        validate.

    Returns:
        bool: True if the calculate_jonswap_gamma is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_calculate_jonswap_gamma")

    if not isinstance(calculate_jonswap_gamma, bool):
        logger.error("calculate_jonswap_gamma must be a boolean value.")
        return False
    return True


def validate_calculate_jonswap_gamma_method(config):
    calculate_jonswap_gamma_method = config.get(
        "calculate_jonswap_gamma_method"
    )
    period_type: str = config.get("period_type")
    """
    Validate the calculate_jonswap_gamma_method value.

    Args:
        calculate_jonswap_gamma_method (str): The
        calculate_jonswap_gamma_method value to validate.

    Returns:
        bool: True if the calculate_jonswap_gamma_method is valid, False
        otherwise.
    """

    logger.debug("Validating Parameter: calculate_jonswap_gamma_method")

    valid_jonswap_gamma_methods: list[str] = ["dnv", "of", "pb"]

    if not isinstance(calculate_jonswap_gamma_method, str):
        logger.error("calculate_jonswap_gamma_method must be a string.")
        return False

    if calculate_jonswap_gamma_method not in valid_jonswap_gamma_methods:
        logger.error(
            f"calculate_jonswap_gamma_method must be one of "
            f"{valid_jonswap_gamma_methods}."
        )
        return False

    if calculate_jonswap_gamma_method == "pb" and period_type != "Tp":
        logger.error(
            "period_type must be 'Tp' when calculate_jonswap_gamma_method "
            "is 'pb'."
        )
        return False

    if calculate_jonswap_gamma_method == "of" and period_type != "Tz":
        logger.error(
            "period_type must be 'Tz' when calculate_jonswap_gamma_method is "
            "'of'."
        )
        return False

    if calculate_jonswap_gamma_method == "dnv" and period_type != "Tp":
        logger.error(
            "period_type must be 'Tp' when calculate_jonswap_gamma_method is "
            "'dnv'."
        )
        return False
    return True


def validate_period_type(config):
    period_type = config.get("period_type")
    """
    Validate the period_type value.

    Args:
        period_type (str): The period_type value to validate.

    Returns:
        bool: True if the period_type is valid, False otherwise.
    """

    logger.debug("Validating Parameter: period_type")

    valid_period_types = ["Tp", "Tz"]
    if not isinstance(period_type, str):
        logger.error("period_type must be a string.")
        return False
    if period_type not in valid_period_types:
        logger.error(f"period_type must be one of {valid_period_types}.")
        return False
    return True


def validate_calculate_min_period(config) -> bool:
    calculate_min_period = config.get("calculate_min_period")
    """
    Validate the calculate_min_period value.

    Args:
        calculate_min_period (bool): The calculate_min_period value to validate.

    Returns:
        bool: True if the calculate_min_period is valid, False otherwise.
    """

    logger.debug("Validating Parameter: calculate_min_period")

    if not isinstance(calculate_min_period, bool):
        logger.error("calculate_min_period must be a boolean value.")
        return False
    return True


def validate_jonswap_gamma(config):
    jonswap_gamma = config.get("jonswap_gamma")
    """
    Validate the jonswap_gamma value.

    Args:
        jonswap_gamma (float): The jonswap_gamma value to validate.

    Returns:
        bool: True if the jonswap_gamma is valid, False otherwise.
    """

    logger.debug("Validating Parameter: jonswap_gamma")

    if not isinstance(jonswap_gamma, (int, float)):
        logger.error("jonswap_gamma must be a numeric value.")
        return False
    if jonswap_gamma <= 0:
        logger.error("jonswap_gamma must be greater than 0.")
        return False
    return True


def validate_t_end(config):
    t_end = config.get("t_end")
    t_start = config.get("t_start")
    """
    Validate the t_end value.

    Args:
        t_end (float): The t_end value to validate.

    Returns:
        bool: True if the t_end is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_end")

    if not isinstance(t_end, (int, float)):
        logger.error("t_end must be a numeric value.")
        return False
    if t_end <= 1:
        logger.error("t_end must be greater than 1.")
        return False
    if t_end > 30:
        logger.error("t_end must be less than 30.")
        return False
    if t_start > t_end:
        logger.error("t_start must be less than t_end.")
        return False
    return True


def validate_t_start(config):
    t_end = config.get("t_end")
    t_start = config.get("t_start")
    """
    Validate the t_start value.

    Args:
        t_start (float): The t_start value to validate.

    Returns:
        bool: True if the t_start is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_start")

    if not isinstance(t_start, (int, float)):
        logger.error("t_start must be a numeric value.")
        return False
    if t_start <= 0:
        logger.error("t_start must be greater than 0.")
        return False
    if t_start > 30:
        logger.error("t_start must be less than 30.")
        return False
    if t_start > t_end:
        logger.error("t_start must be less than t_end.")
        return False
    return True


def validate_t_step(config):
    t_step = config.get("t_step")
    """
    Validate the t_step value.

    Args:
        t_step (float): The t_step value to validate.

    Returns:
        bool: True if the t_step is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_step")

    if not isinstance(t_step, (int, float)):
        logger.error("t_step must be a numeric value.")
        return False
    if t_step <= 0:
        logger.error("t_step must be greater than 0.")
        return False
    return True


def validate_t_step2(config):
    t_step2 = config.get("t_step2")
    """
    Validate the t_step2 value.

    Args:
        t_step2 (float): The t_step2 value to validate.

    Returns:
        bool: True if the t_step2 is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_step2")

    if not isinstance(t_step2, (int, float)):
        logger.error("t_step2 must be a numeric value.")
        return False
    if t_step2 <= 0:
        logger.error("t_step2 must be greater than 0.")
        return False
    return True


def validate_t_step_change(config):
    t_step_change = config.get("t_step_change")
    """
    Validate the t_step_change value.

    Args:
        t_step_change (float): The t_step_change value to validate.

    Returns:
        bool: True if the t_step_change is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_step_change")

    if not isinstance(t_step_change, (int, float)):
        logger.error("t_step_change must be a numeric value.")
        return False
    if t_step_change <= 0:
        logger.error("t_step_change must be greater than 0.")
        return False

    # Check to see if t_step_change is a multiple of t_step
    t_step = config.get("t_step", 1)
    t_step_change_dec = Decimal(str(t_step_change))
    t_step_dec = Decimal(str(t_step))
    if t_step_change_dec % t_step_dec != 0:
        logger.error(
            "t_step_change must be a multiple of t_step. "
            f"Current values: t_step={t_step}, t_step_change={t_step_change}"
        )
        return False

    return True


def validate_t_extra(config):
    t_extra = config.get("t_extra")
    """
    Validate the t_extra value.

    Args:
        t_extra (list): The t_extra value to validate.

    Returns:
        bool: True if the t_extra is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_extra")

    if not isinstance(t_extra, list):
        logger.error("t_extra must be a list.")
        return False
    for item in t_extra:
        if not isinstance(item, (int, float)):
            logger.error("All items in t_extra must be numeric values.")
            return False
    return True


def validate_wave_dirs(config):
    wave_dirs = config.get("wave_dirs")
    """
    Validate the wave_dirs value.

    Args:
        wave_dirs (list): The wave_dirs value to validate.

    Returns:
        bool: True if the wave_dirs is valid, False otherwise.
    """

    logger.debug("Validating Parameter: wave_dirs")

    if not isinstance(wave_dirs, list):
        logger.error("wave_dirs must be a list.")
        return False
    for item in wave_dirs:
        if not isinstance(item, (int, float)):
            logger.error("All items in wave_dirs must be numeric values.")
            return False
        if item <= 0 or item > 360:
            logger.error("Wave directions must be between 0 and 360 degrees.")
            return False
    return True


def validate_min_seeds(config):
    min_seeds = config.get("min_seeds")
    """
    Validate the min_seeds value.

    Args:
        min_seeds (int): The min_seeds value to validate.

    Returns:
        bool: True if the min_seeds is valid, False otherwise.
    """

    logger.debug("Validating Parameter: min_seeds")

    if not isinstance(min_seeds, int):
        logger.error("min_seeds must be an integer.")
        return False
    if min_seeds <= 10:
        logger.error("min_seeds must be greater than 10.")
        return False
    if min_seeds > 1000:
        logger.error("min_seeds must be less than or equal to 1000.")
        return False
    return True


def validate_seed_random_generator(config):
    seed_random_generator = config.get("seed_random_generator")
    """
    Validate the seed_random_generator value.

    Args:
        seed_random_generator (int): The seed_random_generator value to validate.

    Returns:
        bool: True if the seed_random_generator is valid, False otherwise.
    """

    logger.debug("Validating Parameter: seed_random_generator")

    if not isinstance(seed_random_generator, int):
        logger.error("seed_random_generator must be an integer.")
        return False
    return True


def validate_alpha_factor(config):
    alpha_factor = config.get("alpha_factor")
    """
    Validate the alpha_factor value.

    Args:
        alpha_factor (float): The alpha_factor value to validate.

    Returns:
        bool: True if the alpha_factor is valid, False otherwise.
    """

    logger.debug("Validating Parameter: alpha_factor")

    if not isinstance(alpha_factor, (int, float)):
        logger.error("alpha_factor must be a numeric value.")
        return False
    if alpha_factor > 1:
        logger.error("alpha_factor must be less than or equal to 1.")
        return False

    if alpha_factor <= 0:
        logger.error("alpha_factor must be greater than 0.")
        return False
    return True


def validate_run_method(config):
    run_method = config.get("run_method")
    """
    Validate the run_method value.

    Args:
        run_method (str): The run_method value to validate.

    Returns:
        bool: True if the run_method is valid, False otherwise.
    """

    logger.debug("Validating Parameter: run_method")

    valid_run_methods = ["dof", "hpcflex", "local"]
    if not isinstance(run_method, str):
        logger.error("run_method must be a string.")
        return False
    if run_method not in valid_run_methods:
        logger.error(f"run_method must be one of {valid_run_methods}.")
        return False

    # If run_method is HPC-Flex, see if the HPC-Flex API is installed?
    if importlib.util.find_spec("hpcflex") is not None:
        logger.info("HPC-Flex is installed in the current environment.")
    else:
        logger.error("HPC-Flex is not installed in the current environment.")
        return False

    return True


def validate_extra_files(config):
    extra_files = config.get("extra_files", [])
    """
    Validate the extra_files value.

    Args:
        extra_files (list): The extra_files value to validate.

    Returns:
        bool: True if the extra_files is valid, False otherwise.
    """

    logger.debug("Validating Parameter: extra_files")

    if not isinstance(extra_files, list):
        logger.error("extra_files must be a list.")
        return False
    for file in extra_files:
        if not isinstance(file, str):
            logger.error("All items in extra_files must be strings.")
            return False
        if not file.endswith((".dll", ".py", ".his", ".inc")):
            logger.error(
                "Each file in extra_files must have a .dll, .py, .his or .inc extension."
            )
            return False
    return True


def validate_ks_test_criteria(config):
    ks_test_criteria = config.get("ks_test_criteria", 0.05)
    """
    Validate the ks_test_criteria value.

    Args:
        ks_test_criteria (float): The ks_test_criteria value to validate.

    Returns:
        bool: True if the ks_test_criteria is valid, False otherwise.
    """

    logger.debug("Validating Parameter: ks_test_criteria")

    _KS_VALID_LEVELS = {0.15, 0.10, 0.05, 0.025, 0.01}
    if ks_test_criteria not in _KS_VALID_LEVELS:
        logger.error(
            f"ks_test_criteria must be one of {sorted(_KS_VALID_LEVELS, reverse=True)}"
        )
        return False
    return True


def validate_ad_test_criteria(config):
    ad_test_criteria = config.get("ad_test_criteria", 0.05)
    """
    Validate the ad_test_criteria value.

    Args:
        ad_test_criteria (float): The ad_test_criteria value to validate.

    Returns:
        bool: True if the ad_test_criteria is valid, False otherwise.
    """

    logger.debug("Validating Parameter: ad_test_criteria")

    _AD_VALID_LEVELS = {0.15, 0.10, 0.05, 0.025, 0.01}
    if ad_test_criteria not in _AD_VALID_LEVELS:
        logger.error(
            f"ad_test_criteria must be one of {sorted(_AD_VALID_LEVELS, reverse=True)}"
        )
        return False
    return True


def validate_force_skip_sim_file_save(config):
    force_skip_sim_file_save = config.get("force_skip_sim_file_save")
    """
    Validate the force_skip_sim_file_save value.

    Args:
        force_skip_sim_file_save (bool): The force_skip_sim_file_save value to validate.

    Returns:
        bool: True if the force_skip_sim_file_save is valid, False otherwise.
    """

    logger.debug("Validating Parameter: force_skip_sim_file_save")

    if not isinstance(force_skip_sim_file_save, bool):
        logger.error("force_skip_sim_file_save must be a boolean value.")
        return False
    return True


def validate_automatic_post_calc(config):
    auto_post_calc = config.get("automatic_post_calc")
    """
    Validate the automatic_post_calc value.

    Args:
        automatic_post_calc (bool): The automatic_post_calc value to validate.

    Returns:
        bool: True if the automatic_post_calc is valid, False otherwise.
    """
    logger.debug("Validating Parameter: automatic_post_calc")

    if not isinstance(auto_post_calc, bool):
        logger.error("automatic_post_calc must be a boolean value.")
        return False

    # If automatic_post_calc is False, ensure the file name referenced in the Orcaflex File
    # is correct.

    # Load Orcaflex API
    try:
        from OrcFxAPI import DLLError as ofDLLError
        from OrcFxAPI import Model as ofModel
        from OrcFxAPI import stLicensingError as ofstLicensingError

        logger.info("Orcaflex API (OrcFxAPI) loaded")
    except ImportError:
        logger.error("Not able to load OrcFxAPI.")
        return False

    # Load the OF model
    logger.info("Reading name of post calculation actions scripts from model.")
    while True:
        try:
            m = ofModel(config.get("base_file"))
            break
        except ofDLLError as err:
            if not err.status == ofstLicensingError:
                raise
            else:
                logger.info("Trying to get an Orcaflex license...")
                time.sleep(3)

    # Ensure there is at least one post calc action file referenced
    number_post_calc_actions = m.general.GetData(
        "NumberOfPostCalculationActions", 0
    )
    if number_post_calc_actions == 0:
        logger.error(
            "No post calculation action set up in the model."
            "At least one action is required."
        )
        return False

    if auto_post_calc:
        logger.debug("Checking to see if auto post calc files are present.")
        # Check if post calc action name file name is included in the post calc actions.
        for i in range(number_post_calc_actions):  # type: ignore
            m.general.SelectedPostCalculationAction = m.general.GetData(
                "PostCalculationActionName", i
            )
            post_calc_script_name = m.general.GetData(
                "PostCalculationActionScriptFileName", 0
            )

            # If using Auto Post Calc Actions
            if post_calc_script_name == "auto_post_calc_action.py":
                logger.info("Automatic Post Calc Action Specified...")
                break

            # If this is the last item and it wasn't found, then return error.
            if i == number_post_calc_actions - 1:  # type: ignore
                logger.error(
                    "The post calculation action file referenced in the model "
                    "is not in the folder."
                )
                logger.error(
                    "Automatic Post Calc Action file 'auto_post_calc_action.py' not found..."
                )
                return False

    else:
        logger.debug("Checking to see if post calc files are present.")
        # Ensure that post calc action file is in the folder
        for i in range(number_post_calc_actions):  # type: ignore
            post_calc_script_name = m.general.GetData(
                "PostCalculationActionScriptFileName", 0
            )
            if not os.path.exists(post_calc_script_name):  # type: ignore
                logger.error(
                    "The post calculation action file referenced in the model "
                    "is not in the folder."
                )
                return False

    return True


def validate_path_orcfx_dll(config):
    """
    Validates the path the the OrcaFlex API dll for DOF

    Args:
        path_orcfx_dll (str): The path to the OrcaFlex API dll

    Returns:
        bool: True if the path_orcfx_dll is valid, False otherwise.
    """
    logger.debug("Validating Parameter: path_orcfx_dll")
    # Get the path from the config file
    path_orcfx_dll = config.get("path_orcfx_dll")
    run_method = config.get("run_method")

    # If the value is "" then there is no path to be checked
    # Likely that HPC-Flex is to be used.
    if run_method == "dof":
        if path_orcfx_dll == "":
            logger.error("No path to the OrcaFlex API dll specified.")
            return False
        # Check to see if the file can be found
        if not os.path.exists(path_orcfx_dll):
            logger.error("The path to the OrcaFlex API dll is not valid.")
            return False
        else:
            logger.info("DOF dll path valid.")

    return True


def validate_num_bootstraps(config):
    num_bootstraps = config.get("num_bootstraps")
    """
    Validate the num_bootstraps value.

    Args:
        num_bootstraps (int): The number of bootstrap samples

    Returns:
        bool: True if the num_bootstraps is valid, False otherwise.
    """
    if not isinstance(num_bootstraps, int):
        logger.error("num_bootstraps must be an integer.")
        return False
    if not (num_bootstraps >= 1000):
        logger.error("num_bootstraps must be greater than or equal to 1000")
        return False
    if not (num_bootstraps <= 1000000):
        logger.error("num_bootstraps must be less than or equal to 1000000")
        return False
    return True


def validate_max_bisections(config):
    max_bisections = config.get("max_bisections")
    """
    Validate the max_bisections value.

    Args:
        max_bisections (int): The number of bisections that are
        performed if a case failed due to instability

    Returns:
        bool: True if the max_bisections is valid, False otherwise.
    """
    if not isinstance(max_bisections, int):
        logger.error("max_bisections must be an integer.")
        return False
    if max_bisections < 0:
        logger.error("max_bisections must be greater than or equal to 0")
        return False
    if max_bisections > 5:
        logger.error("max_bisections must be less than or equal to 5")
        return False
    return True


def validate_zero_wave_timeout(config):
    zero_wave_timeout = config.get("zero_wave_timeout")
    """
    Validate the zero_wave_timeout parameter

    Args:
        zero_wave_timeout (int): The number of seconds before timeout

    Returns:
        bool: True if the zero_wave_timeout is valid, False otherwise.
    """
    if not isinstance(zero_wave_timeout, int):
        logger.error("zero_wave_timeout must be an integer.")
        return False
    if zero_wave_timeout < 1:
        logger.error("zero_wave_timeout must be greater than or equal to 1")
        return False
    return True


def validate_conf_interval(config):
    conf_interval = config.get("conf_interval")
    """
    Validate the probability_level value.

    Args:
        probability_level (float): The probability_level value to validate.

    Returns:
        bool: True if the probability_level is valid, False otherwise.
    """
    if not isinstance(conf_interval, (float)):
        logger.error("conf_interval must be a numeric value.")
        return False
    if not (0 < conf_interval < 1):
        logger.error("conf_interval must be between 0 and 1.")
        return False
    return True


def validate_email_on_failure(config):
    email_on_failure = config.get("email_on_failure")
    """
    Validate the email_on_failure value.

    Args:
        email_on_failure (bool): The email_on_failure value to validate.

    Returns:
        bool: True if the email_on_failure is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_calculate_jonswap_gamma")

    if not isinstance(email_on_failure, bool):
        logger.error("email_on_failure must be a boolean value.")
        return False
    return True


def validate_email_on_loop(config):
    email_on_loop = config.get("email_on_loop")
    """
    Validate the email_on_loop value.

    Args:
        email_on_loop (bool): The email_on_loop value to validate.

    Returns:
        bool: True if the email_on_loop is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_calculate_jonswap_gamma")

    if not isinstance(email_on_loop, bool):
        logger.error("email_on_loop must be a boolean value.")
        return False
    return True


def validate_email_on_finish(config):
    email_on_finish = config.get("email_on_finish")
    """
    Validate the email_on_finish value.

    Args:
        email_on_finish (bool): The email_on_finish value to validate.

    Returns:
        bool: True if the email_on_finish is valid, False otherwise.
    """

    logger.debug("Validating Parameter: t_calculate_jonswap_gamma")

    if not isinstance(email_on_finish, bool):
        logger.error("email_on_finish must be a boolean value.")
        return False
    return True


def validate_analysis_criteria(config):
    """
    Validate the analysis_criteria value.

    Args:
        analysis_criteria (dict): The analysis_criteria value to validate.

    Returns:
        bool: True if the analysis_criteria is valid, False otherwise.
    """
    logger.debug("Validating Parameter: analysis_criteria")

    def validate_orcaflex_object_name(orcaflex_object_name, m):
        """
        Validate the orcaflex_object_name value.

        Args:
            orcaflex_object_name (str): The orcaflex_object_name value to validate.

        Returns:
            bool: True if the orcaflex_object_name is valid, False otherwise.
        """
        # Check that it is a string
        if not isinstance(orcaflex_object_name, str):
            logger.error("orcaflex_object_name must be a string.")
            return False

        # Check that the name exists in the model
        if orcaflex_object_name not in m:
            logger.error(f"'{orcaflex_object_name}' doesn't exist in model.")
            return False

        # Check that the object type is an acceptable type:
        acceptable_types = [
            "Line",
            "6D buoy",
            "Link",
            "Winch",
            "Constraint",
            "Shape",
        ]
        obj_type = m[orcaflex_object_name].typeName
        if obj_type not in acceptable_types:
            logger.error(
                f"{obj_type} is not an acceptable type. "
                f"Must be one of {acceptable_types}"
            )
            return False

        return True

    def validate_orcaflex_object_parameter(
        m, orcaflex_object_name, orcaflex_object_parameter, user_defined_names
    ):
        """
        Validate the orcaflex_object_parameter value.

        Args:
            orcaflex_object_parameter (str): The orcaflex_object_parameter value to validate.
            user_defined_names (set): Set of valid user-defined result names.

        Returns:
            bool: True if the orcaflex_object_parameter is valid, False otherwise.
        """
        if not isinstance(orcaflex_object_parameter, str):
            logger.error("orcaflex_object_parameter must be a string.")
            return False

        # Check if it is a user-defined result
        if orcaflex_object_parameter in user_defined_names:
            return True

        # Get Orcaflex object type:
        obj_type = m[orcaflex_object_name].typeName
        if obj_type == "Line":
            valid_parameters = load_valid_entries("valid_line_results.txt")
        elif obj_type == "6D buoy":
            valid_parameters = load_valid_entries("valid_6dbuoy_results.txt")
        elif obj_type == "Link":
            valid_parameters = load_valid_entries("valid_link_results.txt")
        elif obj_type == "Winch":
            valid_parameters = load_valid_entries("valid_winch_results.txt")
        elif obj_type == "Constraint":
            valid_parameters = load_valid_entries(
                "valid_constraint_results.txt"
            )
        elif obj_type == "Shape":
            valid_parameters = load_valid_entries("valid_shape_results.txt")
        else:
            valid_parameters = []

        # Check if the parameter is a valid parameter per the valid_X_results.txt files in data.
        if orcaflex_object_parameter not in valid_parameters:
            logger.error(
                f"'{orcaflex_object_parameter}' is not a valid result parameter for a {obj_type} element"
            )
            return False

        return True

    def validate_orcaflex_object_argument(
        m, orcaflex_object_name, orcaflex_object_argument
    ):
        """
        Validate the orcaflex_object_argument value.

        Args:
            orcaflex_object_argument (str or float): The orcaflex_object_argument value to validate.

        Returns:
            bool: True if the orcaflex_object_argument is valid, False otherwise.
        """

        if isinstance(orcaflex_object_argument, (int, float)):
            # Value is a float, need to make sure it is less than the length of the line
            if (
                orcaflex_object_argument
                > m[orcaflex_object_name].cumulativeLength[-1]
            ):
                logger.error(
                    f"'The arc length for {orcaflex_object_argument}' is larger than the total line length."
                )
                return False

            return True  # Accept any float

        if isinstance(orcaflex_object_argument, str):
            valid_strings = {"End A", "End B", "Range"}
            return orcaflex_object_argument.strip() in valid_strings

        logger.error(
            f"The argument for {orcaflex_object_argument} is not an string, integer or float."
        )
        return False  # Invalid type

    def validate_probability_level(probability_level):
        """
        Validate the probability_level value.

        Args:
            probability_level (float): The probability_level value to validate.

        Returns:
            bool: True if the probability_level is valid, False otherwise.
        """
        if not isinstance(probability_level, (int, float)):
            logger.error("probability_level must be a numeric value.")
            return False
        if not (0 <= probability_level <= 1):
            logger.error("probability_level must be between 0 and 1.")
            return False
        return True

    def validate_mode(mode):
        """
        Validate the mode value.

        Args:
            mode (str): The mode value to validate.

        Returns:
            bool: True if the mode is valid, False otherwise.
        """
        if not isinstance(mode, str):
            logger.error("mode must be a string.")
            return False
        valid_modes = ["max", "min", "abs"]
        if mode not in valid_modes:
            logger.error(f"mode must be one of {valid_modes}.")
            return False
        return True

    def validate_value(value):
        """
        Validate the value.

        Args:
            value (float): The value to validate.

        Returns:
            bool: True if the value is valid, False otherwise.
        """
        if not isinstance(value, (int, float)):
            logger.error("Acceptance value must be a numeric value.")
            return False
        return True

    # analysis_criteria is a list of dictionaries, each with keys:
    analysis_criteria = config.get("analysis_criteria")

    # Load the OrcaFlex model:
    # Load Orcaflex API
    try:
        from OrcFxAPI import DLLError as ofDLLError
        from OrcFxAPI import Model as ofModel
        from OrcFxAPI import stLicensingError as ofstLicensingError

        logger.info("Orcaflex API (OrcFxAPI) loaded")
    except ImportError:
        logger.error("Not able to load OrcFxAPI.")
        return False

    # Load the OF model
    while True:
        try:
            m = ofModel(config.get("base_file"))
            break
        except ofDLLError as err:
            if not err.status == ofstLicensingError:
                raise
            else:
                logger.info("Trying to get an Orcaflex license...")
                time.sleep(3)

    # Extract user-defined result names from the model
    user_defined_names = get_user_defined_results(m, config)
    if user_defined_names is None:
        # None signals a validation error (e.g. external script not in extra_files)
        return False
    if user_defined_names:
        logger.info(
            f"User-defined results found: {', '.join(sorted(user_defined_names))}"
        )

    if not isinstance(analysis_criteria, list):
        logger.error("analysis_criteria must be a list.")
        return False

    # Each criteria in analysis_criteria should be a dictionary with specific and optional keys
    required_keys = [
        "orcaflex_object_name",
        "orcaflex_object_parameter",
        "probability_level",
        "mode",
        "value",
    ]
    optional_keys = ["orcaflex_object_argument"]

    # Track duplicates: key = (name, parameter, argument, probability_level, mode)
    # Use dict to also report indices of the duplicate entries
    seen_keys: dict[tuple, int] = {}

    for i, criteria in enumerate(analysis_criteria):
        if not isinstance(criteria, dict):
            logger.error(
                "Each item in analysis_criteria must be a dictionary."
            )
            return False

        # Check for required keys
        for key in required_keys:
            if key not in criteria:
                logger.error(
                    f"Missing required key '{key}' in analysis_criteria item: {criteria}"
                )
                return False

        # Check for optional keys
        for key in criteria.keys():
            if key not in required_keys and key not in optional_keys:
                logger.error(
                    f"Invalid key '{key}' found in analysis_criteria item: {criteria}"
                )
                return False

        # Validate each key using its corresponding validation function
        # Check orcaflex_object_name
        if "orcaflex_object_name" in criteria:
            # Checks to make sure it's a string and that the object exists.
            if not validate_orcaflex_object_name(
                criteria["orcaflex_object_name"], m
            ):
                return False

        # Check orcaflex_object_parameter
        if "orcaflex_object_parameter" in criteria:
            if not validate_orcaflex_object_parameter(
                m,
                criteria["orcaflex_object_name"],
                criteria["orcaflex_object_parameter"],
                user_defined_names,
            ):
                return False

        obj_type = m[criteria["orcaflex_object_name"]].typeName
        if "orcaflex_object_argument" in criteria:
            if obj_type == "Line":
                if not validate_orcaflex_object_argument(
                    m,
                    criteria["orcaflex_object_name"],
                    criteria["orcaflex_object_argument"],
                ):
                    return False
            else:
                logger.info(
                    f"Object {criteria['orcaflex_object_name']} is of type: {obj_type}"
                )
                logger.error(
                    f"A orcaflex_object_argument has been specified for {criteria['orcaflex_object_name']}.  This object does not require an argument"
                )
                return False
        else:
            if obj_type == "Line":
                logger.error(
                    f"Object {criteria['orcaflex_object_name']} is a Line Element and requires a positional argument."
                )
                return False

        if "probability_level" in criteria:
            if not validate_probability_level(criteria["probability_level"]):
                return False

        if "mode" in criteria:
            if not validate_mode(criteria["mode"]):
                return False

        if "value" in criteria:
            if not validate_value(criteria["value"]):
                return False

        # Build the uniqueness key (treat missing optional argument as None)
        arg = criteria.get("orcaflex_object_argument", None)
        key = (
            criteria["orcaflex_object_name"],
            criteria["orcaflex_object_parameter"],
            arg,
            float(criteria["probability_level"]),  # normalize numeric
            criteria["mode"],
        )

        # Check for duplicates
        if key in seen_keys:
            prev_i = seen_keys[key]
            logger.error(
                "Duplicate analysis_criteria detected: entries %d and %d have the same "
                "(orcaflex_object_name, orcaflex_object_parameter, orcaflex_object_argument, "
                "probability_level, mode) = %s. Only one criterion is allowed for a given "
                "combination, even if 'value' differs.",
                prev_i,
                i,
                key,
            )
            return False

        seen_keys[key] = i

    return True


def validate_input(config, ignore_interactive_warnings=False):
    """
    Validate the input data for the RLC analysis.

    Args:
        config (dict): The input data to validate.
        ignore_interactive_warnings (bool): If True, skip interactive dialogs

    Returns:
        bool: True if the input is valid, False otherwise.
    """

    # Define default values
    default_values = {
        "hs_start": 3.5,
        "hs_course_step": 0.5,
        "hs_fine_step": config.get("hs_course_step"),
        "hs_min": 0.25,
        "period_type": "Tp",
        "calculate_jonswap_gamma": True,
        "calculate_jonswap_gamma_method": "of",
        "calculate_min_period": True,
        "jonswap_gamma": 1.0,
        "t_end": 18.0,
        "t_start": 1.0,
        "t_step": 1.0,
        "t_step2": 2.0,
        "t_step_change": 8.0,
        "t_extra": [],
        "wave_dirs": [165, 180, 195],
        "min_seeds": 50,
        "seed_random_generator": 12343,
        "alpha_factor": 1.0,
        "run_method": "dof",
        "extra_files": [],
        "ks_test_criteria": 0.05,
        "ad_test_criteria": 0.05,
        "force_skip_sim_file_save": True,
        "automatic_post_calc": True,
        "num_bootstraps": 10000,
        "conf_interval": 0.95,
        "max_bisections": 0,
        "email_on_failure": False,
        "email_on_loop": False,
        "email_on_finish": False,
        "zero_wave_timeout": 600,
        "path_orcfx_dll": r"",
    }

    # Ensure config is a dictionary
    if not isinstance(config, dict):
        logger.error("Input configuration must be a dictionary.")
        return False

    # Map keys to their validation functions
    validation_functions = {
        "header": validate_header,
        "base_file": validate_base_file,
        "base_file_hash": validate_base_file_hash,
        "input_file_critical_keys": validate_input_file_critical_keys,
        "hs_start": validate_hs_start,
        "hs_course_step": validate_hs_course_step,
        "hs_fine_step": validate_hs_fine_step,
        "hs_min": validate_hs_min,
        "period_type": validate_period_type,
        "calculate_jonswap_gamma": validate_calculate_jonswap_gamma,
        "calculate_jonswap_gamma_method": validate_calculate_jonswap_gamma_method,
        "calculate_min_period": validate_calculate_min_period,
        "jonswap_gamma": validate_jonswap_gamma,
        "t_end": validate_t_end,
        "t_start": validate_t_start,
        "t_step": validate_t_step,
        "t_step2": validate_t_step2,
        "t_step_change": validate_t_step_change,
        "t_extra": validate_t_extra,
        "wave_dirs": validate_wave_dirs,
        "min_seeds": validate_min_seeds,
        "seed_random_generator": validate_seed_random_generator,
        "alpha_factor": validate_alpha_factor,
        "run_method": validate_run_method,
        "extra_files": validate_extra_files,
        "ks_test_criteria": validate_ks_test_criteria,
        "ad_test_criteria": validate_ad_test_criteria,
        "force_skip_sim_file_save": validate_force_skip_sim_file_save,
        "automatic_post_calc": validate_automatic_post_calc,
        "num_bootstraps": validate_num_bootstraps,
        "conf_interval": validate_conf_interval,
        "max_bisections": validate_max_bisections,
        "analysis_criteria": validate_analysis_criteria,
        "path_orcfx_dll": validate_path_orcfx_dll,
        "base_file_version": validate_base_file_version,
        "email_on_failure": validate_email_on_failure,
        "email_on_loop": validate_email_on_loop,
        "email_on_finish": validate_email_on_finish,
        "zero_wave_timeout": validate_zero_wave_timeout,
    }

    # Check to see if any keys are not a valid key.  If an invalid key is found, log an error and return False.
    valid_keys = set(validation_functions.keys()).union(
        set(default_values.keys())
    )
    # Adding keys to valid_keys that are added by the script (not in the input yml file)
    valid_keys.add("base_time_step")
    valid_keys.add("variable_time_step")
    valid_keys.add("input_file_path")
    for key in config.keys():
        if key not in valid_keys:
            logger.error(f"Invalid key found in input configuration: {key}")
            return False

    # Check for required keys
    required_keys = ["header", "base_file", "analysis_criteria"]
    for key in required_keys:
        if key not in config:
            logger.error(f"Input file must contain a '{key}' key.")
            return False

    # Populate missing keys with default values
    for key, default_value in default_values.items():
        if key not in config:
            config[key] = default_value
            logger.warning(
                f"Key '{key}' is missing from the input configuration. Using default value: {default_value}"
            )

    # Validate each key using its corresponding validation function
    logger.info("Validating input configuration...")
    for key, validate_func in validation_functions.items():
        if key in ["base_file_hash", "input_file_critical_keys"]:
            # Pass ignore_interactive_warnings to these validations
            if not validate_func(config, ignore_interactive_warnings):
                logger.error(f"Validation failed for key: {key}")
                return False
        else:
            if not validate_func(config):
                logger.error(f"Validation failed for key: {key}")
                return False

    return True


def import_input_file(input_file, ignore_interactive_warnings=False):
    """Import the input file and print its contents.
    This function expects the input file to be passed as a command line argument.
    It loads the YAML configuration and prints it in an aligned format.

    Args:
        input_file (str): Path to the input YAML file.
        ignore_interactive_warnings (bool): If True, skip interactive dialogs

    Returns:
        dict: Configuration dictionary
    """

    config = load_yaml_config(input_file)

    # Store input file path in config for later use
    config["input_file_path"] = input_file

    if not validate_input(config, ignore_interactive_warnings):
        msg = "Invalid input configuration. Please check the input file."
        logger.error(msg)

        # Get flag for email_on_failure
        try:
            # Catches case where email_on_failure not properly defined
            config.get("email_on_failure")
            if config.get("email_on_failure"):
                notifier = get_notifier()
                notifier.error(msg)
        except Exception as e:
            logger.error(f"Error sending email: {e}")
        sys.exit(1)

    print_config_aligned(config)

    # Add your input file import code here
    logger.info("Input file imported successfully.")

    return config
