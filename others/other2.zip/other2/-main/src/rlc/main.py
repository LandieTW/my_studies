import argparse
import ctypes
import os
import subprocess
import sys

import rlc.analysis as analysis
import rlc.config as cfg
import rlc.config_input as config_input
import rlc.database_setup as database_setup
import rlc.output as output
import rlc.rlc_console as rlc_console
import rlc.utils as utils
from rlc import __author__, __date__, __docs__, __email__, __url__, __version__
from rlc.console_manager import ConsoleManager
from rlc.logger_config import setup_logger, switch_to_rich_logging
from rlc.notifier_factory import get_notifier


def display_intro():
    """Display the RLC ASCII intro."""
    intro = r"""
    
    
    ██████  ██       ██████ 
    ██   ██ ██      ██      
    ██████  ██      ██      
    ██   ██ ██      ██      
    ██   ██ ███████  ██████ 

    Repeated Lowering Control (RLC)
     - Performs a repeated lowering (or hoisting) analysis for an offshore lifting operation.
    
    {:<15} {}
    {:<15} {}
    {:<15} {}
    {:<15} {}
    {:<15} {}
    (c) TechnipFMC 2026
    
    """.format(
        "Version:",
        __version__,
        "Created by:",
        __author__ + ", " + __email__,
        "Date:",
        __date__,
        "Documentation:",
        __docs__,
        "Source Code:",
        __url__,
    )
    print(intro)


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Run RLC validation.")
    parser.add_argument(
        "input_file",
        nargs="?",
        default="rlc_input.yml",
        help="Path to the input file (default: rlc_input.yml)",
    )
    parser.add_argument(
        "--debug", action="store_true", help="Enable debug logging"
    )
    parser.add_argument(
        "--ignore-interactive-warnings",
        action="store_true",
        help="Skip interactive warning dialogs (e.g., base file change check)",
    )
    return parser.parse_args()


def get_config(logger, args):
    # Read the configuration input file
    logger.info("Importing and checking input file...")
    config = config_input.import_input_file(
        args.input_file, args.ignore_interactive_warnings
    )
    return config


def run(config, logger):
    # Set up result databases using SQLite
    cases = database_setup.setup_database(config)

    logger.info("Switching to rich console...")
    # Initialize the console manager
    console_manager = ConsoleManager()
    console_manager.initialize(config, logger)

    # Only call this once
    switch_to_rich_logging(
        logger,
        console=console_manager.console,
        layout=console_manager.layout,
        data=console_manager.data,
        hs_values=console_manager.hs_values,
        period_values=console_manager.period_values,
        main_table=console_manager.main_table,
        legend_table=console_manager.legend_table,
        live=console_manager.live,
        update_callback=rlc_console.update_table,
    )

    try:
        analysis.run_analysis(
            console_manager=console_manager, config=config, cases=cases
        )

        # Finalize the database
        analysis.finalize_case_results(config)

        # Final sync of local DB to network/project location
        utils.sync_db_to_network()

        # Create the required output files
        output.rlc_output(config=config)

        logger.info(
            "RLC has completed successfully.  This window can now be closed."
        )

    except FileNotFoundError as e:
        logger.error(str(e))
        raise SystemExit(1)

    except KeyboardInterrupt:
        logger.info("Analysis interrupted by user")

    finally:
        console_manager.finalize()
        if os.path.exists(cfg.LOCAL_DB_PATH):
            import gc

            gc.collect()
            try:
                os.remove(cfg.LOCAL_DB_PATH)
                logger.info("Local temp database removed.")
            except OSError as e:
                logger.warning(f"Could not remove local temp database: {e}")


def _disable_quickedit():
    """Disable QuickEdit mode on the Windows console.

    When QuickEdit is enabled (the default), clicking in the console window
    enters *Mark/Select* mode which **blocks all writes to stdout/stderr**,
    effectively freezing the script.  Pressing Enter or Escape resumes it.
    Disabling QuickEdit prevents this accidental freeze while keeping normal
    text selection available via the Edit menu.
    """
    try:
        kernel32 = ctypes.windll.kernel32
        STD_INPUT_HANDLE = ctypes.c_uint(-10 & 0xFFFFFFFF)
        handle = kernel32.GetStdHandle(STD_INPUT_HANDLE)
        # Current mode
        mode = ctypes.c_uint()
        kernel32.GetConsoleMode(handle, ctypes.byref(mode))
        # ENABLE_QUICK_EDIT_MODE = 0x0040, ENABLE_EXTENDED_FLAGS = 0x0080
        ENABLE_QUICK_EDIT_MODE = 0x0040
        ENABLE_EXTENDED_FLAGS = 0x0080
        new_mode = (
            mode.value & ~ENABLE_QUICK_EDIT_MODE
        ) | ENABLE_EXTENDED_FLAGS
        kernel32.SetConsoleMode(handle, new_mode)
    except Exception:
        pass  # Non-critical; continue even if this fails


def main():
    args = parse_args()
    config = None  # Initialize config to None

    # Disable Windows Console QuickEdit mode to prevent the script from
    # freezing when the user accidentally clicks on the console window.
    if sys.platform == "win32":
        _disable_quickedit()

    # Clear existing console
    subprocess.run("cls" if os.name == "nt" else "clear", shell=True)

    # Set up logger with file and stream handlers
    logger = setup_logger("RLC", debug=args.debug)
    logger.info("Starting RLC...")
    logger.info(f"RLC Version: {__version__}")
    logger.info(f"Working Directory: {os.getcwd()}")
    display_intro()

    logger.info(f"Input file: {args.input_file}")
    logger.debug(f"Debug mode: {args.debug}")

    # Check if input file exists
    if not os.path.isfile(args.input_file):
        logger.error(f"Input file not found: {args.input_file}")
        raise SystemExit(1)

    # Get configuration Data
    try:
        config = get_config(logger, args)
    except Exception as e:
        logger.error(f"Error getting configuration data: {e}")
        raise SystemExit(1)

    # Run the Program
    try:
        run(config, logger)
    except SystemExit as e:
        # You can customize the message based on exit code
        if config and config.get("email_on_failure"):
            notifier = get_notifier()
            notifier.error(
                f"RLC Controlled Exit - Program exited with code {e.code}"
            )
        raise
    except Exception as e:
        # This will be caught by sys.excepthook
        if config and config.get("email_on_failure"):
            notifier = get_notifier()
            notifier.error(f"RLC Exception - {str(e)}")
        raise


if __name__ == "__main__":
    main()
