# This library provides utility functions for the RLC application.
import hashlib
import json
import logging
import os
import re
import shutil
import sqlite3
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal
from functools import wraps

import numpy as np

# import platform
import win32net
from prettytable import PrettyTable
from scipy import stats

import rlc.config as cfg
import rlc.utils_core as utils_core

logger = logging.getLogger("RLC")


def hash_file(file_path):
    """
    Calculate SHA256 hash of a file.

    Args:
        file_path (str): Path to the file to hash.

    Returns:
        str: Hexadecimal hash string of the file.
    """
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


def check_period_against_dnv_min(hs, period, period_type):
    """
    Check if the provided period is higher than the DNV minimum period based on significant wave height (hs).
    Uses DNV-RP-H103 and OS-C205 recommendations for JONSWAP spectrum with gamma=5.

    Args:
        hs (float): Significant wave height in meters.
        period (float): Period to check in seconds.
        period_type (str): Type of period, either "Tp" (peak period) or "Tz" (zero-crossing period).

    Returns:
        bool: True if the period is higher than the DNV minimum, False if lower or equal.
    """
    # Calculate the minimum period based on the original function's logic
    if hs < 0.1:
        min_period = 1.0
    elif period_type == "Tp":
        # Minimum Tp based on hs
        min_period = round(11 * (hs / 9.806) ** 0.5, 0)
    elif period_type == "Tz":
        # Minimum Tz based on hs
        min_period = round(8.9 * (hs / 9.806) ** 0.5, 0)
    else:
        raise ValueError("period_type must be 'Tp' or 'Tz'")

    # Return True if provided period is lower than the minimum, False otherwise
    return period < min_period


def create_runs_folder(config):
    """
    Create a 'runs' folder in the current working directory if it doesn't exist.
    Copy the base_file to the runs folder, replacing it if it already exists.
    Copy the input file to the runs folder as a baseline if it doesn't exist.
    """
    runs_folder = os.path.join(os.getcwd(), "runs")
    os.makedirs(runs_folder, exist_ok=True)
    logger.info(f"'runs' folder ready at: {runs_folder}")

    base_file = config.get("base_file")
    if not os.path.exists(base_file):
        logger.error(f"Base file does not exist: {base_file}")
        sys.exit(1)

    base_file_name = os.path.basename(base_file)
    base_file_dest = os.path.join(runs_folder, base_file_name)

    try:
        shutil.copy2(base_file, base_file_dest)
        logger.info(f"Copied base file to: {base_file_dest}")
    except Exception as e:
        logger.error(
            f"Error copying base file to: {base_file_dest}. Error: {e}"
        )
        sys.exit(1)

    # Copy input file to runs folder as baseline if it doesn't exist
    input_file = config.get("input_file_path")
    if input_file and os.path.exists(input_file):
        input_file_name = os.path.basename(input_file)
        baseline_name = input_file_name + ".original"
        baseline_dest = os.path.join(runs_folder, baseline_name)
        if not os.path.exists(baseline_dest):
            try:
                shutil.copy2(input_file, baseline_dest)
                logger.info(f"Copied input file baseline to: {baseline_dest}")
            except Exception as e:
                logger.error(f"Error copying input file baseline: {e}")
                sys.exit(1)


def get_yml_files():
    """
    Open the rlc_results.db file, open the seed_results table and count how may cases has a "R" or a "R+" status

    Args:
        None

    Return:
        yml_files (list): List of yml files to be run
    """
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Get all cases with a "R" or "R+" status
        custom_execute(
            cursor,
            """
            SELECT hs, period, wave_dir, seed_number
            FROM seed_results
            WHERE status = 'R' OR status = 'R+'
            """,
        )
        rows = cursor.fetchall()

    yml_files = []
    for row in rows:
        hs, period, wave_dir, seed_no = row
        yml_files.append(
            utils_core.file_name_gen(hs, period, wave_dir, seed_no) + ".yml"
        )

    return yml_files


def copy_extra_files(config):
    """
    Copies the extra files specified in the configuration to the 'runs' folder.

    Args:
        config (dict):  Configuration dictionary
    """
    extra_files = config.get("extra_files")
    if extra_files:
        for file in extra_files:
            shutil.copy(file, os.path.join("runs", os.path.basename(file)))
            logger.info(f"Copied extra file to run folder: {file}")
    else:
        logger.info("No extra files specified in the configuration.")


# Function to generate all patch versions up to the given letter for a minor version
def generate_patch_versions(major_minor, end_letter):
    patches = []
    # Convert the end letter to its position in the alphabet (a=1, b=2, etc.)
    end_pos = ord(end_letter.lower()) - ord("a") + 1
    # Generate versions from 'a' up to the end letter
    for i in range(end_pos):
        patches.append(f"{major_minor}{chr(ord('a') + i)}")
    return patches


def db_status_update(
    old_status,
    new_status,
    case_results=True,
    stat_results=True,
    seed_results=True,
):
    """
    Change all files marked with a Q in the database to an R to indicate they are ready for analysis.
    Do this in all 3 tables (case_results, stat_results and seed_results)

    Args:
        old_status (str): The current status to be updated (e.g., 'Q')
        new_status (str): The new status to set (e.g., 'R')
        case_results (bool): Whether to update the case_results table
        stat_results (bool): Whether to update the stat_results table
        seed_results (bool): Whether to update the seed_results table

    Returns:
        None
    """
    # Connect to database
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        database_tables = []
        if case_results:
            database_tables.append("case_results")
        if stat_results:
            database_tables.append("stat_results")
        if seed_results:
            database_tables.append("seed_results")

        for table in database_tables:
            custom_execute(
                cursor,
                f"""
                UPDATE {table}
                SET status = '{new_status}'
                WHERE status = '{old_status}'
                """,
            )
    sync_db_to_network()


def get_list_criteria_names(config):
    """
    Get a list of all of the criteria (strings) from the config dictionary under the key analysis_criteria.
    Criteria are either:
        orcaflex_object_name_orcaflex_object_parameter_orcaflex_object_argument_mode_probability_level
        or
        orcaflex_object_name_orcaflex_object_parameter_mode_probability_level

    Args:
        criterion (dict): Dictionary containing the criterion details.

    Returns:
        list: A list of strings representing the criteria
    """
    criteria = []
    for criterion in config.get("analysis_criteria", []):
        criteria.append(criteria_to_column_name(criterion))
    return criteria


def criteria_to_column_name(criterion):
    """
    Convert a criterion dictionary to a valid SQLite column name.

    Args:
        criterion (dict): Dictionary containing the criterion details.

    Returns:
        str: Valid SQLite column name.
    """
    required_keys = [
        "orcaflex_object_name",
        "orcaflex_object_parameter",
        "probability_level",
        "mode",
    ]
    missing_keys = [key for key in required_keys if key not in criterion]
    if missing_keys:
        raise ValueError(
            f"Missing required key(s) in criterion: {', '.join(missing_keys)}"
        )

    parts = [str(criterion["orcaflex_object_name"])]

    if "orcaflex_object_argument" in criterion:
        parts.append(str(criterion["orcaflex_object_argument"]))

    parts.extend(
        [
            str(criterion["orcaflex_object_parameter"]),
            str(criterion["probability_level"]),
            str(criterion["mode"]),
        ]
    )

    return "_".join(parts).replace(" ", "_")


def construct_criterion_name_no_prob(criterion):
    """
    Construct a criterion name without the probability level.
    Format:
        object_parameter_argument_mode
        or
        object_parameter_mode
    Args:
        criterion (dict): Dictionary containing the result details.
    Returns:
        str: Constructed criterion name:
                orcaflex_object_name_orcaflex_object_parameter_mode
                or
                orcaflex_object_name_orcaflex_object_parameter_orcaflex_object_argument_mode
    """
    required_keys = [
        "orcaflex_object_name",
        "orcaflex_object_parameter",
        "mode",
    ]
    for key in required_keys:
        if key not in criterion or criterion[key] is None:
            raise ValueError(
                f"Missing or None value for key '{key}' in result: {criterion}"
            )
    parts = [
        criterion["orcaflex_object_name"],
        criterion["orcaflex_object_parameter"],
    ]
    if (
        "orcaflex_object_argument" in criterion
        and criterion["orcaflex_object_argument"] is not None
    ):
        parts.append(criterion["orcaflex_object_argument"])
    parts.append(criterion["mode"])
    return "_".join(part.replace(" ", "_") for part in parts)


def construct_criterion_name_no_prob_no_mag(criterion):
    """
    Construct a criterion name without the probability level or the mode.
    Format:
        object_parameter_argument_mode
        or
        object_parameter_mode
    Args:
        criterion (dict): Dictionary containing the result details.
    Returns:
        str: Constructed criterion name:
                orcaflex_object_name_orcaflex_object_parameter
                or
                orcaflex_object_name_orcaflex_object_parameter_orcaflex_object_argument
    """
    required_keys = ["orcaflex_object_name", "orcaflex_object_parameter"]
    for key in required_keys:
        if key not in criterion or criterion[key] is None:
            raise ValueError(
                f"Missing or None value for key '{key}' in result: {criterion}"
            )
    parts = [
        criterion["orcaflex_object_name"],
        criterion["orcaflex_object_parameter"],
    ]
    if (
        "orcaflex_object_argument" in criterion
        and criterion["orcaflex_object_argument"] is not None
    ):
        parts.append(criterion["orcaflex_object_argument"])
    return "_".join(part.replace(" ", "_") for part in parts)


def get_unique_criteria(config):
    """
    Get unique criteria from the configuration.

    Args:
        config (dict): Configuration dictionary containing criteria.

    Returns:
        list: A list of unique criteria

    """
    exclude_keys = {"probability_level", "value"}
    unique_params_set = set()
    unique_params_list = []

    for item in config.get("analysis_criteria", []):
        filtered_item = tuple(
            (k, item[k]) for k in item if k not in exclude_keys
        )
        if filtered_item not in unique_params_set:
            unique_params_set.add(filtered_item)
            unique_params_list.append(dict(filtered_item))

    return unique_params_list


def get_highest_prob_from_criterion(config, criterion: str):
    """
    Get the highest probability level from the criterion in the configuration.

    Args:
        config (dict): Configuration dictionary containing criteria.
        criterion (str): The criterion to search for.

    Returns:
        float: The highest probability level for the given criterion.
    """

    # Create a dictionary of all criterion and their associated highest probability
    # - key: Criteria Name with no probability
    # - value: probability level (highest)
    highest_probs = {}
    for crit in config.get("analysis_criteria", []):
        crit_name = construct_criterion_name_no_prob(crit)

        # Get the highest probability level for this criterion
        if crit_name not in highest_probs:
            # Add the criteria name and associated probability to the dictionary
            highest_probs[crit_name] = crit.get("probability_level")  # type: ignore
        else:
            # Update the criteria value if the value is higher.
            highest_probs[crit_name] = max(
                highest_probs[crit_name],
                crit.get("probability_level"),  # type: ignore
            )

    criterion_name = construct_criterion_name_no_prob(criterion)
    if criterion_name in highest_probs:
        return highest_probs[criterion_name]


def sync_db_to_network():
    """
    Copy the local temp database to the network path after a write commit.
    Retries on failure up to a timeout, then logs a warning and continues.
    """
    max_retries = 5
    retry_interval = 2  # seconds

    for attempt in range(max_retries):
        try:
            shutil.copy2(cfg.LOCAL_DB_PATH, cfg.DATABASE_PATH)
            if attempt > 0:
                logger.info(
                    "Successfully synced local DB to network path after %d retries.",
                    attempt,
                )
            return
        except Exception as e:
            if attempt < max_retries - 1:
                logger.debug(
                    "Sync attempt %d failed: %s. Retrying in %ds...",
                    attempt + 1,
                    e,
                    retry_interval,
                )
                time.sleep(retry_interval)
            else:
                logger.warning(
                    "Failed to sync local DB to network path after %d attempts: %s",
                    max_retries,
                    e,
                )


def retry_execute(timeout=10, retry_interval=1):
    """
    Decorator to retry cursor.execute until success or timeout.
    - timeout: Total time to keep trying (in seconds, default 10).
    - retry_interval: Time between retries (in seconds, default 1).
    - Logs a message after 5 seconds if still retrying.
    - Raises RuntimeError after timeout.
    """

    _RETRYABLE = (
        "readonly database",
        "database is locked",
        "disk i/o error",
        "unable to open database file",
    )

    def decorator(func):
        @wraps(func)
        def wrapper(cursor, *args, **kwargs):
            start_time = time.time()
            first_log_time = start_time + 5  # Log after 5 seconds
            has_logged = False

            while time.time() - start_time < timeout:
                try:
                    return func(cursor, *args, **kwargs)  # Attempt to execute
                except sqlite3.OperationalError as e:
                    if any(msg in str(e).lower() for msg in _RETRYABLE):
                        # Log after 5 seconds if not already logged
                        if time.time() >= first_log_time and not has_logged:
                            logger.info(
                                "Attempting to execute command, but database is unavailable, keep trying"
                            )
                            has_logged = True
                        time.sleep(retry_interval)  # Wait before retrying
                    else:
                        raise  # Re-raise other OperationalErrors
            # Timeout reached
            logger.error(
                "Timeout after %d seconds: database still unavailable", timeout
            )
            raise RuntimeError(
                f"Database unavailable after {timeout}s timeout"
            )

        return wrapper

    return decorator


# Custom cursor.execute with retry logic
@retry_execute(timeout=10, retry_interval=1)
def custom_execute(cursor, query, params=()):
    """Custom execute function with retry logic."""
    return cursor.execute(query, params)


def update_probabilistic_load(hs, period, wave_dir, config):
    """
    Update the probabilistic load in the database for a given hs, period, and wave_dir.

    Args:
        cursor (sqlite3.Cursor): Database cursor.
        hs (float): Significant wave height.
        period (float): Wave period.
        wave_dir (int): Wave direction.
        config (dict): Configuration dictionary containing analysis criteria.

    Returns:
        None
    """

    # Need to check to see if there is any point of calculating probabilistic values
    # If a criteria has a higher probability level so that there isn't currently enough seeds
    # run then we need to run more seeds.  For example, if a criterion needs a 99% probability level
    ## and there is only 50 seeds run, then we need to run more seeds.  No need to do any further calculations.

    # Get number of seeds run from this case from case_results in the database
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()
        custom_execute(
            cursor,
            """
            SELECT no_seeds, status
            FROM case_results
            WHERE hs = ? AND period = ?
            """,
            (hs, period),
        )
        # Get no_seeds value and status from database
        row = cursor.fetchone()
        case_no_seeds_run = row[0]
        case_status = row[1]

        # If the case is already marked as NG (e.g. due to failed seeds after
        # max bisections), there is no point requesting more seeds or computing
        # probabilistic loads — the case is done.
        if case_status == "NG":
            logger.info(
                f"Case hs={hs}, period={period} is already NG. "
                f"Skipping probabilistic load update."
            )
            return

        unique_criteria = get_unique_criteria(config)

        more_seeds_needed = False
        seeds_needed = config.get("min_seeds")
        for criterion in unique_criteria:
            # Get the highest probability level associated with this criterion
            # Get min seeds required for this probability level
            min_seeds_for_criteria = int(
                round(
                    1
                    / (1 - get_highest_prob_from_criterion(config, criterion)),
                    0,
                )
            )  # type: ignore
            criterion_table_name = construct_criterion_name_no_prob(criterion)

            custom_execute(
                cursor,
                f"""
                SELECT status
                FROM {criterion_table_name}_results
                WHERE hs = ? AND period = ?
                """,
                (hs, period),
            )

            # List of the status for all 3 wave directions.
            case_status = [row[0] for row in cursor.fetchall()]
            if (
                case_no_seeds_run < min_seeds_for_criteria
                and "FF" in case_status
            ):
                more_seeds_needed = True
                if min_seeds_for_criteria > seeds_needed:
                    seeds_needed = min_seeds_for_criteria
                break

        # If more seeds needed update status from A to N+ for that specific hs and period (for all combinations)
        if more_seeds_needed:
            logger.info("More seeds are needed for this case.")
            # In the seed_results table, find the cases for this hs/period where the status is "-" and change to N
            # This would cover the remaining files needed for extra seeds
            custom_execute(
                cursor,
                """
                UPDATE seed_results
                SET status = 'N'
                WHERE hs = ? AND period = ? AND status = "-"
                """,
                (hs, period),
            )

            tables = ["case_results", "stat_results"]
            for table in tables:
                custom_execute(
                    cursor,
                    f"""
                    UPDATE {table}
                    SET status = 'N+', no_seeds = {seeds_needed}
                    WHERE hs = ? AND period = ? AND status != 'NG'
                    """,
                    (hs, period),
                )

            sync_db_to_network()
            return
        else:
            # Sufficient seeds exist for empirical if gumbel doesn't fit
            # See if fit passed (PF)
            criteria = config.get("analysis_criteria", [])
            for criterion in criteria:
                column_name = criteria_to_column_name(criterion)
                criterion_table_name = construct_criterion_name_no_prob(
                    criterion
                )
                custom_execute(
                    cursor,
                    f"""
                    SELECT status, gumbel_mu, gumbel_beta
                    FROM {criterion_table_name}_results
                    WHERE hs = ? AND period = ? AND wave_dir = ?
                    """,
                    (hs, period, wave_dir),
                )

                status, gumbel_mu, gumbel_beta = cursor.fetchone()
                probability_level = criterion.get("probability_level")

                if status == "PF":
                    # Criteria Passed, Use Gumbel parameters to determine value
                    if criterion.get("mode") == "max":
                        # Need to use the gumbel right
                        prob_value = stats.gumbel_r.ppf(
                            probability_level, gumbel_mu, gumbel_beta
                        )
                    if criterion.get("mode") == "min":
                        # Need to use the gumbel left
                        prob_value = stats.gumbel_l.ppf(
                            1 - probability_level, gumbel_mu, gumbel_beta
                        )

                    # logger.debug(f"Writing gumbel {prob_value} to {column_name}")  # type: ignore

                elif status == "FF":
                    # Criteria Failed, Use empirical parameters to determine value
                    # Get values from seed_results table in rlc_results.db

                    custom_execute(
                        cursor,
                        f'''
                        SELECT "{criterion_table_name}"
                        FROM seed_results
                        WHERE hs = ? AND period = ? AND wave_dir = ?
                        ''',
                        (hs, period, wave_dir),
                    )

                    result_values = [row[0] for row in cursor.fetchall()]
                    result_values = [x for x in result_values if x is not None]

                    # Get empirical probabilistic value with bootstrapping
                    prob_value, _ = bootstrap_percentile(
                        result_values,
                        percentile=probability_level * 100,
                        mode=criterion.get("mode"),
                    )

                    # Write probability value in correct column in stat_results
                    # Get column name
                    # logger.debug(f"Writing empirical {prob_value} to {column_name}")  # type: ignore
                    # Write value to database

                # Write value to database
                custom_execute(
                    cursor,
                    f"""
                    UPDATE stat_results
                    SET "{column_name}" = ?
                    WHERE hs = ? AND period = ? AND wave_dir = ?
                    """,
                    (prob_value, hs, period, wave_dir),  # type: ignore
                )
        return


def bootstrap_percentile(
    data,
    percentile=90,
    mode="max",
    confidence_level=95,
    n_bootstraps=10000,
    random_seed=None,
):
    """
    Calculate the specified percentile of a dataset using bootstrapping,
    returning the upper or lower confidence interval bound based on mode.

    Args:
        data: List or numpy array of numbers (any size).
        percentile: The percentile to calculate (e.g., 90 for 90th percentile in max case).
        mode: "max" for percentile (upper CI) or "min" for (100-percentile) (lower CI).
        confidence_level: Confidence level for the interval (e.g., 95 for 95% CI).
        n_bootstraps: Number of bootstrap samples (minimum 2000 recommended).
        random_seed: Seed for reproducibility (optional).

    Returns:
        float: Estimated percentile value (upper CI for max, lower CI for min).
        list: List of bootstrapped percentile values for further analysis.
    """
    if mode not in ["max", "min"]:
        raise ValueError("mode must be 'max' or 'min'")
    if not 0 < percentile < 100:
        raise ValueError("percentile must be between 0 and 100")
    if not 0 < confidence_level < 100:
        raise ValueError("confidence_level must be between 0 and 100")
    if n_bootstraps < 1000:
        print(
            f"Warning: n_bootstraps={n_bootstraps} is below recommended minimum of 1000. Results may be less reliable."
        )
    if data == []:
        raise ValueError("Input data cannot be empty")

    # Set random seed for reproducibility
    if random_seed is not None:
        np.random.seed(random_seed)

    # Convert data to numpy array for efficiency
    data = np.asarray(data, dtype=float).ravel()
    n = len(data)

    # Determine percentile based on mode
    target_percentile = percentile if mode == "max" else 100 - percentile

    # Calculate confidence interval bounds
    lower_bound = (100 - confidence_level) / 2
    upper_bound = 100 - lower_bound

    # Perform vectorized bootstrapping
    bootstrap_indices = np.random.randint(0, n, size=(n_bootstraps, n))
    bootstrap_samples = data[bootstrap_indices]
    bootstrap_percentiles = np.percentile(
        bootstrap_samples, target_percentile, axis=1
    )

    # Select the appropriate confidence interval bound
    if mode == "max":
        final_percentile = np.percentile(
            bootstrap_percentiles, upper_bound
        )  # Upper CI
    else:  # mode == "min"
        final_percentile = np.percentile(
            bootstrap_percentiles, lower_bound
        )  # Lower CI

    return final_percentile, bootstrap_percentiles


def next_hs(config):
    """
    Looks at the database and determines the status of each case.  If the case has a status of NG, the
    script reduces the Hs by the hs_course_step parameter.  If the case has a status of OK, it sees if it can increase
    the hs by hs_fine_step.

    Args:
        config (dict): Configuration dictionary containing analysis criteria.

    Return:
    None
    """
    hs_course_step = Decimal(str(config.get("hs_course_step")))
    hs_fine_step = Decimal(str(config.get("hs_fine_step")))
    hs_start = Decimal(str(config.get("hs_start")))
    hs_min = Decimal(str(config.get("hs_min")))
    min_seeds = Decimal(str(config.get("min_seeds")))
    wave_dirs = config.get("wave_dirs")

    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Consider cases that are NG, look to reduce
        custom_execute(
            cursor,
            """
            SELECT period, MIN(hs) as min_hs
            FROM case_results
            WHERE status = 'NG'
            GROUP BY period
            """,
        )
        rows = cursor.fetchall()

        if rows:
            for period, min_hs in rows:
                target_hs = Decimal(str(min_hs)) - hs_course_step
                # Floor the target at hs_min so it is always considered
                if target_hs < hs_min:
                    target_hs = hs_min
                custom_execute(
                    cursor,
                    """
                    UPDATE case_results
                    SET status = 'N'
                    WHERE period = ? AND hs = ? AND status = '-'
                """,
                    (period, str(float(target_hs))),
                )

        # Consider cases that are OK, look to increase by hs_fine_step
        custom_execute(
            cursor,
            """
            SELECT period, MAX(hs) as max_hs
            FROM case_results
            WHERE status = 'OK'
            GROUP BY period
            """,
        )
        rows = cursor.fetchall()

        if rows:
            for period, max_hs in rows:
                if max_hs != hs_start:
                    target_hs = float(Decimal(str(max_hs)) + hs_fine_step)
                    custom_execute(
                        cursor,
                        """
                        UPDATE case_results
                        SET status = 'N'
                        WHERE period = ? AND hs = ? AND status = '-'
                    """,
                        (period, str(target_hs)),
                    )

        # Now need to set the status of the stat_results and seed_results tables
        # Get a list of cases in case_results table that have a "N" value
        custom_execute(
            cursor,
            """
            SELECT period, hs
            FROM case_results
            WHERE status = 'N'
            """,
        )

        rows = cursor.fetchall()
        if rows:
            for period, hs in rows:
                for wave_dir in wave_dirs:
                    custom_execute(
                        cursor,
                        """
                        UPDATE stat_results
                        SET status = 'N'
                        WHERE period = ? AND hs = ? AND wave_dir = ?
                        """,
                        (period, hs, wave_dir),
                    )
                    custom_execute(
                        cursor,
                        f"""
                        UPDATE seed_results
                        SET status = 'N'
                        WHERE period = ? AND hs = ? AND wave_dir = ? AND seed_number <= {min_seeds}
                        """,
                        (period, hs, wave_dir),
                    )
    sync_db_to_network()


def get_current_results_table_from_db():
    """
    Retrieves the current results table from the database.

    Returns:
        lst: A list of strings for each row of the table
    """

    # Connect to the database
    with sqlite3.connect(
        cfg.LOCAL_DB_PATH
    ) as conn:  # Replace with your actual database path
        cursor = conn.cursor()

        # Query hs, period, status
        cursor.execute("SELECT hs, period, status FROM case_results")
        rows = cursor.fetchall()

        # Organize data into a nested dictionary: hs -> period -> status
        data = defaultdict(dict)
        hs_set = set()
        period_set = set()

        for hs, period, status in rows:
            data[hs][period] = status
            hs_set.add(hs)
            period_set.add(period)

        # Sort hs and period values
        hs_list = sorted(hs_set)
        period_list = sorted(period_set)

        # Pretty table for log file output
        # Create PrettyTable
        table = PrettyTable()
        table.field_names = ["hs"] + period_list

        for hs in hs_list:
            row = [hs]
            for period in period_list:
                row.append(data[hs].get(period, " "))
            table.add_row(row)

        # HTML Table for Email
        # First table: hs vs period status
        html = [
            '<table border="1" style="border-collapse: collapse; margin: auto; text-align: center;">',
            '<thead><tr><th style="padding: 4px;">Hs [m] / T [s]</th>'
            + "".join(
                f'<th style="padding: 4px; min-width: 60px;">{period}</th>'
                for period in period_list
            )
            + "</tr></thead>",
            "<tbody>",
        ]

        for hs in hs_list:
            row_html = (
                f'<tr><td style="padding: 4px; font-weight: bold;">{hs}</td>'
            )
            for period in period_list:
                status = data[hs].get(period, "")
                row_html += f'<td style="padding: 4px;">{status}</td>'
            row_html += "</tr>"
            html.append(row_html)

        html.append("</tbody></table>")

        # Second table: status definitions
        definitions = {
            "X": "Never run this case (outside of period limit)",
            "-": "May be run in the future",
            "N": "Next up, YML File Needed",
            "Y": "YML File Created",
            "Q": "Queued for Analysis",
            "R": "Running",
            "A": "Assessing Results",
            "N+": "Next Up, YML File Needed for more seeds",
            "Y+": "YML File Created for more seeds",
            "Q+": "Queued for Analysis for more seeds",
            "R+": "Running for more seeds",
            "A+": "Assessing Results for more seeds",
            "OK": "Case passes all acceptance criteria",
            "NG": "Case fails one or more acceptance criteria",
            "F": "Case has failed runs",
        }

        html.append(
            '<br><table border="1" style="border-collapse: collapse; margin: auto; text-align: left;">'
        )
        html.append(
            '<thead><tr><th style="padding: 4px;">Status</th><th style="padding: 4px;">Definition</th></tr></thead>'
        )
        html.append("<tbody>")

        for code, description in definitions.items():
            html.append(
                f'<tr><td style="padding: 4px;">{code}</td><td style="padding: 4px;">{description}</td></tr>'
            )

        html.append("</tbody></table>")

        # Final HTML string
        html_table = "\n".join(html)

    return table.get_string(), html_table


def seed_results_update(hs, t, wave_dir, seed, status):
    """
    Update the status of a specific seed in the seed_results table.

    Parameters:
        hs (float): Significant wave height.
        t (float): Wave period.
        wave_dir (float): Wave direction.
        seed (int): Seed number.
        status (str): New status value.
        db_path (str): Path to the SQLite database (default: rlc_results.db).
    """
    try:
        with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
            cursor = conn.cursor()

            sql = """
            UPDATE seed_results
            SET status = ?
            WHERE hs = ? AND period = ? AND wave_dir = ? AND seed_number = ?
            """

            custom_execute(cursor, sql, (status, hs, t, wave_dir, seed))
        sync_db_to_network()
    except sqlite3.Error as e:
        print(f"Database error: {e}")


def stat_results_update(hs, t, wave_dir, status):
    """
    Update the status of a specific (hs, period, wave_dir) row in the stat_results table.

    Parameters:
        hs (float): Significant wave height.
        t (float): Wave period.
        wave_dir (float): Wave direction.
        status (str): New status value for the stat_results row.
        db_path (str): Path to the SQLite database (default: rlc_results.db).

    Returns:
        bool: True if a row was updated; False if no matching row was found or on error.
    """
    try:
        with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
            cursor = conn.cursor()

            sql = """
            UPDATE stat_results
            SET status = ?
            WHERE hs = ? AND period = ? AND wave_dir = ?
            """

            custom_execute(cursor, sql, (status, hs, t, wave_dir))
        sync_db_to_network()
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        sys.exit(1)


def case_results_update(hs, t, status):
    """
    Update the status of a specific (hs, period) row in the case_results table.

    Parameters:
        hs (float): Significant wave height.
        t (float): Wave period.
        status (str): New status value for the case_results row.
        db_path (str): Path to the SQLite database (default: rlc_results.db).

    Returns:
        bool: True if a row was updated; False if no matching row was found or on error.
    """
    try:
        with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
            cursor = conn.cursor()

            sql = """
            UPDATE case_results
            SET status = ?
            WHERE hs = ? AND period = ?
            """

            custom_execute(cursor, sql, (status, hs, t))
        sync_db_to_network()
    except sqlite3.Error as e:
        print(f"Database error: {e}")
        sys.exit(1)


def extract_values_from_filename(filename, logger):
    # Define the pattern to match Hs, T, WD, and seed values
    pattern = r"Hs(\d+\.\d{2})_T(\d+\.\d{2})_WD(\d+)_seed(\d+)\.yml"

    # Use re.search to find matches
    match = re.search(pattern, filename)

    if match:
        hs = float(match.group(1))  # Extract Hs value
        t = float(match.group(2))  # Extract T value
        wave_dir = int(match.group(3))  # Extract WD value
        seed = int(match.group(4))  # Extract seed value
        return {"hs": hs, "t": t, "wave_dir": wave_dir, "seed": seed}
    else:
        logger.error(f"Failed to extract values from filename: {filename}")
        sys.exit(1)
        sys.exit(1)


def get_unc_path(logger):
    """
    Returns the UNC path of the current working folder on a mapped network drive.
    If running on a local drive (e.g., C:\, D:\, etc.), returns the local path as-is.
    If the path is already a UNC path, returns it unchanged.
    """
    try:
        current_path = os.getcwd()

        # If it's already a UNC path, just return it
        if current_path.startswith("\\\\"):
            return current_path

        # Extract the drive (e.g., 'X:') from the path
        drive, _ = os.path.splitdrive(current_path)

        # Try to get network/mapping info for the drive.
        # If this fails, it's a local drive — return the path as-is.
        try:
            net_info = win32net.NetUseGetInfo("", drive)
        except Exception:
            return current_path

        # If we have mapping info, build the UNC path
        share_path = net_info.get("remote")
        if not share_path:
            # No remote share: treat as local
            return current_path

        # Construct UNC using the share root + relative path
        relative_path = current_path[len(drive) :]  # keep leading backslash
        full_unc_path = (
            share_path.rstrip("\\") + "\\" + relative_path.lstrip("\\")
        )

        return full_unc_path.replace("/", "\\")
    except Exception as e:
        logger.error(f"Error converting to UNC path: {e}")
        sys.exit(1)


def write_failed_json(base_name, bisection, reason=None, retry_bisection=None):
    """
    Writes a _failed.json marker file to indicate that a run has failed.

    Args:
        base_name (str): Base filename (e.g. 'Hs1.50_T08.00_WD180_seed1')
        bisection (int): The bisection number at which the failure occurred.
        reason (str, optional): Description of the failure reason.
        retry_bisection (int, optional): If set, indicates that bisect.main()
            has already prepared the YAML with a halved timestep for this
            bisection attempt.  create_txt_package() uses this to decide
            whether the file should be re-run or skipped on restart.
    """
    failed_path = os.path.join("runs", base_name + "_failed.json")
    payload = {
        "bisection": bisection,
        "reason": reason,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    if retry_bisection is not None:
        payload["retry_bisection"] = retry_bisection
    with open(failed_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def delete_failed_json(base_name):
    """
    Deletes a _failed.json marker file if it exists.

    Args:
        base_name (str): Base filename (e.g. 'Hs1.50_T08.00_WD180_seed1')

    Returns:
        bool: True if deleted, False otherwise.
    """
    failed_path = os.path.join("runs", base_name + "_failed.json")
    try:
        os.remove(failed_path)
        return True
    except FileNotFoundError:
        return False


def create_txt_package(config, logger):
    """
    Creates a text file of files to run.

    The text file contains:
     - list of all yaml files for the current step (files listed as Q in db)

     Args:
        config (dict): Configuration dictionary

    Returns:
        str: The name of the text file created.
    """
    logger.info("Creating text file of files to run...")

    txt_file = "submit.txt"

    yml_files = []
    # Open sql database and get a list of files that are required to be run
    # in the current step.
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Retrieve cases with status 'Q' or 'Q+'
        # Also need to retrieve cases that have a 'Fi' status where
        # i <= max_bisections
        max_bisections = config.get("max_bisections")
        statuses = ["Q", "Q+", "F"] + [
            f"F{i}" for i in range(max_bisections + 1)
        ]
        placeholders = ",".join("?" for _ in statuses)

        sql = f"""
        SELECT rowid, hs, period, wave_dir, seed_number, seed_value
        FROM seed_results
        WHERE status IN ({placeholders})
        """

        custom_execute(cursor, sql, statuses)

        rows = cursor.fetchall()

    for row in rows:
        rowid, hs, period, wave_dir, seed_number, seed_value = row

        # Create a YAML file for each case
        base_name = utils_core.file_name_gen(hs, period, wave_dir, seed_number)
        yml_name = base_name + ".yml"
        json_name = base_name + "_results.json"

        # Check to see if results json file exists — no need to re-run.
        # Also check for a _failed.json marker:
        #   - If it contains "retry_bisection", bisect.main() already
        #     prepared the YAML with a halved timestep → allow re-run
        #     and delete the stale marker.
        #   - If it does NOT contain "retry_bisection", the failure
        #     has not been followed by a bisection → skip on restart
        #     and mark the seed/stat/case as failed in the database.
        failed_path = os.path.join("runs", base_name + "_failed.json")
        if os.path.isfile(os.path.join("runs", json_name)):
            continue
        if os.path.isfile(failed_path):
            try:
                with open(failed_path, "r", encoding="utf-8") as f:
                    failed_data = json.load(f)
            except Exception:
                failed_data = {}
            if "retry_bisection" in failed_data:
                # Bisection prepared a new attempt — delete marker, allow re-run
                delete_failed_json(base_name)
            else:
                # No retry prepared — mark as permanently failed in the database
                # so downstream code (store_results, run_stats) skips this seed.
                bisection = failed_data.get("bisection", 0)
                seed_results_update(hs, period, wave_dir, seed_number, "F")
                stat_results_update(hs, period, wave_dir, "NG")
                case_results_update(hs, period, "NG")
                logger.info(
                    f"Skipping {base_name} — previous failure at bisection "
                    f"{bisection} (no retry prepared)"
                )
                continue
        yml_files.append(yml_name)

    if len(yml_files) == 0:
        logger.info(
            "JSON files already exist for all cases, no need to run YML files."
        )
        return None, []

    # Write the YML files to the text file
    with open("runs/" + txt_file, "w") as f:
        for yml_file in yml_files:
            f.write(yml_file + "\n")

    # Add UNC path to all yml files in list using get_unc_path_cwd
    yml_files = [
        get_unc_path(logger) + "\\runs\\" + yml_file for yml_file in yml_files
    ]

    return txt_file, yml_files
