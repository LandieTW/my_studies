import math
import os
from math import isclose, isnan
from numbers import Real

import OrcFxAPI


def generate_yml_file(
    config,
    hs,
    period,
    wd,
    seed_number,
    seed,
):
    """
    Generate a YML file with the provided parameters.

    """
    # Get parameters from configuration
    period_type = config.get("period_type")
    jonswap_gamma = config.get("jonswap_gamma")
    base_file = config.get("base_file")
    calculate_jonswap_gamma = config.get("calculate_jonswap_gamma")
    calculate_jonswap_gamma_method = config.get(
        "calculate_jonswap_gamma_method"
    )

    filename = os.path.join(
        "runs", file_name_gen(hs, period, wd, seed_number) + ".yml"
    )
    if os.path.exists(filename):
        return 0

    # Calculate Gamma
    if calculate_jonswap_gamma:
        if calculate_jonswap_gamma_method == "dnv":
            # Use the DNV-RP-H103 method for calculating gamma
            # This works for only Tp which is checked when input file is checked
            gamma = jonswap_gamma_DNVH103(hs, period)
        elif calculate_jonswap_gamma_method == "of":
            # Use the OrcaFlex method to calculate gamma (Isherwood)
            # This only works for period_type Tz which is checked when input file is checked
            gamma = jonswap_gamma_of(hs, period)
        elif calculate_jonswap_gamma_method == "pb":
            # Use the Petrobras method to calculate gamma
            # This only works for period_type Tp which is checked when input file is checked
            gamma = jonswap_gamma_petrobras(period)

    else:
        gamma = jonswap_gamma

    with open(filename, "w") as f:
        # Base file is located in the runs folder.
        f.write("BaseFile: %s\n" % base_file)
        f.write("General:\n")
        f.write("  Comments: " + period_type + "\n")
        f.write("Environment:\n")
        f.write("  WaveDirection: %d\n" % wd)
        f.write("  WaveHs: %.2f\n" % hs)
        f.write("  WaveJONSWAPParameters: Partially specified\n")
        f.write("  WaveGamma: %.4f\n" % gamma)
        if hs != 0:
            if period_type == "Tp":
                f.write("  WaveTp: %.2f\n" % period)
            else:
                f.write("  WaveTz: %.2f\n" % period)
            f.write("  WaveSeed: %d\n" % seed)
    return 0


def jonswap_gamma_petrobras(period):
    """
    Special function required by Petrobras for calculating gamma.
    gamma = 6.4 * Tp ^ -0.491
    """

    return 6.4 * period**-0.491


def jonswap_gamma_DNVH103(hs, period):
    """JONSWAP gamma as per DNV-H103"""
    if hs == 0:
        # Catches case when hs = 0.  Gamma doesn't matter so return 1
        return 1
    else:
        if hs < 0.1:
            return 1.0
        alpha = period / math.sqrt(hs)
        if alpha >= 3.6 and alpha <= 5.0:
            return math.exp(5.75 - 1.15 * alpha)
        if alpha < 3.6:
            return 5.0
        if alpha > 5.0:
            return 1.0


def jonswap_gamma_of(hs, period):
    """ "
    Below is based on 'Technical Note: A revised parameterisation of the
    Jonswap spectrum.
    R.M. Isherwood, Applied Ocean Research, 1989, Vol. 9, No. 1
    """
    if hs == 0:
        # Catches case when hs = 0.  Gamma doesn't matter so return 1
        return 1
    else:
        steepness = 2 * math.pi * hs / (9.806 * period**2)

        if steepness >= 0.037:
            return (
                10.54
                - 1.34 * steepness**-0.5
                - math.exp(-19 + 3.775 * steepness**-0.5)
            )
        else:
            return 0.9 + math.exp(18.86 - 3.67 * steepness**-0.5)


def file_name_gen(hs, period, wd, seed_number):
    """pattern used to create YML files and read results TXT files"""
    return "Hs%.2f_T%05.2f_WD%d_seed%d" % (hs, period, wd, seed_number)


def zero_wave_analysis(config, logger):
    """
    Performs the analysis assuming a zero wave height.  Multiple seeds are not required.

    Args:
        config (dict):
    """

    logger.info("Generating zero wave case file ...")
    generate_yml_file(config, 0, 8, 180, 1, 1)

    zero_wave_file = "Hs0.00_T08.00_WD180_seed1.yml"

    # Run it
    if os.path.exists("runs\\" + zero_wave_file.rsplit(".", 1)[0] + ".json"):
        pass
        # logger.info("Zero wave case already run.")
    else:
        os.chdir("runs")  # folder 'runs' is created in pre

        # Load the YAML model
        logger.info("Loading the zero wave case ...")
        model = OrcFxAPI.Model(zero_wave_file)

        # Run the simulation
        logger.info("Running the zero wave case ...")
        model.RunSimulation()
        logger.info("Running Post Calc Actions for the zero wave case ...")
        model.ExecutePostCalculationActions(
            zero_wave_file.rsplit(".", 1)[0] + ".sim",
            actionType=False,  # type: ignore
        )

        os.chdir("..")  # folder 'runs' is created in pre


def progress_bar(percent_complete):
    width = 40
    filled_length = int(round(width * percent_complete))
    bar = "#" * filled_length + "-" * (width - filled_length)
    percent_display = int(percent_complete * 100)
    return f"[{bar}] {percent_display}%"


def contains_all_zeros(
    seq,
    *,
    abs_tol: float = 1e-12,
    treat_nan_as_zero: bool = False,
    empty_is_zero: bool = False,
) -> bool:
    """
    Return True if every element in `seq` is zero or 'essentially zero'.

    Parameters
    ----------
    seq : iterable
        Collection of items to test.
    abs_tol : float, optional (default=1e-12)
        Absolute tolerance for floating-point comparisons.
        Uses math.isclose(x, 0.0, rel_tol=0.0, abs_tol=abs_tol).
    treat_nan_as_zero : bool, optional (default=False)
        If True, NaN values are treated as zero; otherwise any NaN makes the result False.
    empty_is_zero : bool, optional (default=False)
        If True, an empty sequence returns True (vacuous truth); else False.

    Notes
    -----
    - Only real numeric values are considered. Non-numeric types (e.g., str, None, bool)
      will cause the function to return False.
    - bool is a subclass of int in Python; we explicitly exclude it to avoid
      treating True/False as 1/0.
    """
    seen_any = False

    for x in seq:
        seen_any = True

        # Reject non-real numbers (including bool, complex, strings, None, etc.)
        if isinstance(x, bool) or not isinstance(x, Real):
            return False

        # Handle NaN explicitly for float
        if isinstance(x, float) and isnan(x):
            if not treat_nan_as_zero:
                return False
            else:
                continue  # treat NaN as zero and continue

        # Check zero-ness with absolute tolerance only
        if not isclose(x, 0.0, rel_tol=0.0, abs_tol=abs_tol):
            return False

    # Empty input handling
    if not seen_any:
        return bool(empty_is_zero)

    return True
