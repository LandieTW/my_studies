import datetime
import glob
import json
import logging
import multiprocessing as mp
import os
import sqlite3
import time
import zipfile

# import socket
import requests
from hpcflex import Job

import rlc.config as cfg
import rlc.utils as utils
import rlc.utils_core as utils_core

logger = logging.getLogger("RLC")


def check_task_status(job):
    n = len(job.get_load_cases())  # number of tasks in HPC-Flex job
    n_failed = 0
    n_queued = 0
    n_active = 0
    n_running = 0
    n_completed = 0
    for i in range(n):
        if (
            job.loadCases[i]["status"] == "failed"
        ):  # this is status of each task
            n_failed += 1
        elif job.loadCases[i]["status"] == "queued":
            n_queued += 1
        elif job.loadCases[i]["status"] == "active":
            n_active += 1
        elif job.loadCases[i]["status"] == "running":
            n_running += 1
        elif job.loadCases[i]["status"] == "completed":
            n_completed += 1

    logger.info(
        "HPC Job Status: %s [Failed = %d, Queued = %d, Active = %d, Running = %d, Completed = %d]"
        % (job.status, n_failed, n_queued, n_active, n_running, n_completed)
    )

    return n_failed, n_queued, n_active, n_running, n_completed


def is_connected():
    """
    Checks to see if the internet is active

    Return:
        boolean
    """
    try:
        requests.head("http://www.google.com")
        logger.info("Internet is active...")
        return True
    except Exception:
        return False


def create_zip_package(config):
    """
    Creates a zip file to send to HPC-Flex job.

    The zip file contains:
     - base model in the runs directory
     - all yaml files for the current step (files listed as Q in db)
     - any Python script found in the `runs` directory.

     Args:
        config (dict): Configuration dictionary

    Returns:
        str: The name of the zip file created.
    """

    hpc_zip_file = "runs/hpc_files.zip"

    # Get data from configuration
    base_file = config["base_file"]
    extra_files = config["extra_files"]

    # Open sql database and get a list of files that are required to be run
    # in the current step.
    with sqlite3.connect(cfg.LOCAL_DB_PATH) as conn:
        cursor = conn.cursor()

        # Query all rows from the case_results table
        utils.custom_execute(
            cursor, "SELECT hs, period, status, no_seeds FROM case_results"
        )
        rows = cursor.fetchall()

        # Create the dictionary
        results_dict = {}
        for hs, period, status, no_seeds in rows:
            results_dict[(hs, period)] = {
                "status": status,
                "no_seeds": no_seeds,
            }

        # Create a temporary dictionary of cases to see how many YML files need to be submitted
        for row in cursor.fetchall():
            rowid, hs, period, no_seeds = row

        yml_files = []
        # Retrieve cases with status 'Q', 'Q+', or bisection-failed 'F{i}'
        max_bisections = config.get("max_bisections", 0)
        statuses = ["Q", "Q+", "F"] + [
            f"F{i}" for i in range(max_bisections + 1)
        ]
        placeholders = ",".join("?" for _ in statuses)
        utils.custom_execute(
            cursor,
            f"""
            SELECT rowid, hs, period, wave_dir, seed_number, seed_value
            FROM seed_results
            WHERE status IN ({placeholders})
            """,
            statuses,
        )

    for row in cursor.fetchall():
        rowid, hs, period, wave_dir, seed_number, seed_value = row

        # Only submit cases where seed number is less than or equal to no_seeds
        if seed_number <= results_dict[(hs, period)]["no_seeds"]:
            # Create a YAML file for each case
            base_name = utils_core.file_name_gen(
                hs, period, wave_dir, seed_number
            )
            yml_name = base_name + ".yml"
            json_name = base_name + "_results.json"

            # Check to see if results json file exists — no need to re-run.
            # Also check for a _failed.json marker:
            #   - If it contains "retry_bisection", bisect.main() already
            #     prepared the YAML with a halved timestep → allow re-run.
            #   - If it does NOT contain "retry_bisection", the failure
            #     has not been followed by a bisection → skip on restart
            #     and mark the seed/stat/case as failed in the database.
            failed_path = os.path.join("runs", base_name + "_failed.json")
            if os.path.isfile(os.path.join("runs", json_name)):
                continue
            if os.path.isfile(failed_path):
                try:
                    with open(failed_path, "r", encoding="utf-8") as f:
                        failed_data = json.load(f)
                except Exception:
                    failed_data = {}
                if "retry_bisection" in failed_data:
                    # Bisection prepared a new attempt — delete marker, allow re-run
                    utils.delete_failed_json(base_name)
                else:
                    # No retry prepared — mark as permanently failed in the database
                    bisection = failed_data.get("bisection", 0)
                    utils.seed_results_update(
                        hs, period, wave_dir, seed_number, "F"
                    )
                    utils.stat_results_update(hs, period, wave_dir, "NG")
                    utils.case_results_update(hs, period, "NG")
                    logger.info(
                        f"Skipping {base_name} — previous failure at bisection "
                        f"{bisection} (no retry prepared)"
                    )
                    continue
            yml_files.append("runs/" + yml_name)

    if len(yml_files) == 0:
        logger.info(
            "JSON files already exist for all cases, no need to run YML files."
        )
        return None, yml_files

    py_files = glob.glob("runs/*.py")

    files = (
        [os.path.join("runs", base_file)] + yml_files + py_files + extra_files
    )

    with zipfile.ZipFile(hpc_zip_file, "w", zipfile.ZIP_DEFLATED) as zipf:
        for file in files:
            arcname = os.path.basename(file)  # Strip folder path
            zipf.write(file, arcname=arcname)

    return hpc_zip_file, yml_files


def retry_upload(model_file_name, fname_missing, job):
    # get the list of files in the storage
    uploaded_files = job.get_file_names("input")
    # fname_uploaded = 'uploaded_files.txt'

    uploaded_files_list = []
    with open("retrieved_files.txt", "w") as list_file:
        for item in uploaded_files:
            list_file.write(str(item) + "\n")
            uploaded_files_list.append(item)

    # get required files to upload
    with open(fname_missing, "r") as f:
        yml_list = [line.strip() for line in f.readlines()]
    pys = glob.glob("*.py")

    files_list = [model_file_name]
    files_list.extend(yml_list)
    files_list.extend(pys)
    # files_list = [x for x in files_list if x != '']

    # compared uploaded vs. required to be uploaded
    miss_uploaded = []
    for item in files_list:
        if item not in uploaded_files_list:
            miss_uploaded.append(item)

    return miss_uploaded


def write_new_missing(fname_missing, new_files, new_fname_missing):
    # delete any previous missing.txt
    if os.path.isfile(new_fname_missing):
        os.remove(new_fname_missing)
    # print missing files to missing.txt if set not empty

    if new_files:
        with open(new_fname_missing, "w") as g:
            for line in new_files:
                g.write("%s\n" % line)
        return True
    return False


def get_unstable(yml_files):
    """
    Get a list of yml files that must have failed (as there is no *.json file
    when there should be.

    Args:
        yml_files (list): List of YML files run in this job

    Return:
        unstable (list): List of yml files that must have failed
    """
    unstable = []
    for yml_file in yml_files:
        json_file = yml_file.replace(".yml", "_results.json")
        if not os.path.isfile(json_file):
            unstable.append(yml_file)
    return unstable


def main(config, console_manager):
    logger.info("Creating HPC-Flex interface.")
    job = Job()

    hpc_job_id = "hpcflex_jobid"
    if os.path.exists(hpc_job_id):
        # a previously existing job id file is found, ie, script didn't finish
        # properly last time. --> load that job id.
        with open(hpc_job_id, "r") as f:
            job_id = f.read().strip()
        job.load(job_id)
        logger.info("HPC-Flex job loaded")
        yml_files = list(job.get_file_names(usage="temp", pattern="*.yml"))
    else:
        # Create zip file and upload it to HPC
        zip_fname, yml_files = create_zip_package(config)

        if zip_fname is None:
            logger.info("No YML files to run, exiting HPC-Flex submission.")
            # Exit the HPC-Flex submission
            utils.db_status_update(old_status="Q", new_status="R")
            utils.db_status_update(old_status="Q+", new_status="R+")
            console_manager.update_from_database()
            return [], []

        # no job id file, create a new job from scratch.
        job.create(
            name="rlc job " + datetime.datetime.now().strftime("%H:%M"),
            application="Orcaflex",
            application_version=config.get("orcaflex_version"),
            high_priority=False,
            linked_job_id=None,  # type: ignore
        )
        job.save()

        logger.info("HPC-Flex job created")
        job_id = job.id  # type: ignore
        with open(hpc_job_id, "w") as f:
            f.write("{}".format(job_id))
        # ... zip, prepare, execute job as normally

        logger.info("Uploading zip file")
        job.upload_file("input", zip_fname)

        logger.info("Input files uploaded to HPC-Flex")

        # not sure this is needed
        job.prepare()

        job.execute()
        logger.info("HPC-Flex job submitted")

    # Update file status in the database
    utils.db_status_update(old_status="Q", new_status="R")
    utils.db_status_update(old_status="Q+", new_status="R+")

    console_manager.update_from_database()

    n_failed, n_queued, n_active, n_running, n_completed = check_task_status(
        job
    )

    # Wait for the Job completion in HPC-Flex
    retry_delay = 20  # Wait 20 seconds if job.refresh() fails
    max_retries = 10  # Retry up to 10 times
    hpcflex_update_interval = 10  # HPC-Flex check-in interval
    retries = 0
    terminal_statuses = {"completed", "terminating", "terminated", "failed"}
    while job.status not in terminal_statuses:  # type: ignore
        try:
            job.refresh()
            n_failed, n_queued, n_active, n_running, n_completed = (
                check_task_status(job)
            )
            retries = 0  # Reset retries on success
        except Exception as e:
            logger.warning(f"Job refresh failed: {e}")
            while retries < max_retries:
                logger.info(
                    f"Retrying job.refresh() in {retry_delay} seconds... (Attempt {retries + 1}/{max_retries})"
                )
                time.sleep(retry_delay)
                try:
                    job.refresh()
                    n_failed, n_queued, n_active, n_running, n_completed = (
                        check_task_status(job)
                    )
                    break  # Exit retry loop
                except Exception as e:
                    retries += 1
                    logger.warning(f"HPC-FLex Retry {retries} failed: {e}")
            else:
                logger.error("Max retries reached. Exiting RLC.")
                raise SystemExit(1)

        time.sleep(hpcflex_update_interval)

    logger.info(f"HPC-Flex job finished with status: {job.status}")

    # Download results files
    no_cpu = max(mp.cpu_count() - 1, 10)  # leave one CPU free
    logger.info(f"Using {no_cpu} CPUs for downloading results files...")
    job.download_files(
        usage="temp", folder="runs", pattern="*.json", processes=no_cpu
    )
    logger.info("Results files downloaded.")

    job.delete()
    # remove the file, flagging successful job completion
    os.remove(hpc_job_id)

    if n_failed:
        logger.info(
            "There are %d failed cases, please check the OrcaFlex model"
            % (n_failed)
        )
        # Check each file in file list to see if a *.json file exists. If not, it must have failed.
        unstable = get_unstable(yml_files)
        return yml_files, unstable
    else:
        return yml_files, []
