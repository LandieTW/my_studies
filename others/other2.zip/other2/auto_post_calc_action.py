import json
import os
import re
import time

import OrcFxAPI

LAST_TIME = time.time()


def get_number_before_extension(filepath):
    # Get the base filename from the path
    filename = os.path.basename(filepath)
    # Split the filename at the extension
    name, _ = os.path.splitext(filename)
    # Find all numbers (integer or float) in the filename
    numbers = re.findall(r"\d+\.\d+|\d+", name)
    # Return the last number found, converted to float or int
    if numbers:
        last_number = numbers[-1]
        try:
            number = float(last_number)
            if number.is_integer():
                return int(number)
            return number
        except ValueError:
            return None
    return None


def run_post_calc(info):
    analysis_criteria = [
    {
        "orcaflex_object_name": "LC08_OMP_200Te_Cranehook",
        "orcaflex_object_parameter": "Connection z force",
        "probability_level": 0.99,
        "mode": "max",
        "value": 1233.8
    },
    {
        "orcaflex_object_name": "LC08_OMP_200Te_Cranehook",
        "orcaflex_object_parameter": "Connection z force",
        "probability_level": 0.9,
        "mode": "min",
        "value": 59.9
    },
    {
        "orcaflex_object_name": "Sling1",
        "orcaflex_object_parameter": "Effective tension",
        "orcaflex_object_argument": "End A",
        "probability_level": 0.9,
        "mode": "max",
        "value": 391.1
    },
    {
        "orcaflex_object_name": "Sling1",
        "orcaflex_object_parameter": "Effective tension",
        "orcaflex_object_argument": "End A",
        "probability_level": 0.9,
        "mode": "min",
        "value": 0
    },
    {
        "orcaflex_object_name": "Sling2",
        "orcaflex_object_parameter": "Effective tension",
        "orcaflex_object_argument": "End A",
        "probability_level": 0.9,
        "mode": "max",
        "value": 391.1
    },
    {
        "orcaflex_object_name": "Sling2",
        "orcaflex_object_parameter": "Effective tension",
        "orcaflex_object_argument": "End A",
        "probability_level": 0.9,
        "mode": "min",
        "value": 0
    },
    {
        "orcaflex_object_name": "Sling3",
        "orcaflex_object_parameter": "Effective tension",
        "orcaflex_object_argument": "End A",
        "probability_level": 0.9,
        "mode": "max",
        "value": 391.1
    },
    {
        "orcaflex_object_name": "Sling3",
        "orcaflex_object_parameter": "Effective tension",
        "orcaflex_object_argument": "End A",
        "probability_level": 0.9,
        "mode": "min",
        "value": 0
    },
    {
        "orcaflex_object_name": "Sling4",
        "orcaflex_object_parameter": "Effective tension",
        "orcaflex_object_argument": "End A",
        "probability_level": 0.9,
        "mode": "max",
        "value": 391.1
    },
    {
        "orcaflex_object_name": "Sling4",
        "orcaflex_object_parameter": "Effective tension",
        "orcaflex_object_argument": "End A",
        "probability_level": 0.9,
        "mode": "min",
        "value": 0
    }
]

    wavetype = info.model.environment.GetData("WaveType", 0)
    period_type = info.model.general.comments
    if wavetype in {"Airy", "Dean Stream", "Stokes' 5th", "Cnoidal"}:
        waveData = ["WaveHeight", "WavePeriod", "WaveDirection"]
        simPeriod = OrcFxAPI.pnLatestWave
    elif wavetype in {"JONSWAP", "ISSC", "Torsethaugen", "Gaussian Swell"}:
        waveData = [
            "WaveHs",
            "WaveTp" if period_type == "Tp" else "WaveTz",
            "WaveDirection",
            "WaveSeed",
        ]
        simPeriod = OrcFxAPI.SpecifiedPeriod(
            FromTime=0.0, ToTime=info.model.simulationStopTime
        )
    elif wavetype in {"Ochi-Hubble", "User Defined Spectrum"}:
        waveData = ["WaveHs", "WaveTz", "WaveDirection", "WaveSeed"]
        simPeriod = OrcFxAPI.SpecifiedPeriod(
            FromTime=0.0, ToTime=info.model.simulationStopTime
        )
    else:
        raise Exception(f"Unsupported wave type: {wavetype}")

    wave_data = {}
    for key in waveData:
        wave_data[key] = info.model.environment.GetData(key, 0)

    results = []
    for criterion in analysis_criteria:
        obj_name = criterion["orcaflex_object_name"]
        param = criterion["orcaflex_object_parameter"]
        mode = criterion["mode"].lower()
        argument = criterion.get("orcaflex_object_argument")
        obj = info.model[obj_name]
        extra = None
        extra_label = None
        is_range = False

        if argument:
            info.model.ReportActionProgress("Argument = " + argument)
            if argument.lower() in ["range"]:
                extrema = obj.RangeGraph(param, period=simPeriod)
                extra_label = "Range"
                is_range = True
            else:
                if isinstance(argument, (int, float)):
                    extra = OrcFxAPI.oeLine(ArcLength=argument)
                    extra_label = f"{argument:.2f}m"
                elif argument.lower() in ["enda", "end a"]:
                    extra = OrcFxAPI.oeEndA
                    extra_label = "End A"
                elif argument.lower() in ["endb", "end b"]:
                    extra = OrcFxAPI.oeEndB
                    extra_label = "End B"
                extrema = obj.AnalyseExtrema(param, period=simPeriod, objectExtra=extra)
        else:
            extrema = obj.AnalyseExtrema(param, period=simPeriod)

        result_entry = {
            "orcaflex_object_name": obj_name,
            "orcaflex_object_parameter": param,
            "mode": mode,
            "orcaflex_object_argument": extra_label,
            "value": None,
        }

        if mode == "max":
            result_entry["value"] = max(extrema.Max) if is_range else extrema.Max
        elif mode == "min":
            result_entry["value"] = min(extrema.Min) if is_range else extrema.Min

        results.append(result_entry)

    seed_number = get_number_before_extension(info.modelFileName)
    output = {
        "model": info.modelFileName,
        "seed_number": seed_number,
        "waveType": wavetype,
        "waveData": wave_data,
        "results": results,
    }

    output_file = os.path.splitext(info.modelFileName)[0] + "_results.json"
    with open(output_file, "w") as f:
        json.dump(output, f, indent=4)

    info.model.ReportActionProgress("Results written to " + output_file)
    return None


def Execute(info):
    run_post_calc(info)
