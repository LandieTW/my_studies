import io
import os
import fnmatch
import atexit
import tempfile
import logging
from typing import Optional
import requests
import re
import time
import json
from multiprocessing.pool import ThreadPool

import msal
from azure.storage.blob import ContainerClient, BlobClient

logger = logging.getLogger(__name__)

# Token cache management
__cache_file_name = os.path.join(tempfile.gettempdir(), ".hpcflex-cache")
token_cache = msal.SerializableTokenCache()
if os.path.exists(__cache_file_name):
    token_cache.deserialize(open(__cache_file_name, "r").read())
atexit.register(lambda:
                open(__cache_file_name, "w").write(token_cache.serialize())
                # Hint: The following optional line persists only when state changed
                if token_cache.has_state_changed else None
                )

config = {
    "type": "PublicClient",
    "authority": "https://login.microsoftonline.com/0804c951-93a0-405d-80e4-fa87c7551d6a",
    "client_id": "24007313-fe62-4292-80fb-4997771dcb1f",
    "scopes": ["api://24007313-fe62-4292-80fb-4997771dcb1f/.default"],
    "endpoint": "https://hpcflex.apps.technipfmc.com"
}

config_file_name = os.getenv("HPCFLEX_CONFIG_FILE")
if config_file_name is not None:
    user_config = json.load(open(config_file_name))
    config.update(user_config)

class _IteratorReader(io.RawIOBase):
    def __init__(self, iterator):
        self.iterator = iterator
        self.leftover = []

    def readinto(self, buffer: bytearray) -> Optional[int]:
        size = len(buffer)
        while len(self.leftover) < size:
            try:
                self.leftover.extend(next(self.iterator))
            except StopIteration:
                break

        if len(self.leftover) == 0:
            return 0

        output, self.leftover = self.leftover[:size], self.leftover[size:]
        buffer[:len(output)] = output
        return len(output)

    def readable(self) -> bool:
        return True

class _Connection:
    def __init__(self, config):
        # Service principal client id
        authority = config["authority"]
        self.scopes = config["scopes"]
        self.client_type = config["type"]
        client_id = config["client_id"]
        if self.client_type == "PublicClient":
            self.app = msal.PublicClientApplication(client_id,
                                                    authority=authority, token_cache=token_cache)
        else:
            if "secret" in config:
                client_credential = config["secret"]
                self.app = msal.ConfidentialClientApplication(client_id,
                                                              authority=authority, client_credential=client_credential)
            elif "refresh_token" in config:
                refresh_token = config["refresh_token"]
                self.app = msal.ConfidentialClientApplication(
                    client_id, authority=authority)
                self.app.acquire_token_by_refresh_token(
                    refresh_token, scopes=self.scopes)
            else:
                raise Exception("Unable to configure connection to server")

        base_url = config["endpoint"]
        self.prefix = base_url + "/api/v1"
        self.session = requests.Session()

    def is_connected(self) -> bool:
        try:
            requests.head(self.base_url)
            return True
        except:
            return False

    def get_access_token(self):
        accounts = self.app.get_accounts()
        result = None
        token = None
        if accounts:
            # Assuming the end user chose this one
            chosen = accounts[0]
            # Now let's try to find a token in cache for this account
            token = self.app.acquire_token_silent(self.scopes, account=chosen)

        if not token:
            logger.info(
                "No suitable token exists in cache. Let's get a new one from AAD.")
            if self.client_type == "PublicClient":
                token = self.app.acquire_token_interactive(scopes=self.scopes)
            else:
                token = self.app.acquire_token_for_client(scopes=self.scopes)

        if "access_token" in token:
            result = token['access_token']

        return result

    def get_headers(self):
        access_token = self.get_access_token()
        return {'Authorization': 'Bearer ' + access_token}

    def request(self, method: str, path: str, stream: bool = None) -> requests.Response:
        url = self.prefix + path
        headers = self.get_headers()
        return self.session.request(method, url, headers=headers, stream=stream)

    def get_jobs(self):
        url = self.prefix + "/jobs?detailed=false"
        headers = self.get_headers()
        response = self.session.get(  # Use token to call downstream service
            url,
            headers=headers,
        )
        if response.ok:
            return response.json()
        else:
            raise Exception("Failed to load job")

    def get_job(self, job_id: str):
        url = self.prefix + "/jobs/" + job_id
        headers = self.get_headers()
        response = self.session.get(  # Use token to call downstream service
            url,
            headers=headers,
        )
        if response.ok:
            return response.json()
        else:
            raise Exception("Failed to load job")

    def create_job(self):
        url = self.prefix + "/jobs"
        headers = self.get_headers()
        response = self.session.post(
            url,
            headers=headers,
        )
        if response.ok:
            return response.json()
        else:
            raise Exception(response.content)

    def delete_job(self, job_id: str):
        url = self.prefix + "/jobs/" + job_id
        headers = self.get_headers()
        response = self.session.delete(
            url,
            headers=headers,
        )
        if response.ok:
            return True
        else:
            raise Exception(response.content)

    def put_job(self, action, job_id: str, job_info):
        url = self.prefix + "/jobs/" + job_id
        headers = self.get_headers()
        response = self.session.put(
            url,
            headers=headers,
            json={"action": action, "job": job_info},
        )
        if response.ok:
            return response.json()
        else:
            raise Exception(response.content)

    def put_job_task(self, action, job_id: str, task_id: str, job_info):
        url = self.prefix + "/jobs/" + job_id + "/tasks/" + task_id
        headers = self.get_headers()
        response = self.session.put(
            url,
            headers=headers,
            json={"action": action, "job": job_info},
        )
        if response.ok:
            return response.json()
        else:
            raise Exception(response.content)

    def create_storage_info(self, job_id: str, usage: str) -> dict:
        url = self.prefix + "/storage/"
        headers = self.get_headers()
        response = self.session.post(
            url,
            headers=headers,
            json={"jobId": job_id, "usage": usage},
        )
        if response.ok:
            return response.json()
        else:
            raise Exception(response.content)

    def update_job(self, job_id: str, job_info):
        url = self.prefix + "/jobs/" + job_id
        headers = self.get_headers()
        response = self.session.put(
            url,
            headers=headers,
            json={"action": "update", "job": job_info},
        )
        if response.ok:
            return response.json()
        else:
            raise Exception(response.content)

    def unzip_blob(self, job_id: str, usage: str, zip_filename: str):
        url = self.prefix + "/storage/unzip"
        headers = self.get_headers()
        response = self.session.put(
            url,
            headers=headers,
            json={"jobId": job_id, "usage": usage,
                  "zipFileName": zip_filename},
        )
        return response.content

    def read_task_stream(self, job_id: str, task_id: str, stream_name: str):
        path = f"/jobs/{job_id}/tasks/{task_id}/{stream_name}"
        response = self.request("GET", path, stream=True)
        if response.ok:
            return response.iter_lines()
        else:
            return None

    def read_task_file(self, job_id: str, task_id: str, file_name: str, text: bool = True):
        path = f"/jobs/{job_id}/tasks/{task_id}/files/{file_name}"
        response: requests.Response = self.request("GET", path, stream=True)
        if response.ok:
            if text == True:
                return response.iter_lines()
            else:
                return response.iter_content()
        else:
            return None

    def get_task_stream(self, job_id: str, task_id: str, stream_name: str):
        url = f"{self.prefix}/jobs/{job_id}/tasks/{task_id}/{stream_name}"
        headers = self.get_headers()
        response = self.session.get(
            url,
            headers=headers
        )
        if response.ok:
            return str(response.content, "utf-8")
        else:
            return None

    def get_task_file_content(self, job_id: str, task_id: str, file_name: str):
        url = f"{self.prefix}/jobs/{job_id}/tasks/{task_id}/files/{file_name}"
        headers = self.get_headers()
        response = self.session.get(
            url,
            headers=headers
        )
        if response.ok:
            response.iter_lines()
            return str(response.content, "utf-8")
        else:
            return None

    def get_task_file_list(self, job_id: str, task_id: str):
        url = f"{self.prefix}/jobs/{job_id}/tasks/{task_id}/filelist.json"
        headers = self.get_headers()
        response = self.session.get(
            url,
            headers=headers
        )
        if response.ok:
            response.iter_lines()
            return response.json()
        else:
            return None


class Job:
    """
    An instance of a Job represents a job in HPC-Flex
    """
    # Static members
    __connection = _Connection(config)

    @classmethod
    def setup_connection(cls, client_id: str, client_type: str = "ConfidentialClient", refresh_token: str = None, secret: str = None):
        global config
        custom_config = {
            "type": client_type,
            "client_id": client_id
        }
        if secret is not None:
            custom_config["secret"] = secret
        elif refresh_token is not None:
            custom_config["refresh_token"] = refresh_token
        config.update(custom_config)
        cls.__connection = _Connection(config)

    @classmethod
    def get_list(cls) -> list[str]:
        """
        returns the list of jobs

        Returns:
            List of jobs
        """
        list = cls.__connection.get_jobs()
        result = []
        for job in list:
            result.append(job["id"])
        return result

    # Subclass used to iterate Job tasks
    class LoadCase:
        """
        An instance of LoadCase represent a job load case (task)
        """

        # Class members
        __connection = _Connection(config)

        def __init__(self, l, job_id):
            self.__dict__ = l
            self.job_id = job_id

        def get_stderr(self):
            result = self.__connection.get_task_stream(
                self.job_id, self.taskId, "stderr")
            return result

        def get_stdout(self):
            result = self.__connection.get_task_stream(
                self.job_id, self.taskId, "stdout")
            return result

        def get_file_content(self, filename: str):
            result = self.__connection.get_task_file_content(
                self.job_id, self.taskId, filename)
            return result

        def get_file(self, filename: str):
            return self.__connection.read_task_file(self.job_id, self.taskId, filename)
        
        def get_file_list(self):
            return self.__connection.get_task_file_list(self.job_id, self.taskId)

    # Object members
    def __init__(self):
        self.job_id = ""

    def __load_json(self, j):
        self.__dict__ = j

    def __get_json(self, full=False):
        result = self.__dict__
        if not full:
            # removing loadcases from payload
            result.pop("loadCases")
        return result

    def create(self, application: str = None, application_version: str = None, name: str = None,
               high_priority: bool = None, linked_job_id: str = None, task_maximum_wall_time: int = None, threads: int = None):
        """
        Create a new job.

        parameters:
            application (string): Application to be executed (Default: Orcaflex)
            application_version (string): Application version to be rexecuted (if applicable)
            name (string): Optional description of the job
            high_priority (boolean): When true, the job will be executed on the High Priority compute nodes pool (Default: false)
            linked_job_id (string): Id of the job to retreive the result files from (if applicable)

        """
        j = self.__connection.create_job()
        self.__load_json(j)
        logger.info(f"Created new job with id={self.id}")
        if application:
            self.application = application
        if application_version:
            self.applicationVersion = application_version
        if name:
            self.name = name
        if high_priority:
            self.lowPriority = not high_priority
        if linked_job_id:
            self.dataSourceJobId = linked_job_id
        if task_maximum_wall_time:
            self.taskMaxWallClockTime = f"PT{task_maximum_wall_time}H"
        if threads:
            self.threads = threads

    def get_load_cases(self) -> list[LoadCase]:
        """
        Get the list of load cases (tasks)

        Returns:
            list of load cases (tasks)
        """
        result = []
        for LC in self.loadCases:
            result.append(self.LoadCase(LC, self.id))
        return result

    def load(self, job_id):
        """
        Load a job

        Parameters:
            job_id (string): Id of the job to load        
        """
        j = self.__connection.get_job(job_id)
        self.__load_json(j)

    def save(self):
        """
        Save the job parameters.
        """
        j = self.__connection.put_job(
            "update", self.id, self.__get_json(False))
        self.__load_json(j)

    def delete(self):
        """
        Delete the job and associated files.
        """
        self.__connection.delete_job(self.id)

    def prepare(self):
        """
        Prepare the job (optional)
        """
        j = self.__connection.put_job(
            "prepare", self.id, self.__get_json(False))
        self.__load_json(j)

    def execute(self):
        """
        Execute the job
        """
        j = self.__connection.put_job(
            "execute", self.id, self.__get_json(False))
        self.__load_json(j)

    def cancel(self):
        """
        Cancel the job execution.
        """
        j = self.__connection.put_job(
            "cancel", self.id, self.__get_json(False))
        self.__load_json(j)

    def cancel(self, task_id: str):
        """
        Cancel the execution of a specific task.
        """
        j = self.__connection.put_job_task(
            "cancel", self.id, task_id, self.__get_json(False))
        self.__load_json(j)

    def refresh(self):
        """
        Refresh the status and load case list of the job.
        """
        self.load(self.id)

    # Data storage management
    def __get_storage_access(self, usage) -> tuple[dict[str, str], ContainerClient]:
        storage = self.__connection.create_storage_info(self.id, usage)
        container_url = storage["containerUrl"]
        container_sas = storage["sharedAccessSignature"]
        container_uri = f"{container_url}?{container_sas}"
        container_client = ContainerClient.from_container_url(container_uri)
        return storage, container_client

    def __upload_blob(self, blob_client: BlobClient, filepath):
        logger.info(f"uploading {filepath}")
        if blob_client.exists():
            blob_client.delete_blob()
        with open(filepath, "rb") as stream:
            chunk_size = 1024 * 1024  # 1MiB
            blob_client.create_append_blob()
            while True:
                blob_data = stream.read(chunk_size)
                if not blob_data:
                    break
                blob_client.append_block(blob_data)

    def __get_blob_list(self, usage: str, pattern: str = None):
        storage, container_client = self.__get_storage_access(usage)
        prefix = storage["folderName"]
        bloblist = container_client.list_blobs(name_starts_with=prefix)
        if (pattern):
            return self.__filter_blobs(bloblist, prefix, pattern)
        else:
            return bloblist

    def __download_blob(self, blob_client: BlobClient, filepath):
        logger.info(f"downloading {filepath}")
        with open(filepath, "wb") as my_file:
            stream_downloader = blob_client.download_blob(max_concurrency=20)
            stream_downloader.readinto(my_file)

    def __download_blobs(self, container_client: ContainerClient, folder, blobs, processes=1):
        # internal private function
        def download_blob(blob):
            filename = blob.name.rsplit('/', 1)[1]
            filepath = os.path.join(folder, filename)
            blob_client = container_client.get_blob_client(blob.name)
            self.__download_blob(blob_client, filepath)
            return filename
        if processes > 1:
            # Parallel download
            with ThreadPool(processes=int(processes)) as pool:
                return pool.map(download_blob, blobs)
        else:
            result = list()
            for count, blob in enumerate(blobs):
                result.append(download_blob(blob))
                # Wait for one second every 1000 downloads
                if (count % 1000 == 999):
                    time.sleep(1)
            return result

    def __filter_blobs(self, blobs, prefix, pattern):
        regex = fnmatch.translate(f"{prefix}/{pattern}")
        reobj = re.compile(regex, flags=re.IGNORECASE)
        return filter(lambda blob: reobj.match(blob.name), blobs)

    def get_storage_url(self, usage: str) -> str:
        storage, container_client = self.__get_storage_access(usage)
        folder = storage["folderName"].strip('/')
        container_url = storage["containerUrl"].strip('/')
        container_sas = storage["sharedAccessSignature"]
        return f"{container_url}/{folder}/?{container_sas}"

    def upload_files(self, usage: str, folder: str):
        """
        Upload files from the specified folder to the cloud storage sepecified by usage.

        Parameters:
            usage (string): name of the cloud storage to upload files to.
            folder (string): path to the local folder where the files to upload are located
        """
        logger.info("Uploading files to storage")
        storage, container_client = self.__get_storage_access(usage)
        with os.scandir(folder) as filepaths:
            for entry in filepaths:
                if not entry.name.startswith('.') and entry.is_file():
                    filename = entry.name
                    basename, extension = os.path.splitext(filename)
                    blobname = storage["folderName"] + "/" + filename
                    blob_client = container_client.get_blob_client(blobname)
                    self.__upload_blob(blob_client, entry.path)

                    # unzip file if .zip
                    if extension.lower() == "zip":
                        self.__connection.unzip_blob(self.id, usage, filename)

    def upload_file(self, usage: str, filepath: str):
        """
        Upload the specified file to the cloud storage sepecified by usage.

        Parameters:
            usage (string): name of the cloud storage to upload files to.
            filepath (string): path to the local file to upload location.
        """
        logger.info("Uploading file to storage")
        storage, container_client = self.__get_storage_access(usage)

        folder, filename = os.path.split(filepath)
        basename, extension = os.path.splitext(filename)
        blobname = storage["folderName"] + "/" + filename

        blob_client = container_client.get_blob_client(blobname)
        self.__upload_blob(blob_client, filepath)

        if extension.lower() == ".zip":
            self.__connection.unzip_blob(self.id, usage, filename)
            logger.info(f"{filename} unzipped")

    def get_file_names(self, usage: str, pattern: str = None):
        """
        Get the list of file names stored in the specified cloud storage.

        Parameters:
            usage (string): name of the cloud storage to where the files are located.
            pattern (string): pattern used to filter the files.

        Returns:
            List of the files.
        """
        blobs = self.__get_blob_list(usage, pattern)
        return map(lambda blob: blob.name.rsplit('/', 1)[1], blobs)

    def download_files(self, usage: str, folder: str, pattern: str = None, processes: int = 1):
        """
        Download files from the specified cloud storage.

        Parameters:
            usage (string): name of the cloud storage to download files from.
            folder (string): path of the folder where the files will be downloaded to.
            pattern (string): pattern used to filter the files.

        Returns:
            List of the downloaded files.
        """
        storage, container_client = self.__get_storage_access(usage)
        blobs = self.__get_blob_list(usage, pattern)
        # Download filtered blobs
        return self.__download_blobs(container_client, folder, blobs, processes)

    def download_file(self, usage: str, folder: str, filename: str):
        """
        Download a file from the specified cloud storage.

        Parameters:
            usage (string): name of the cloud storage to download the file from.
            folder (string): path of the folder where the file will be downloaded to.
            filename (string): name of the file to download.
        """
        storage, container_client = self.__get_storage_access(usage)
        filepath = os.path.join(folder, filename)
        blobname = storage["folderName"] + "/" + filename
        blob_client = container_client.get_blob_client(blobname)
        self.__download_blob(blob_client, filepath)
